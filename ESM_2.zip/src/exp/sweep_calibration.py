"""Diagnostics of the calibration in the controlled sweep: for every case (the weights before the
events), which solver produced the working weights, after how many fixed-point steps, with which
residual and in how much time.  Re-creates the weights exactly as synthetic_sweep.py does.
Output: out/sweep_calibration.csv
"""
import csv
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.calib import calibrate                         # noqa: E402
from fsp.core import target_inclusion                   # noqa: E402
from fsp.paths import OUT                               # noqa: E402
from synthetic_sweep import FAMS, GRID, family           # noqa: E402

rows = []
for fi, fam in enumerate(FAMS):
    reps = 3 if fam.startswith("lognormal") else 1
    for (n, k) in GRID:
        for rep in range(reps):
            rng = np.random.default_rng([fi, n, k, rep])
            w = family(fam, n, rng)
            t = time.time()
            lam, alw, info = calibrate(w, k, "exp", return_info=True)
            rows.append(dict(family=fam, n=n, k=k, rep=rep, pmax=float(target_inclusion(w, k).max()),
                             n_capped=int(alw.sum()), method=info.get("method", "none"),
                             fp_status=info.get("fp_status", "none"), fp_iters=info.get("fp_iters", 0),
                             iters=info["iters"], err=info["err"], seconds=time.time() - t))
with open(f"{OUT}/sweep_calibration.csv", "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0]))
    wr.writeheader()
    wr.writerows(rows)
fb = [r for r in rows if r["method"] == "newton"]
print(len(rows), "cases;", len(fb), "needed Newton:",
      [(r["family"], r["n"], r["k"], r["rep"], r["fp_status"], round(r["pmax"], 4)) for r in fb])
print("largest residual", max(r["err"] for r in rows))
