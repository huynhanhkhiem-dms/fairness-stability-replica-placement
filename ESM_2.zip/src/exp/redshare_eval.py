"""Redundant Share as a fair stateless baseline (two copies).

For every configuration of the corpus and every event of corpus_eval.py with k = 2 (removal of a domain,
reweighting by 1.25), measure the movement of Redundant Share with common random numbers (one uniform
per object and device), relative to the fair optimum, next to COS on the same keys and events.
Before measuring, exact fairness of our implementation is checked for the weights before and after
every event.  Output: out/redshare_movement.csv
"""
import csv
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import redshare as RS                         # noqa: E402
from fsp.calib import calibrate                        # noqa: E402
from fsp.core import target_inclusion                  # noqa: E402
from fsp.movement import draws, moved, topk_sets      # noqa: E402
from fsp.paths import OUT                              # noqa: E402

M = int(os.environ.get("M_KEYS", 500_000))
K = 2


def fair(w, k):
    out = np.zeros(len(w))
    p = w > 0
    out[p] = target_inclusion(w[p], k) if p.sum() > k else 1.0
    return out


def cos_weights(w, k):
    out = np.zeros(len(w))
    p = w > 0
    if p.sum() <= k:
        out[p] = np.inf
        return out
    lam, _ = calibrate(w[p], k, "exp")
    out[p] = lam
    return out


def main():
    configs = json.load(open(f"{OUT}/corpus_used.json"))
    rows = []
    t0 = time.time()
    worst_fair = 0.0
    for ci, e in enumerate(configs):
        w = np.array(e["weights"], dtype=float)
        n = len(w)
        if K >= n:
            continue
        rng = np.random.default_rng([20261117, ci])
        U = rng.random((M, n))                 # per (object, device) uniform used by Redundant Share
        E = draws(M, n, seed=1)                # straws for COS (as in corpus_eval.py)
        worst_fair = max(worst_fair, RS.check_fair(w, K))
        base_rs = RS.sample_sets(w, U, K)
        base_cos = topk_sets(cos_weights(w, K), E, K)
        f0 = fair(w, K)
        for ev in ("remove", "reweight"):
            for j in range(n):
                w2 = w.copy()
                w2[j] = 0.0 if ev == "remove" else w[j] * 1.25
                if (w2 > 0).sum() < K:
                    continue
                opt = float(np.clip(fair(w2, K) - f0, 0, None).sum())
                if opt <= 1e-3:
                    continue
                worst_fair = max(worst_fair, RS.check_fair(w2, K))
                m_rs = moved(base_rs, RS.sample_sets(w2, U, K))
                m_cos = moved(base_cos, topk_sets(cos_weights(w2, K), E, K))
                pm = float(max(f0.max(), fair(w2, K).max()))
                rows.append(dict(config=e["id"], n=n, k=K, event=ev, node=j, opt_fair=opt, pmax=pm,
                                 rs_moved=m_rs, rs_ratio=m_rs / opt, cos_moved=m_cos, cos_ratio=m_cos / opt,
                                 rs_se=float(np.sqrt(m_rs * (1 - min(m_rs, 1)) / M)) / opt))
        print(f"[{time.time()-t0:5.0f}s] {ci+1}/{len(configs)} n={n} done", flush=True)
    assert worst_fair < 1e-9, f"Redundant Share implementation not exactly fair: {worst_fair}"
    with open(f"{OUT}/redshare_movement.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0]))
        wr.writeheader()
        wr.writerows(rows)
    print("events", len(rows), "largest fairness error of the implementation", worst_fair)


if __name__ == "__main__":
    main()
