"""E1/E2: fairness and data movement on the corpus of real multi-pick
configurations, including runs of the unmodified Ceph CRUSH mapper.

For each heterogeneous configuration (failure-domain weights w) and replica
count k we report
  fairness : exact inclusion probabilities of straw2 (successive sampling),
             of two other stable rules (priority shape, power exponent), and of
             the calibrated rule (COS), against the capped-proportional target;
  movement : for every single-domain REMOVE event and every REWEIGHT(x1.25)
             event, the expected number of replicas copied per key, divided by
             the optimum, for
        ceph        real Ceph mapper, raw weights            (deployed default)
        retry       numpy model of the same retry coupling   (cross-check)
        topk        single-order top-k, raw weights          (stable, biased)
        ceph+cal    real Ceph mapper, calibrated weights     (ideal compat weight-set)
        cos         single-order top-k, calibrated weights   (this paper)
        systematic  Madow systematic pps                     (classical fair design)
        pivotal     ordered pivotal sampling                 (classical fair design)
All movement numbers use common random numbers / identical keys before and
after the event.
"""
import csv
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import cephcrush as CC, crushmap as C          # noqa: E402
from fsp.calib import calibrate                        # noqa: E402
from fsp.core import inclusion, target_inclusion        # noqa: E402
from fsp.designs import pivotal_sets, retry_sets, systematic_sets   # noqa: E402
from fsp.movement import draws, moved_stats, topk_sets        # noqa: E402

from fsp.paths import ROOT   # noqa: E402
M_KEYS = int(os.environ.get("M_KEYS", 500_000))
MAX_EVENT_NODES = 8
HET_CV = 0.005


def flat_map(ws):
    cm = C.CrushMap("flat")
    cm.buckets[-1] = C.Bucket(-1, "root", "root", "straw2", [(i, w) for i, w in enumerate(ws) if w > 0])
    for i in range(len(ws)):
        cm.devices[i] = f"osd.{i}"
    cm.rules.append(C.Rule("r", [("take", "root", None), ("choose", "firstn", 0, "osd"), ("emit",)]))
    return cm


def ceph_sets(ws, k, m):
    """Membership matrix from the real Ceph mapper on a flat straw2 bucket."""
    ws = np.asarray(ws, dtype=float)
    n = len(ws)
    fin = ws[np.isfinite(ws) & (ws > 0)]
    has_inf = bool(np.isinf(ws).any())
    # CRUSH weights are 16.16 fixed point (< 65536).  Without capped nodes use the
    # full range; with capped ("always") nodes keep a 1:16383 ratio to the rest.
    # NOTE: the builder API takes weights as signed 32-bit ints, i.e. 16.16 values
    # below 32768; larger values overflow.
    top = 2.0 if has_inf else 16000.0
    scale = top / fin.max() if len(fin) else 1.0
    wq = np.where(np.isinf(ws), 32767.0, ws * scale)
    cm = flat_map(wq)
    res = CC.run(CC.spec_for(cm, cm.rules[0], k, m), m, k)
    mem = np.zeros((m, n), dtype=bool)
    for j in range(k):
        ok = res[:, j] != CC.NONE
        mem[np.nonzero(ok)[0], res[ok, j]] = True
    return mem


def fair_vec(w, k):
    out = np.zeros(len(w))
    p = w > 0
    out[p] = target_inclusion(w[p], k)
    return out


def own_vec(w, k):
    out = np.zeros(len(w))
    p = w > 0
    out[p] = inclusion(w[p], k, "exp") if p.sum() > k else 1.0
    return out


def cal_mult(w, k):
    out = np.zeros(len(w))
    p = w > 0
    if p.sum() <= k:
        out[p] = np.inf
        return out
    lam, _ = calibrate(w[p], k, "exp")
    out[p] = lam
    return out


def main():
    corpus = json.load(open(f"{ROOT}/data/corpus.json"))["configurations"]
    # merge near-duplicates (text vs json rounding) and drop numerically homogeneous ones
    configs = []
    for e in corpus:
        if e["cv"] <= HET_CV:
            continue
        v = np.array(e["weights"]) / np.sum(e["weights"])
        dup = None
        for c in configs:                 # same cluster in another file format / snapshot
            u = np.array(c["weights"]) / np.sum(c["weights"])
            if len(u) == len(v) and np.max(np.abs(u / v - 1)) < 0.02:
                dup = c
                break
        if dup is not None:
            dup["sources"] = dup["sources"] + e["sources"]
            continue
        configs.append(dict(e))
    json.dump(configs, open(f"{ROOT}/out/corpus_used.json", "w"), indent=1)
    os.makedirs(f"{ROOT}/out/chunks", exist_ok=True)
    lo, hi = (int(x) for x in os.environ.get("SLICE", f"0:{len(configs)}").split(":"))
    t0 = time.time()
    for ci, e in enumerate(configs):
        if not (lo <= ci < hi) or os.path.exists(f"{ROOT}/out/chunks/move_{ci:02d}.csv"):
            continue
        fair_rows, move_rows = [], []
        w = np.array(e["weights"], dtype=float)
        n = len(w)
        ks = {2, 3}
        for s in e["sources"]:
            if s["num"] and s["num"] > 1:
                ks.add(int(s["num"]))
            ks.update(int(x) for x in s["pool_sizes"])
        ks = sorted(k for k in ks if 2 <= k < n)
        label = e["sources"][0]["map"].split("/")[-1] + ":" + e["sources"][0]["level"]
        for k in ks:
            pf = target_inclusion(w, k)
            ps = inclusion(w, k, "exp")
            lam, always, info = calibrate(w, k, "exp", return_info=True)
            row = dict(config=e["id"], label=label, n=n, k=k, cv=e["cv"],
                       n_capped=int((pf >= 1 - 1e-12).sum()),
                       straw2_over_pct=100 * (ps / pf - 1).max(), straw2_under_pct=100 * (ps / pf - 1).min(),
                       straw2_misplaced_pct=100 * np.abs(ps - pf).sum() / (2 * k),
                       cos_abs_err=info["err"], cos_iters=info["iters"])
            for nm, shape in (("priority", "uniform"), ("pow1.25", ("frechet", 1.25)), ("pow1.5", ("frechet", 1.5))):
                px = inclusion(w, k, shape)
                row[f"{nm}_over_pct"] = 100 * (px / pf - 1).max()
                row[f"{nm}_under_pct"] = 100 * (px / pf - 1).min()
                row[f"{nm}_misplaced_pct"] = 100 * np.abs(px - pf).sum() / (2 * k)
            fair_rows.append(row)
            # ---------------- movement events ----------------
            rng = np.random.default_rng(1000 + ci)
            nodes = list(range(n)) if n <= MAX_EVENT_NODES else sorted(
                set([0, 1, n - 1, n - 2]) | set(rng.choice(n, MAX_EVENT_NODES - 4, replace=False).tolist()))
            U = draws(M_KEYS, n, seed=77 + ci)
            base = dict(
                ceph=ceph_sets(w, k, M_KEYS),
                retry=retry_sets(w, M_KEYS, k, seed=5 + ci),
                topk=topk_sets(w, U, k),
                systematic=systematic_sets(w, M_KEYS, k, seed=9 + ci),
                pivotal=pivotal_sets(w, M_KEYS, k, seed=9 + ci),
            )
            mc = cal_mult(w, k)
            base["ceph+cal"] = ceph_sets(mc, k, M_KEYS)
            base["cos"] = topk_sets(mc, U, k)
            pf0, po0 = fair_vec(w, k), own_vec(w, k)
            for ev in ("remove", "reweight"):
                for i in nodes:
                    w2 = w.copy()
                    if ev == "remove":
                        if n - 1 < k:
                            continue
                        w2[i] = 0.0
                    else:
                        w2[i] *= 1.25
                    pf1, po1 = fair_vec(w2, k), own_vec(w2, k)
                    opt_fair = float(np.clip(pf1 - pf0, 0, None).sum())
                    opt_own = float(np.clip(po1 - po0, 0, None).sum())
                    mc2 = cal_mult(w2, k)
                    after = dict(
                        ceph=ceph_sets(w2, k, M_KEYS),
                        retry=retry_sets(w2, M_KEYS, k, seed=5 + ci),
                        topk=topk_sets(w2, U, k),
                        systematic=systematic_sets(w2, M_KEYS, k, seed=9 + ci),
                        pivotal=pivotal_sets(w2, M_KEYS, k, seed=9 + ci),
                    )
                    after["ceph+cal"] = ceph_sets(mc2, k, M_KEYS)
                    after["cos"] = topk_sets(mc2, U, k)
                    for name in base:
                        mv, se = moved_stats(base[name], after[name])
                        ref = opt_own if name in ("ceph", "retry", "topk") else opt_fair
                        move_rows.append(dict(config=e["id"], label=label, n=n, k=k, event=ev, node=i,
                                              share=float(w[i] / w.sum()), scheme=name, moved=mv,
                                              opt_fair=opt_fair, opt_own=opt_own,
                                              ratio=mv / ref if ref > 1e-12 else float("nan"),
                                              se=se, n_keys=M_KEYS))  # exact sample SD / sqrt(N), with keys as units
            print(f"[{time.time()-t0:6.0f}s] {ci+1}/{len(configs)} {label} n={n} k={k} done", flush=True)
        for name, rows in ((f"fair_{ci:02d}.csv", fair_rows), (f"move_{ci:02d}.tmp", move_rows)):
            with open(f"{ROOT}/out/chunks/{name}", "w", newline="") as f:
                wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                wr.writeheader()
                wr.writerows(rows)
        os.replace(f"{ROOT}/out/chunks/move_{ci:02d}.tmp", f"{ROOT}/out/chunks/move_{ci:02d}.csv")
    # merge when every configuration has its chunk
    import glob
    import pandas as pd
    if len(glob.glob(f"{ROOT}/out/chunks/move_*.csv")) == len(configs):
        for kind, name in (("fair", "corpus_fairness.csv"), ("move", "corpus_movement.csv")):
            pd.concat([pd.read_csv(p) for p in sorted(glob.glob(f"{ROOT}/out/chunks/{kind}_*.csv"))]).to_csv(
                f"{ROOT}/out/{name}", index=False)
        print("merged all", len(configs), "configurations")


if __name__ == "__main__":
    main()
