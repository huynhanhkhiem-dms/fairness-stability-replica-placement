"""Turn experiment outputs into LaTeX tables and numeric macros.

Every number quoted in the paper comes from paper/numbers.tex or paper/tables/*.tex,
both written by this script from out/*.csv and out/*.json.  Nothing is typed by hand.
"""
import glob
import json
import os
import sys
from fractions import Fraction

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.calib import calibrate                      # noqa: E402
from fsp.core import inclusion, target_inclusion     # noqa: E402

from fsp.paths import ROOT   # noqa: E402
OUT = f"{ROOT}/out"
TAB = f"{ROOT}/paper/tables"
os.makedirs(TAB, exist_ok=True)
macros = {}
CAP = 0.999          # a domain with pi* >= CAP is treated as capped


def M(name, value, fmt="{:.2f}"):
    assert name.isalpha(), name
    macros[name] = fmt.format(value) if not isinstance(value, str) else value


def tex_escape(s):
    return str(s).replace("_", r"\_").replace("%", r"\%").replace("~", r"\textasciitilde{}")


def sci(x):
    if x == 0:
        return "0"
    m, e = f"{x:.0e}".split("e")
    return f"${m}\\times10^{{{int(e)}}}$" if m != "1" else f"$10^{{{int(e)}}}$"


def sci_up(x):
    """x rounded UP to one significant digit, for statements of the form 'at most' / 'within'."""
    if x <= 0:
        return "0"
    e = int(np.floor(np.log10(x)))
    m = int(np.ceil(round(x / 10 ** e, 12)))
    if m == 10:
        m, e = 1, e + 1
    return f"${m}\\times10^{{{e}}}$" if m != 1 else f"$10^{{{e}}}$"


def up(x, nd):
    """x rounded UP to nd decimals."""
    return f"{np.ceil(round(x * 10 ** nd, 9)) / 10 ** nd:.{nd}f}"


def thousands(x):
    return f"{int(round(x)):,d}".replace(",", r"\,")


def write_table(name, header, rows, align, pre=None):
    """pre: optional first header row (a LaTeX string, including any \\cmidrule after it)."""
    with open(f"{TAB}/{name}.tex", "w") as f:
        f.write("\\begin{tabular}{" + align + "}\n\\toprule\n" + (pre + "\n" if pre else "")
                + " & ".join(header) + " \\\\\n\\midrule\n")
        for r in rows:
            if isinstance(r, str):
                f.write(r + "\n")
            else:
                f.write(" & ".join(str(c) for c in r) + " \\\\\n")
        f.write("\\bottomrule\n\\end{tabular}\n")


# ------------------------------------------------------------------ corpus description
corp = json.load(open(f"{ROOT}/data/corpus.json"))
used = json.load(open(f"{OUT}/corpus_used.json"))
W = {c["id"]: np.array(c["weights"], float) for c in used}
M("nMapsParsed", corp["n_maps"], "{:d}")
M("nConfigsAll", len(corp["configurations"]), "{:d}")
M("nConfigs", len(used), "{:d}")
M("nMin", min(c["n"] for c in used), "{:d}")
M("nMax", max(c["n"] for c in used), "{:d}")

SHORT = {"multitype.after": "multitype-a", "multitype.before": "multitype-b", "test-map-hammer-tunables.crushmap": "hammer",
         "test-map-firstn-indep.txt": "firstn-indep", "test-map-big-1.crushmap": "big-1", "osdmap.2982809": "osdmap",
         "test_crush_filter.json": "filter", "ceph-crushmap-rules-order.txt": "report-10h", "ceph-report-small.json": "report-10h",
         "test_optimize_big_cluster.json": "beesly-opt", "f": "gabe"}
NAME = {}
for c in used:
    s0 = c["sources"][0]
    nm = SHORT.get(s0["map"].split("/")[-1], s0["map"].split("/")[-1])
    if s0.get("rule") == "ssd-rule":
        nm += " (ssd)"
    NAME[c["id"]] = (nm, s0["level"])
assert len(set(NAME.values())) == len(NAME), "display names must be unique"


def event_pmax(cfg, k, ev, i):
    w = W[cfg]
    w2 = w.copy()
    w2[i] = 0.0 if ev == "remove" else w2[i] * 1.25
    a = target_inclusion(w, k).max()
    pos = w2 > 0
    b = 1.0 if pos.sum() <= k else target_inclusion(w2[pos], k).max()
    return max(a, b)


# ------------------------------------------------------------------ corpus fairness
F = pd.read_csv(f"{OUT}/corpus_fairness.csv")
rows, pg1, stranded = [], [], []
for _, r in F.iterrows():
    nm, lvl = NAME[r["config"]]
    w = W[r["config"]]
    k = int(r["k"])
    ps, pf = inclusion(w, k, "exp"), target_inclusion(w, k)
    i = int(np.argmax(ps / pf))
    p1 = ps[i] * (1 - ps[i]) / (ps[i] - pf[i]) ** 2          # PGs at which the bias equals one standard deviation
    st = 100 * (1 - 1 / (1 + r["straw2_over_pct"] / 100))
    pg1.append(p1)
    stranded.append(st)
    rows.append([tex_escape(nm), lvl, int(r["n"]), k, f"{r['cv']:.2f}", f"{r['straw2_over_pct']:.1f}", f"{r['straw2_under_pct']:.1f}",
                 f"{st:.1f}", thousands(p1), f"{r['priority_over_pct']:.1f}", f"{r['pow1.25_over_pct']:.1f}",
                 sci(r["cos_abs_err"])])
F["stranded"], F["pg1"] = stranded, pg1
write_table("corpus_fairness",
            ["map", "level", "$n$", "$k$", "CV", "over", "under", "stranded", "PGs at $1\\sigma$", "priority", "power", "resid."],
            rows, "llrrrrrrrrrr",
            pre="& & & & & \\multicolumn{4}{c}{CRUSH (exact)} & \\multicolumn{2}{c}{other shapes} & COS \\\\ "
                "\\cmidrule(lr){6-9}\\cmidrule(lr){10-11}\\cmidrule(lr){12-12}")
M("overMin", F["straw2_over_pct"].min(), "{:.1f}")
M("overMax", F["straw2_over_pct"].max(), "{:.0f}")
M("overMedianKthree", F[F.k == 3]["straw2_over_pct"].median(), "{:.1f}")
M("overMedianKtwo", F[F.k == 2]["straw2_over_pct"].median(), "{:.1f}")
M("strandedMax", F["stranded"].max(), "{:.0f}")
M("nFairRows", len(F), "{:d}")
M("nOverFive", int((F["straw2_over_pct"] >= 5).sum()), "{:d}")
M("nOverOne", int((F["straw2_over_pct"] >= 1).sum()), "{:d}")
M("cosErrMax", sci_up(F["cos_abs_err"].max()) if F["cos_abs_err"].max() > 0 else "$10^{-12}$")
M("pgOneSigmaMedian", thousands(np.median(pg1)))
M("pgOneSigmaMedianKthree", thousands(F[F.k == 3]["pg1"].median()))
M("priorityBetter", int((F["priority_over_pct"] < F["straw2_over_pct"]).sum()), "{:d}")
M("powBetter", int((F["pow1.25_over_pct"] < F["straw2_over_pct"]).sum()), "{:d}")
M("priorityOverMax", F["priority_over_pct"].max(), "{:.0f}")
M("powOverMax", F["pow1.25_over_pct"].max(), "{:.0f}")
cern = F[F["config"].map(lambda c: NAME[c][0] in ("beesly", "gabe", "osdmap"))]
named = F[(F.k == 3) & F["config"].map(lambda c: NAME[c][0] in ("beesly", "gabe"))]
M("cernNamedOverMinKthree", named["straw2_over_pct"].min(), "{:.1f}")
M("cernNamedOverMaxKthree", named["straw2_over_pct"].max(), "{:.1f}")
M("cernOverMinKthree", cern[cern.k == 3]["straw2_over_pct"].min(), "{:.1f}")
M("cernOverMaxKthree", cern[cern.k == 3]["straw2_over_pct"].max(), "{:.1f}")
M("nRacksMin", int(cern["n"].min()), "{:d}")
M("nRacksMax", int(cern["n"].max()), "{:d}")

# ------------------------------------------------------------------ validation on full maps
V = pd.read_csv(f"{OUT}/realmap_validation.csv")
V = V.drop_duplicates(subset=["n", "ceph_over_pct", "pred_over_pct"])
rows = [[tex_escape(SHORT.get(r["map"], r["map"])), tex_escape(r["rule"]), r["level"], int(r["n"]), f"{r['pred_over_pct']:.2f}",
         f"{r['ceph_over_pct']:.2f}", f"{r['max_abs_diff_pred']:.4f}", f"{r['max_abs_z']:.2f}"] for _, r in V.iterrows()]
write_table("validation", ["map", "rule", "level", "$n$", "predicted", "Ceph", "max $|\\Delta\\pi|$", "max $|z|$"],
            rows, "lllrrrrr",
            pre="& & & & \\multicolumn{2}{c}{over (\\%)} & & \\\\ \\cmidrule(lr){5-6}")
M("valRules", len(V), "{:d}")
M("valMaxZ", V["max_abs_z"].max(), "{:.2f}")
M("valMaxDiff", V["max_abs_diff_pred"].max(), "{:.4f}")
M("valPgs", thousands(V["pgs"].iloc[0]))
ndom = int(V["n"].sum())
M("valDomains", ndom, "{:d}")
M("valBonferroniZ", float(stats.norm.ppf(1 - 0.05 / (2 * ndom))), "{:.2f}")
M("valOverDiffMax", up(float((V["ceph_over_pct"] - V["pred_over_pct"]).abs().max()), 2))

# ------------------------------------------------------------------ corpus movement
Mv = pd.read_csv(f"{OUT}/corpus_movement.csv")
Mv = Mv[Mv.opt_fair > 1e-3].copy()
# A removal that leaves exactly k domains is outside the model (k <= n - 1): every rule must then place a
# replica on every remaining domain and attains the optimum, so such events carry no information.
_deg = (Mv.event == "remove") & (Mv.n - 1 <= Mv.k)
M("nDegenerate", int(_deg[Mv.scheme == "cos"].sum()), "{:d}")
Mv = Mv[~_deg].copy()
# Standard error from the observed per-key movement counts; no Poisson shortcut.
Mv["ref"] = np.where(Mv.scheme.isin(["ceph", "retry", "topk"]), Mv.opt_own, Mv.opt_fair)
Mv["se_ratio"] = Mv["se"] / Mv["ref"]
pm = {}
Mv["pmax"] = [pm.setdefault((c, int(k), e, int(i)), event_pmax(c, int(k), e, int(i)))
              for c, k, e, i in zip(Mv["config"], Mv["k"], Mv["event"], Mv["node"])]
Mv["capped"] = Mv["pmax"] >= CAP
names = {"ceph": "CRUSH (unmodified Ceph mapper)", "retry": "retry coupling (model)", "topk": "single-order top-$k$",
         "ceph+cal": "CRUSH + exact weight set$^\\dagger$", "cos": "COS (single-order, calibrated)",
         "pivotal": "ordered pivotal sampling", "systematic": "systematic $\\pi$ps"}
fair_of = {"ceph": "no", "retry": "no", "topk": "no", "ceph+cal": "yes", "cos": "yes", "pivotal": "yes", "systematic": "yes"}
keyname = {"ceph": "Ceph", "retry": "Retry", "topk": "Topk", "ceph+cal": "Cephpcal", "cos": "Cos", "pivotal": "Pivotal", "systematic": "Systematic"}


def sel(sch, ev):
    d = Mv[(Mv.scheme == sch) & (Mv.event == ev)]
    return d[~d.capped] if sch == "ceph+cal" else d


rows = []
for sch in ["ceph", "retry", "topk", "MID", "ceph+cal", "cos", "pivotal", "systematic"]:
    if sch == "MID":
        rows.append("\\midrule")
        continue
    row = [names[sch], fair_of[sch]]
    for ev in ("remove", "reweight"):
        d = sel(sch, ev)["ratio"]
        row += [f"{d.median():.3f}", f"{d.quantile(.9):.3f}", f"{d.max():.3f}"]
        K = keyname[sch] + ev.capitalize()
        M(f"mv{K}Median", d.median(), "{:.3f}")
        M(f"mv{K}Max", d.max(), "{:.2f}")
        M(f"mv{K}MedianPct", 100 * (d.median() - 1), "{:.1f}")
        M(f"mv{K}MaxPct", 100 * (d.max() - 1), "{:.0f}")
    rows.append(row)
RSm = pd.read_csv(f"{OUT}/redshare_movement.csv")
# same events as the corpus evaluation (which evaluates at most MAX_EVENT_NODES nodes per configuration)
_ck2 = Mv[(Mv.scheme == "cos") & (Mv.k == 2)][["config", "event", "node"]]
RSm = RSm.merge(_ck2, on=["config", "event", "node"], how="inner")
rsrow = ["Redundant Share, $k=2$ only$^\\ddagger$", "yes"]
for ev in ("remove", "reweight"):
    d = RSm[RSm.event == ev]["rs_ratio"]
    rsrow += [f"{d.median():.3f}", f"{d.quantile(.9):.3f}", f"{d.max():.3f}"]
# Redundant Share implementation exceeds its published bound in some removals; not an authenticated comparator.
rows = ["\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}", ["rule", "fair", "median", "p90", "max", "median", "p90", "max"], "\\midrule"] + rows
with open(f"{TAB}/corpus_movement.tex", "w") as f:
    f.write("\\begin{tabular}{llrrrrrr}\n\\toprule\n & & \\multicolumn{3}{c}{removal} & \\multicolumn{3}{c}{reweighting by $1.25$} \\\\\n")
    for r in rows:
        f.write((r if isinstance(r, str) else " & ".join(str(c) for c in r) + " \\\\") + "\n")
    f.write("\\bottomrule\n\\end{tabular}\n")
_cl = [sel(s_, e_)["ratio"].median() for s_ in ("pivotal", "systematic") for e_ in ("remove", "reweight")]
M("classicMedianMin", min(_cl), "{:.3f}")
M("classicMedianMax", max(_cl), "{:.3f}")
ncos = Mv[Mv.scheme == "cos"]
M("nEventsRemove", int((ncos.event == "remove").sum()), "{:d}")
M("nEventsReweight", int((ncos.event == "reweight").sum()), "{:d}")
M("nCalExcluded", int(Mv[(Mv.scheme == "ceph+cal")]["capped"].sum()), "{:d}")
M("nCalKept", int((~Mv[(Mv.scheme == "ceph+cal")]["capped"]).sum()), "{:d}")
M("mKeys", thousands(int(Mv["n_keys"].median())))
_maxev = int(Mv[Mv.scheme == "cos"].groupby(["config", "k", "event"])["node"].nunique().max())
M("maxEventNodes", _maxev, "{:d}")
# COS on the capped events only (the events excluded for CRUSH + weight set)
cc = ncos[ncos.capped]
M("cosCappedMax", cc["ratio"].max(), "{:.2f}")
M("cosCappedMedian", cc["ratio"].median(), "{:.3f}")
# paired one-sided Wilcoxon tests at the level of (configuration, k); events common to both rules
tests = {}
for a, b in (("cos", "ceph+cal"), ("cos", "pivotal"), ("cos", "systematic"), ("topk", "ceph"), ("topk", "retry")):
    for ev in ("remove", "reweight"):
        d = Mv[(Mv.event == ev) & Mv.scheme.isin([a, b])]
        if "ceph+cal" in (a, b):
            d = d[~d.capped]
        agg = d.groupby(["config", "k", "scheme"])["ratio"].mean().unstack("scheme").dropna()
        wt = stats.wilcoxon(agg[a], agg[b], alternative="less")
        tests[f"{a}<{b}|{ev}"] = dict(n=len(agg), p=float(wt.pvalue), wins=int((agg[a] < agg[b]).sum()))
json.dump(tests, open(f"{OUT}/movement_tests.json", "w"), indent=1)
M("testNmin", min(t["n"] for t in tests.values()), "{:d}")
M("testNmax", max(t["n"] for t in tests.values()), "{:d}")
pmax_ = max(t["p"] for t in tests.values())
M("testPmax", sci_up(pmax_).strip("$"))
M("testAllWins", "all" if all(t["wins"] == t["n"] for t in tests.values()) else "most")
# cluster bootstrap (by configuration) for the median ratios
rng = np.random.default_rng(0)
cfgs = Mv["config"].unique()


def boot(sch, ev, B=2000):
    d = sel(sch, ev)
    groups = {c: g["ratio"].values for c, g in d.groupby("config")}
    meds = []
    for _ in range(B):
        pick = rng.choice(cfgs, len(cfgs))
        vals = [groups[c] for c in pick if c in groups]
        meds.append(np.median(np.concatenate(vals)))
    return np.percentile(meds, [2.5, 97.5])


for sch in ("cos", "ceph", "ceph+cal"):
    for ev in ("remove", "reweight"):
        lo, hi = boot(sch, ev)
        M(f"ci{keyname[sch]}{ev.capitalize()}", f"[{lo:.3f},\\,{hi:.3f}]")
worst = ncos.sort_values("ratio").iloc[-1]
M("cosWorstN", int(worst["n"]), "{:d}")
M("cosWorstShare", 100 * worst["share"], "{:.0f}")
M("cosWorstEvent", str(worst["event"]))
big = ncos[ncos.n >= 5]
M("cosReweightMaxNfive", big[big.event == "reweight"]["ratio"].max(), "{:.3f}")
M("cosRemoveMaxNfive", big[big.event == "remove"]["ratio"].max(), "{:.3f}")

# ------------------------------------------------------------------ retry demo
R = pd.read_csv(f"{OUT}/retry_demo.csv")
rows = [[r["scenario"].replace("%", "\\%"), int(r["n"]), int(r["k"]), f"{r['optimum']:.4f}", f"{r['ceph_ratio']:.3f}", f"{r['retry_model_ratio']:.3f}",
         f"{r['single_order_ratio']:.3f}"] for _, r in R.iterrows()]
write_table("retry_demo", ["event", "$n$", "$k$", "bound", "Ceph mapper", "retry model", "single order"], rows, "lrrrrrr")
addrm = R[R.scenario.str.contains("add|remove")]
rew = R[~R.scenario.str.contains("add|remove")]
M("retryAddMinPct", 100 * (addrm["ceph_ratio"].min() - 1), "{:.0f}")
M("retryAddMaxPct", 100 * (addrm["ceph_ratio"].max() - 1), "{:.0f}")
M("retryRewMinPct", 100 * (rew["ceph_ratio"].min() - 1), "{:.0f}")
M("retryRewMaxPct", 100 * (rew["ceph_ratio"].max() - 1), "{:.0f}")
M("retrySingleMaxDev", up((R["single_order_ratio"] - 1).abs().max(), 3))
M("retryModelMaxDev", up((R["retry_model_ratio"] - R["ceph_ratio"]).abs().max(), 3))
M("retryKeys", thousands(2_000_000))
dach = R[R.scenario.str.contains("two replicas")]
if len(dach):
    r0 = float(dach["ceph_ratio"].iloc[0])
    M("dacharyRatio", r0, "{:.3f}")
    M("dacharyOldPct", 100 * (1 - 1 / r0), "{:.1f}")

# ------------------------------------------------------------------ theory tables
T = json.load(open(f"{OUT}/theory_checks.json"))
rows = []
Bc = {b["k"]: b for b in T["B_cyclic"]}
Dc = {d["k"]: d for d in T["D_price_of_fairness"]["closed"]}
for a in T["A_rectangle"]:
    k = a["k"]
    b = Bc[k]
    rows.append([k, f"{a['bound_sup']:.4f}", f"{b['cyclic_bound']:.4f}", f"{b['straw2_err']:.3f}", f"{b['priority_err']:.3f}",
                 f"{Dc[k]['ratio_lower_bound']:.4f}"])
write_table("bounds", ["$k$", "$\\frac{1}{4k(2k-1)}$", "$\\delta_k$", "exp.\\ race", "priority", "$1+\\frac{1}{4k^2-3k+1}$"], rows, "rrrrrr")
C = T["C_one_swap"]
M("swapKeys", thousands(C["keys"]))
M("swapRetryViol", thousands(C["retry_violations"]))
M("lpFour", T["D_price_of_fairness"]["lp_4corner"], "{:.6f}")
M("lpNine", T["D_price_of_fairness"]["lp_3x3"], "{:.6f}")
cr = {d["k"]: d for d in T["D_price_of_fairness"]["cos_rectangle"]}
M("cosRectTwo", cr[2]["cos_max_ratio"], "{:.3f}")
M("cosRectThree", cr[3]["cos_max_ratio"], "{:.3f}")
E = T["E_laplacian_vs_mc"]
M("lapMaxDiff", max(abs(e["predicted_ratio"] - e["mc_ratio"]) for e in E), "{:.3f}")
M("lapCases", len(E), "{:d}")
M("cornerLast", T["F_corner_limit"]["values"][-1]["ratio"], "{:.3f}")

# ------------------------------------------------------------------ minimax LP (n=3,k=2)
L = json.load(open(f"{OUT}/lp_minimax_n3.json"))
PHI = (1 + 5 ** 0.5) / 2
rows = []
for r in L["lp"]:
    gold = abs(r["R"] - PHI ** 3) < 1e-9
    rows.append([("$\\varphi^3$" if gold else f"{r['R']:.0f}"), r["G"], r["n_test"], thousands(r["n_atoms"]),
                 f"{r['delta_primal']:.6f}", f"{r['delta_certified']:.6f}", r["cert_support"]])
write_table("minimax_lp", ["max ratio $R$", "grid", "test conf.", "atoms", "primal", "certified dual", "support"], rows, "rrrrrrr")
gold = [r for r in L["lp"] if abs(r["R"] - PHI ** 3) < 1e-9]
M("lpGoldTests", max(r["n_test"] for r in gold), "{:d}")
M("lpGoldAtoms", thousands(max(r["n_atoms"] for r in gold)))
M("lpGoldGap", sci(max(abs(r["delta_primal"] - L["cyclic_bound"]) for r in gold)))
M("deltaTwo", L["cyclic_bound"], "{:.4f}")
other = [r for r in L["lp"] if abs(r["R"] - PHI ** 3) >= 1e-9]
M("lpOtherValue", max(r["delta_primal"] for r in other), "{:.4f}")
# exact worst-case errors of concrete rules on the finest golden test set
t = np.linspace(-3 * np.log(PHI), 3 * np.log(PHI), 25)
worst_err = {"exp": 0.0, "uniform": 0.0, ("frechet", 1.25): 0.0, ("frechet", 1.5): 0.0}
ntest = 0
for a in t:
    for b in t:
        w = np.array([np.exp(a), np.exp(b), 1.0])
        p = w / w.sum()
        if p.max() > 0.5 + 1e-12:
            continue
        ntest += 1
        for sh in worst_err:
            worst_err[sh] = max(worst_err[sh], float(np.abs(inclusion(w, 2, sh) - 2 * p).max()))
assert ntest == max(r["n_test"] for r in gold), (ntest, [r["n_test"] for r in gold])
M("errExp", worst_err["exp"], "{:.3f}")
M("errPriority", worst_err["uniform"], "{:.3f}")
M("errPowA", worst_err[("frechet", 1.25)], "{:.3f}")
M("errPowB", worst_err[("frechet", 1.5)], "{:.3f}")
M("errExpOverDelta", worst_err["exp"] / L["cyclic_bound"], "{:.1f}")

# the example of the 2017 mailing-list message and a second textbook example
for nm, w, k in (("Weil", [99, 99, 99, 99, 4], 2), ("Five", [10, 10, 10, 5, 5], 3)):
    w = np.array(w, float)
    lam, _ = calibrate(w, k, "exp")
    r = (lam[0] / w[0]) / (lam[-1] / w[-1])
    M(f"alpha{nm}", 1 + np.log(r) / np.log(w[0] / w[-1]), "{:.2f}")
    ps, pf = inclusion(w, k, "exp"), target_inclusion(w, k)
    M(f"ex{nm}Small", 100 * ps[-1] / k, "{:.2f}")
    M(f"ex{nm}SmallFair", 100 * pf[-1] / k, "{:.2f}")
    M(f"ex{nm}Over", 100 * (ps[-1] / pf[-1] - 1), "{:.0f}")
    if nm == "Weil":
        M("exWeilCount", thousands(40e6 * ps[-1]))
        M("exWeilCountFair", thousands(40e6 * pf[-1]))
        M("exWeilSecond", thousands(40e6 * (ps[-1] - w[-1] / w.sum())))
w3 = np.array([2.0, 1.0, 1.0])
M("exTwoOneOneMiss", 1 - inclusion(w3, 2, "exp")[0], "{:.4f}")

# ------------------------------------------------------------------ COS differential adaptivity
H = pd.read_csv(f"{OUT}/rho_hier.csv")
rows = []
for k, g in H.groupby("k"):
    g = g.sort_values("g", ascending=False)
    fr = Fraction(g["T_k"].iloc[0])
    rows.append([k, f"${fr.numerator}/{fr.denominator}$", f"{float(fr):.5f}"] + [f"{v:.5f}" for v in g["rho_lightest_fine"]])
write_table("rho_hier", ["$k$", "$T_k$", "", "$g=10^{-2}$", "$10^{-3}$", "$10^{-4}$", "$10^{-5}$"], rows, "rrrrrrr")
last = H[H.g == H.g.min()]
M("hierMaxGap", float((last["rho_lightest_fine"] - last["T_k_float"]).abs().max()), "{:.5f}")
M("hierKmax", int(H["k"].max()), "{:d}")
Fm = pd.read_csv(f"{OUT}/rho_fmu.csv")
M("fmuMax", float(Fm["f_mu"].iloc[-1]), "{:.4f}")
M("fmuArg", float(Fm["mu"].iloc[-1]), "{:.3f}")
M("fmuMaxDiff", sci_up(float((Fm["f_mu"] - Fm["rho_exact"]).abs().max())))
M("fmuValues", int((Fm["mu"] < 1).sum()), "{:d}")
parts = [pd.read_csv(p) for p in sorted(glob.glob(f"{OUT}/rho_margin_*.csv"))]
if parts:
    S = pd.concat(parts)
    S["val"] = S["sup_rho_fine"].astype(float)
    piv = S.groupby(["n", "k", "margin"])["val"].max().unstack("margin")
    free = None
    fp = [pd.read_csv(p) for p in sorted(glob.glob(f"{OUT}/rho_free_*.csv"))]
    if fp:
        free = pd.concat(fp).groupby(["n", "k"])["sup_rho_fine"].max()
    margins = sorted(piv.columns, reverse=True)
    rows = []
    for (n, k), r in piv.iterrows():
        row = [n, k] + [("--" if np.isnan(r[m]) else f"{r[m]:.3f}") for m in margins]
        if free is not None:
            row += [f"{free[(n, k)]:.3f}" if (n, k) in free.index else "--",
                        (f"{float(Fraction(1) + Fraction(k - 1, 2 * k) + Fraction(k + 1, k) * (sum(Fraction(1, m) for m in range(1, k + 2)) - Fraction(3, 2))):.3f}"
                         if n >= k + 2 else "--")]
        rows.append(row)
    hdr = ["$n$", "$k$"] + [f"margin {100*m:g}\\%" for m in margins] + (["no margin", "$T_k$"] if free is not None else [])
    write_table("rho", hdr, rows, "rr" + "r" * (len(hdr) - 2))
    M("rhoMarginTen", piv[0.1].max(), "{:.2f}")
    M("rhoMarginOne", piv[0.01].max(), "{:.2f}")
    M("rhoMarginMilli", piv[0.001].max(), "{:.2f}")
    M("rhoTested", thousands(S["tested"].sum() + (pd.concat(fp)["tested"].sum() if fp else 0)))
    if free is not None:
        ex = [(n, k, v) for (n, k), v in free.items()]
        M("rhoFreeMaxKtwo", max(v for n, k, v in ex if k == 2), "{:.3f}")
        over = [v - float(Fraction(1) + Fraction(k - 1, 2 * k) + Fraction(k + 1, k) * (sum(Fraction(1, m) for m in range(1, k + 2)) - Fraction(3, 2))) for n, k, v in ex]
        M("rhoFreeExcess", max(over), "{:.3f}")

# ------------------------------------------------------------------ implementation
I = pd.read_csv(f"{OUT}/impl_distribution.csv")
M("implRows", len(I), "{:d}")
M("implRawZ", I["raw_max_abs_z"].max(), "{:.2f}")
M("implCalZ", I["cal_max_abs_z"].max(), "{:.2f}")
M("implCalRel", up(I["cal_max_rel_err_pct"].max(), 2))
M("implRemoveMax", I["remove_largest_ratio"].max(), "{:.3f}")
M("implKeys", thousands(I["keys"].iloc[0]))
M("implBonferroniZ", float(stats.norm.ppf(1 - 0.05 / (2 * 2 * int(I["n"].sum())))), "{:.2f}")
Tm = pd.read_csv(f"{OUT}/impl_timing.csv")
Ct = pd.read_csv(f"{OUT}/calibration_timing.csv")
rows = [[int(a["n"]), f"{a['crush_do_rule_ns']:.0f}", f"{a['single_order_ns']:.0f}", f"{a['speedup']:.1f}",
         f"{c['seconds_median']:.2f}", f"{c['iters_median']:.0f}", sci(c["max_abs_err"])]
        for (_, a), (_, c) in zip(Tm.iterrows(), Ct.iterrows())]
write_table("impl", ["$n$", "\\texttt{crush\\_do\\_rule} (ns)", "single order (ns)", "speed-up", "calibration (s)", "iterations", "max err."],
            rows, "rrrrrrr")
M("speedMin", Tm["speedup"].min(), "{:.1f}")
M("speedMax", Tm["speedup"].max(), "{:.1f}")
M("calSecTen", float(Ct[Ct.n == 10]["seconds_median"].iloc[0]), "{:.2f}")
M("calSecMax", Ct["seconds_median"].max(), "{:.0f}")
M("calNmax", int(Ct["n"].max()), "{:d}")

# ------------------------------------------------------------------ synthetic sweep
if os.path.exists(f"{OUT}/sweep_fairness.csv"):
    SF = pd.read_csv(f"{OUT}/sweep_fairness.csv")
    SM = pd.read_csv(f"{OUT}/sweep_movement.csv")
    SM = SM[SM.opt_fair > 1e-3].copy()
    SM["capped"] = SM["pmax"] >= CAP
    rows = []
    for fam, g in SF.groupby("family", sort=False):
        mm = SM[SM.family == fam]
        cosr = mm[mm.scheme == "cos"]["ratio"]
        rcal = mm[(mm.scheme == "retry+cal") & ~mm.capped]["ratio"]
        piv_ = mm[mm.scheme == "pivotal"]["ratio"]
        rows.append([fam.replace("x", "$\\times$") if "(3x)" in fam else fam, len(g), f"{g['straw2_over_pct'].median():.1f}", f"{g['straw2_over_pct'].max():.1f}",
                     f"{g['priority_over_pct'].max():.1f}", sci(g["cal_err"].max()),
                     f"{cosr.median():.3f}", f"{cosr.max():.3f}", f"{rcal.median():.3f}", f"{piv_.median():.2f}"])
    write_table("sweep", ["weight family", "cases", "med.", "max", "max", "resid.", "med.", "max", "med.", "med."],
                rows, "lrrrrrrrrr",
                pre="& & \\multicolumn{2}{c}{successive} & priority & \\multicolumn{3}{c}{COS} & retry+cal & pivotal \\\\ "
                    "\\cmidrule(lr){3-4}\\cmidrule(lr){5-5}\\cmidrule(lr){6-8}\\cmidrule(lr){9-9}\\cmidrule(lr){10-10}")
    M("sweepCases", len(SF), "{:d}")
    SC = pd.read_csv(f"{OUT}/sweep_calibration.csv")
    assert len(SC) == len(SF), "sweep_calibration.csv does not match the sweep"
    assert SC["err"].max() < 1e-8
    fb = SC[SC.method == "newton"]
    M("sweepFallback", len(fb), "{:d}")
    fpc = SC[(SC.method == "fixed-point") & (SC.fp_status == "converged")]
    M("calFpMedian", int(fpc.fp_iters.median()), "{:d}")
    M("calFpMax", int(fpc.fp_iters.max()), "{:d}")
    if len(fb):
        ks = sorted(set(int(x) for x in fb.k))
        kdesc = (f"all with $k={ks[0]}$" if len(ks) == 1 else "with $k\\in\\{" + ",".join(map(str, ks)) + "\\}$")
        nnf = int((fb.fp_status == "non-finite").sum())
        if nnf == 0:
            how = "in each it had not converged after $60$ steps"
        elif nnf == len(fb):
            how = "in each it produced non-finite values"
        else:
            how = (f"it produced non-finite values in {nnf} and had not converged after $60$ steps in "
                   f"{len(fb) - nnf}")
        M("sweepFallbackWhat", f"{kdesc} and a largest target of at least "
          f"${np.floor(fb.pmax.min() * 100) / 100:.2f}$; {how}")
    else:
        M("sweepFallbackWhat", "none")
    assert SF["cal_err"].max() < 1e-8, "a calibration of the sweep did not converge"
    M("sweepCosMax", SM[SM.scheme == "cos"]["ratio"].max(), "{:.2f}")
    M("sweepCosMedian", SM[SM.scheme == "cos"]["ratio"].median(), "{:.3f}")
    M("sweepOverMax", SF["straw2_over_pct"].max(), "{:.0f}")
    M("sweepCalErr", sci_up(SF["cal_err"].max()))
    bigc = SF[SF.n >= 24]
    M("sweepOverLargeN", bigc[bigc.k == 3]["straw2_over_pct"].max(), "{:.1f}")
    M("sweepNmax", int(SF["n"].max()), "{:d}")
    M("sweepCapped", int((SF["pmax"] >= CAP).sum()), "{:d}")
    wr = SM[SM.scheme == "cos"].sort_values("ratio").iloc[-1]
    M("sweepCosWorstFam", str(wr["family"]).replace("x)", "$\\times$)"))
    M("sweepCosWorstN", int(wr["n"]), "{:d}")
    M("sweepCosWorstK", int(wr["k"]), "{:d}")
    M("sweepCosWorstEvent", str(wr["event"]).replace("x1.25", "by $1.25$"))
    M("sweepCosWorstWhere", "an event in which a node is at its cap" if bool(wr["capped"])
      else "an event without capped nodes")
    nc = SM[(SM.scheme == "cos") & ~SM.capped]
    M("sweepCosMaxUncapped", nc["ratio"].max(), "{:.2f}")

# ------------------------------------------------------------------ frontier
Fr = pd.read_csv(f"{OUT}/frontier.csv")
h = Fr[Fr.theta == 0.5].set_index("config")
z = Fr[Fr.theta == 0.0].set_index("config")
o = Fr[Fr.theta == 1.0].set_index("config")
M("frontHalfOverShare", 100 * (h["max_overfill_pct"] / z["max_overfill_pct"]).mean(), "{:.0f}")
M("frontHalfMoveShare", 100 * (h["excess_reweight_mean"] / o["excess_reweight_mean"]).mean(), "{:.0f}")
M("frontFullRemoveMaxPct", 100 * o["excess_remove_mean"].max(), "{:.1f}")
M("frontFullReweightMaxPct", 100 * o["excess_reweight_mean"].max(), "{:.1f}")
M("frontKeys", thousands(1_000_000))

# ------------------------------------------------------------------ Redundant Share (two copies)
for ev, nm in (("remove", "Remove"), ("reweight", "Reweight")):
    d = RSm[RSm.event == ev]
    M(f"rs{nm}Median", d["rs_ratio"].median(), "{:.2f}")
    M(f"rs{nm}Ninety", d["rs_ratio"].quantile(.9), "{:.2f}")
    M(f"rs{nm}Max", d["rs_ratio"].max(), "{:.2f}")
    M(f"rs{nm}Events", len(d), "{:d}")
    c = Mv[(Mv.scheme == "cos") & (Mv.k == 2) & (Mv.event == ev)][["config", "node", "ratio"]]
    j = d.merge(c, on=["config", "node"])
    assert len(j) == len(d), "Redundant Share events do not match the corpus events"
    M(f"cosKtwo{nm}Median", j["ratio"].median(), "{:.3f}")
    M(f"cosKtwo{nm}Max", j["ratio"].max(), "{:.2f}")
    M(f"rsWorse{nm}", int((j["rs_ratio"] > j["ratio"]).sum()), "{:d}")
    agg = j.groupby("config")[["rs_ratio", "ratio"]].mean()
    M(f"rsTest{nm}P", sci_up(stats.wilcoxon(agg["ratio"], agg["rs_ratio"], alternative="less").pvalue).strip("$"))
    M(f"rsPairs{nm}", len(agg), "{:d}")
_rr = RSm[RSm.event == "remove"]
M("rsAboveLn", int((_rr.rs_ratio > np.log(_rr.n)).sum()), "{:d}")
_wrs = _rr.sort_values("rs_ratio").iloc[-1]
M("rsWorstRemoveN", int(_wrs.n), "{:d}")
M("rsWorstRemoveLn", float(np.log(_wrs.n)), "{:.2f}")
from fsp import redshare as _RS       # noqa: E402
_W = {c["id"]: np.array(c["weights"], float) for c in used}
_errs = []
for (cfg, ev, node), _ in RSm.groupby(["config", "event", "node"]):
    w0 = _W[cfg]
    w1 = w0.copy()
    w1[int(node)] = 0.0 if ev == "remove" else w0[int(node)] * 1.25
    _errs += [_RS.check_fair(w0, 2), _RS.check_fair(w1, 2)]
M("rsMaxFairErr", sci_up(max(max(_errs), 1e-16)))
# ------------------------------------------------------------------ cost of correcting the bias with exception tables
cern3 = F[(F.k == 3) & F["config"].map(lambda c: NAME[c][0] in ("beesly", "gabe", "osdmap"))]
M("misCernMin", cern3["straw2_misplaced_pct"].min(), "{:.2f}")
M("misCernMax", cern3["straw2_misplaced_pct"].max(), "{:.2f}")
M("pgExample", thousands(4096))
M("upmapMin", int(np.floor(cern3["straw2_misplaced_pct"].min() / 100 * 4096 * 3)), "{:d}")
M("upmapMax", int(np.ceil(cern3["straw2_misplaced_pct"].max() / 100 * 4096 * 3)), "{:d}")
M("misAllMax", F["straw2_misplaced_pct"].max(), "{:.1f}")
# ------------------------------------------------------------------ Monte Carlo uncertainty of the movement ratios
cse = Mv[Mv.scheme == "cos"]
M("cosSeMedian", cse["se_ratio"].median(), "{:.3f}")
M("cosSeMax", up(cse["se_ratio"].max(), 3))
M("cosExcessWithinTwoSePct", 100 * ((cse["ratio"] - 1) < 2 * cse["se_ratio"]).mean(), "{:.0f}")
_tk = Mv[Mv.scheme == "topk"]
M("topkMaxZ", up(float(((_tk["ratio"] - 1).abs() / _tk["se_ratio"]).max()), 1))
# ------------------------------------------------------------------ numerical checks quoted in the text
TC = json.load(open(f"{OUT}/theory_checks.json"))
lap = TC["E_laplacian_vs_mc"]
M("lapMcCases", len(lap), "{:d}")
M("lapMcMaxDiff", up(max(abs(r["predicted_ratio"] - r["mc_ratio"]) for r in lap), 3))
cv = TC["F_corner_limit"]["values"][-1]
M("cornerEps", f"{cv['eps']:g}")
M("cornerRatio", cv["ratio"], "{:.3f}")
M("oneSwapKeys", thousands(TC["C_one_swap"]["keys"]))
M("oneSwapRetry", thousands(TC["C_one_swap"]["retry_violations"]))
Hh = pd.read_csv(f"{OUT}/rho_hier.csv")
from fractions import Fraction


def Tk_exact(k):
    H = sum(Fraction(1, r) for r in range(1, k + 2))
    return 1 + Fraction(k - 1, 2 * k) + Fraction(k + 1, k) * (H - Fraction(3, 2))


hh = Hh[np.isclose(Hh["g"], 1e-5)]
col = "rho_lightest_fine" if "rho_lightest_fine" in hh else "rho_lightest"
M("rhoHierMaxDiff", sci_up(max(abs(float(r[col]) - float(Tk_exact(int(r["k"])))) for _, r in hh.iterrows())))
M("rhoHierKmax", int(Hh["k"].max()), "{:d}")
# ------------------------------------------------------------------ corpus facts derived from the maps
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import crushmap as CMAP          # noqa: E402
from fsp.paths import RAW                  # noqa: E402


def bucket_counts(path):
    cm = CMAP.load(path)
    real = [b for b in cm.buckets.values() if "~" not in b.name]
    cnt = {t: sum(1 for b in real if b.type == t) for t in ("host", "rack", "room")}
    cnt["devices"] = len(cm.devices)
    cnt["rooms"] = sorted(b.name for b in real if b.type == "room")
    return cnt


bc = bucket_counts(f"{RAW}/ceph/src/test/cli/crushtool/crush-classes/beesly")
oc = bucket_counts(f"{RAW}/ceph/src/test/compressor/osdmaps/osdmap.2982809")
M("beeslyDevices", thousands(bc["devices"]))
M("beeslyHosts", bc["host"], "{:d}")
M("beeslyRacks", bc["rack"], "{:d}")
M("beeslyRooms", bc["room"], "{:d}")
M("osdDevices", thousands(oc["devices"]))
M("osdHosts", oc["host"], "{:d}")
M("osdRacks", oc["rack"], "{:d}")
M("osdSameRooms", "the same" if bc["rooms"] == oc["rooms"] else "different")
M("roomNames", ", ".join("\\texttt{" + r + "}" for r in bc["rooms"]))

with open(f"{ROOT}/paper/numbers.tex", "w") as f:
    for k, v in sorted(macros.items()):
        f.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
print("macros:", len(macros))
