"""Numerical verification of every theorem / proposition in the paper.

 A  rectangle inequality (Thm 1):  Delta_k = 1/(k(2k-1)); stable rules satisfy
    P(d)-P(b)-P(c)+P(a) >= 0, the fair target gives -Delta_k.
 B  cyclic inequality (Thm 2, scale-invariant stable rules, n = k+1).
 C  one-swap stability: holds for generalized order sampling (any joint law of
    the talents), fails for the CRUSH retry coupling.
 D  price of fairness (Thm 3): closed forms, Monte Carlo excess of the
    calibrated rule on the rectangle, and LP lower bounds from finite
    configuration sets (n=3, k=2).
 E  Laplacian (electrical-flow) formula for COS vs Monte Carlo.
 F  corner limit 8/5 of the COS differential ratio (n=3, k=2).
Writes out/theory_checks.json; every block also asserts its claim.
"""
import itertools
import json
import os
import sys

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.calib import calibrate                      # noqa: E402
from fsp.core import inclusion, target_inclusion     # noqa: E402
from fsp.designs import retry_sets                   # noqa: E402
from fsp.laplacian import cos_differential_ratio     # noqa: E402
from fsp.movement import draws, moved, topk_sets     # noqa: E402

from fsp.paths import OUT as _OUTDIR   # noqa: E402
OUT = _OUTDIR + "/theory_checks.json"
res = {}
RULES = {"straw2": "exp", "priority": "uniform", "power1.5": ("frechet", 1.5)}

# ---------------------------------------------------------------- A
A = []
for k in range(2, 7):
    n = k + 1
    h = k / (2 * (k - 1))
    base = np.ones(n)
    base[1] = base[2] = 0.5
    corners = {}
    for name, (d2, d3) in dict(a=(0, 0), b=(h, 0), c=(0, h), d=(h, h)).items():
        w = base.copy()
        w[1] += d2
        w[2] += d3
        assert w.max() <= w.sum() / k + 1e-12, "corner must be uncapped"
        corners[name] = w
    fair = {c: 1 - target_inclusion(w, k)[0] for c, w in corners.items()}
    delta = fair["b"] + fair["c"] - fair["a"] - fair["d"]
    assert abs(delta - 1 / (k * (2 * k - 1))) < 1e-12
    row = dict(k=k, n=n, h=h, Delta=delta, closed_form=1 / (k * (2 * k - 1)), bound_sup=delta / 4)
    for rn, shape in RULES.items():
        ex = {c: 1 - inclusion(w, k, shape)[0] for c, w in corners.items()}
        S = ex["d"] - ex["b"] - ex["c"] + ex["a"]
        err = max(abs(ex[c] - fair[c]) for c in corners)
        assert S >= -1e-9 and err >= delta / 4 - 1e-9
        row[f"{rn}_rect"] = S
        row[f"{rn}_maxerr"] = err
    A.append(row)
res["A_rectangle"] = A

# ---------------------------------------------------------------- B
B = []
for k in range(2, 9):
    n = k + 1
    c = (1 + np.sqrt(1 + k * k)) / k if k % 2 == 0 else (2 + np.sqrt(k * k + 3)) / (k + 1)
    sig = np.zeros(n)
    for d in range(1, (n - 1) // 2 + 1):
        sig[d] = np.log(c)
        sig[n - d] = -np.log(c)
    wts = np.exp(sig)
    S = wts.sum()
    assert abs(S - k * c) < 1e-9 and wts.max() <= S / k + 1e-12
    bound = k / n - k / S
    assert abs(bound - (k / (k + 1) - 1 / c)) < 1e-12
    row = dict(k=k, n=n, c=c, S=S, cyclic_bound=bound, rectangle_bound=1 / (4 * k * (2 * k - 1)))
    for rn, shape in RULES.items():
        probs = []
        for i in range(n):
            x = np.array([wts[(j - i) % n] for j in range(n)])       # x^{(i)}_j = exp(sigma(j-i))
            probs.append(1 - inclusion(x, k, shape)[i])
        tot = float(np.sum(probs))
        fair_i = 1 - k / S
        assert tot <= 1 + 1e-7, (k, rn, tot)
        row[f"{rn}_sumP"] = tot
        row[f"{rn}_err"] = fair_i - min(probs)
        assert row[f"{rn}_err"] >= bound - 1e-7
    B.append(row)
res["B_cyclic"] = B
res["B_golden"] = dict(value=(7 - 3 * np.sqrt(5)) / 6, matches_k2=abs(B[0]["cyclic_bound"] - (7 - 3 * np.sqrt(5)) / 6) < 1e-12)

# ---------------------------------------------------------------- C
rng = np.random.default_rng(42)
viol_gos = viol_retry = trials = 0
for rep in range(40):
    n = int(rng.integers(3, 9))
    k = int(rng.integers(1, n))
    m = 50_000
    # dependent talents: T = exp(correlated Gaussian + heavy-tailed common shocks)
    Lc = rng.normal(size=(n, n)) * rng.uniform(0.2, 1.5)
    Z = rng.normal(size=(m, n)) @ Lc.T + rng.standard_t(3, size=(m, 1)) * rng.normal(size=(1, n))
    T = np.exp(Z)
    w = np.exp(rng.normal(0, 1, n))
    j = int(rng.integers(n))
    w2 = w.copy()
    w2[j] *= np.exp(abs(rng.normal(0, 1)) + 0.05)

    def top(wv):
        s = wv[None, :] * T
        idx = np.argpartition(-s, k - 1, axis=1)[:, :k]
        mem = np.zeros((m, n), bool)
        np.put_along_axis(mem, idx, True, axis=1)
        return mem
    Ra, Rb = top(w), top(w2)
    entered = Rb & ~Ra
    left = Ra & ~Rb
    bad = entered.copy()
    bad[:, j] = False
    viol_gos += int(bad.any(axis=1).sum() + left[:, j].sum())
    if k >= 2:
        Qa, Qb = retry_sets(w, m, k, seed=rep), retry_sets(w2, m, k, seed=rep)
        e2 = Qb & ~Qa
        e2[:, j] = False
        viol_retry += int(e2.any(axis=1).sum())
    trials += m
assert viol_gos == 0 and viol_retry > 0
res["C_one_swap"] = dict(keys=trials, gos_violations=viol_gos, retry_violations=viol_retry)

# ---------------------------------------------------------------- D
D = dict(closed=[], cos_rectangle=[])
for k in range(2, 7):
    n = k + 1
    h = k / (2 * (k - 1))
    base = np.ones(n)
    base[1] = base[2] = 0.5
    cfg = {}
    for name, (d2, d3) in dict(a=(0, 0), b=(h, 0), c=(0, h), d=(h, h)).items():
        w = base.copy()
        w[1] += d2
        w[2] += d3
        cfg[name] = w
    edges = [("a", "b"), ("a", "c"), ("b", "d"), ("c", "d")]
    opt = {e: float(np.clip(target_inclusion(cfg[e[1]], k) - target_inclusion(cfg[e[0]], k), 0, None).sum()) for e in edges}
    sopt = sum(opt.values())
    assert abs(sopt - (4 * k * k - 3 * k + 1) / (k * (2 * k - 1))) < 1e-9
    D["closed"].append(dict(k=k, sum_opt=sopt, Delta=1 / (k * (2 * k - 1)), ratio_lower_bound=1 + 1 / (4 * k * k - 3 * k + 1)))
    if k <= 4:
        m = 2_000_000
        U = draws(m, n, seed=100 + k)
        sets = {}
        for name, w in cfg.items():
            lam, alw = calibrate(w, k, "exp")
            sets[name] = topk_sets(lam, U, k)
        mv = {e: moved(sets[e[0]], sets[e[1]]) for e in edges}
        excess = sum(mv[e] - opt[e] for e in edges)
        assert excess >= 1 / (k * (2 * k - 1)) - 5e-3
        D["cos_rectangle"].append(dict(k=k, cos_excess_sum=excess, required_min=1 / (k * (2 * k - 1)),
                                       cos_max_ratio=max(mv[e] / opt[e] for e in edges)))


def fairness_movement_lp(points, edges):
    """n=3,k=2.  points: list of weight triples; edges: list of (i, j) index
    pairs differing in one coordinate.  Variables: joint law of the excluded
    node at every point (3^P atoms) with exactly fair marginals; minimise the
    largest movement / optimum over the edges."""
    P = len(points)
    tau = np.array([1 - target_inclusion(np.array(p, float), 2) for p in points])
    atoms = np.array(list(itertools.product(range(3), repeat=P)), dtype=np.int8)
    N = len(atoms)
    Aeq = lil_matrix((P * 3 + 1, N + 1))
    beq = np.zeros(P * 3 + 1)
    for p in range(P):
        for v in range(3):
            Aeq[p * 3 + v, np.nonzero(atoms[:, p] == v)[0]] = 1.0
            beq[p * 3 + v] = tau[p, v]
    Aeq[P * 3, :N] = 1.0
    beq[P * 3] = 1.0
    Aub = lil_matrix((len(edges), N + 1))
    for r, (i, j) in enumerate(edges):
        opt = float(np.clip((1 - tau[j]) - (1 - tau[i]), 0, None).sum())
        Aub[r, np.nonzero(atoms[:, i] != atoms[:, j])[0]] = 1.0
        Aub[r, N] = -opt
    c = np.zeros(N + 1)
    c[N] = 1.0
    r = linprog(c, A_ub=Aub.tocsr(), b_ub=np.zeros(len(edges)), A_eq=Aeq.tocsr(), b_eq=beq,
                bounds=[(0, None)] * (N + 1), method="highs")
    return float(r.fun)


x = y = 0.5
h = 1.0
pts4 = [(1, x, y), (1, x + h, y), (1, x, y + h), (1, x + h, y + h)]
D["lp_4corner"] = fairness_movement_lp(pts4, [(0, 1), (0, 2), (1, 3), (2, 3)])
assert D["lp_4corner"] >= 12 / 11 - 1e-7
g = [x, x + h / 2, x + h]
pts9 = [(1, a, b) for a in g for b in g]
idx = lambda ia, ib: ia * 3 + ib
e9 = [(idx(ia, ib), idx(ia + 1, ib)) for ia in range(2) for ib in range(3)] + \
     [(idx(ia, ib), idx(ia, ib + 1)) for ia in range(3) for ib in range(2)]
D["lp_3x3"] = fairness_movement_lp(pts9, e9)
res["D_price_of_fairness"] = D

# ---------------------------------------------------------------- E
E = []
for w, k, j in [([4, 3, 2, 1, 2, 3], 3, 2), ([3, 3, 2, 2, 2, 1, 1, 1, 1, 2], 3, 9), ([5, 4, 4, 3], 2, 3)]:
    w = np.array(w, float)
    ratio, excess, opt = cos_differential_ratio(w, k, j)
    eps = 0.02
    w2 = w.copy()
    w2[j] *= np.exp(eps)
    m = 4_000_000
    U = draws(m, len(w), seed=11)
    la, _ = calibrate(w, k, "exp")
    lb, _ = calibrate(w2, k, "exp")
    mc = moved(topk_sets(la, U, k), topk_sets(lb, U, k))
    opt_fin = float(np.clip(target_inclusion(w2, k) - target_inclusion(w, k), 0, None).sum())
    E.append(dict(w=w.tolist(), k=k, j=j, predicted_ratio=ratio, mc_ratio=mc / opt_fin,
                  mc_se_ratio=float(np.sqrt(mc / m) / opt_fin)))
    assert abs(ratio - mc / opt_fin) < 0.03
res["E_laplacian_vs_mc"] = E

# ---------------------------------------------------------------- F
F = []
for eps in (0.05, 0.02, 0.01, 0.005):
    w = np.array([1.0, eps, 1.0])
    r, _, _ = cos_differential_ratio(w, 2, 0)
    F.append(dict(eps=eps, ratio=r))
res["F_corner_limit"] = dict(values=F, limit=8 / 5)

json.dump(res, open(OUT, "w"), indent=1, default=float)
print(json.dumps({k: (v if k not in ("A_rectangle", "B_cyclic") else "...") for k, v in res.items()}, indent=1, default=float)[:2500])
for row in A:
    print("A", {k: (round(v, 5) if isinstance(v, float) else v) for k, v in row.items()})
for row in B:
    print("B", {k: (round(v, 5) if isinstance(v, float) else v) for k, v in row.items()})
