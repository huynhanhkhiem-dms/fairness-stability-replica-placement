"""Figures of the paper (vector PDF), drawn from out/*.csv.

  fig_tripod.pdf    schematic for n = 3, k = 2: tripod representation and the cyclic pinwheel
  fig_movement.pdf  adaptivity ratios of all rules on the corpus of real cluster maps
  fig_frontier.pdf  bias against extra movement when interpolating between the stable rule and COS
  fig_sweep.pdf     controlled sweep: bias of successive sampling and adaptivity of COS against n

Colour is used for identity only; every series also has its own marker or a direct label, so the
figures survive grey-scale printing.  Palette: first slots of a validated categorical palette
(checked for colour-vision-deficiency separation on a white surface).
"""
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Polygon

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.core import target_inclusion   # noqa: E402

from fsp.paths import ROOT   # noqa: E402
OUT = f"{ROOT}/out"
FIG = f"{ROOT}/paper/figs"
os.makedirs(FIG, exist_ok=True)

BLUE, ORANGE, AQUA, YELLOW, MAGENTA = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#c2409b"
INK, MUTED, GRID = "#1f1f1c", "#6b6a64", "#dcdbd5"
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "legend.fontsize": 8, "axes.edgecolor": MUTED, "axes.linewidth": 0.6, "xtick.color": MUTED, "ytick.color": MUTED,
    "text.color": INK, "axes.labelcolor": INK, "axes.spines.top": False, "axes.spines.right": False,
    "grid.color": GRID, "grid.linewidth": 0.5, "pdf.fonttype": 42, "savefig.bbox": "tight", "savefig.pad_inches": 0.03,
})


def tint(c, a=0.22):
    c = np.array(matplotlib.colors.to_rgb(c))
    return tuple(1 - a * (1 - c))


# ------------------------------------------------------------------------------------------ tripod
def fig_tripod():
    L = np.log((1 + 5 ** 0.5) / 2)
    R = 2.3
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 3.15))
    # (a) one apex: which node is left out, as a function of the configuration
    ax = axes[0]
    a0, b0 = -0.45, 0.35
    far = 10
    ax.add_patch(Polygon([(a0, b0), (a0, far), (far, far), (far, b0)], closed=True, fc=tint(AQUA), ec="none"))
    ax.add_patch(Polygon([(a0, b0), (a0, far), (-far, far), (-far, b0 - (far + a0))], closed=True, fc=tint(BLUE), ec="none"))
    ax.add_patch(Polygon([(a0, b0), (far, b0), (far, -far), (a0 - (far + b0), -far)], closed=True, fc=tint(ORANGE), ec="none"))
    for (dx, dy) in ((0, 1), (1, 0), (-1, -1)):
        ax.plot([a0, a0 + far * dx], [b0, b0 + far * dy], color=INK, lw=1.0, solid_capstyle="butt")
    ax.plot([a0], [b0], "o", color=INK, ms=4.5, zorder=5)
    ax.annotate(r"apex $-\log T$", (a0, b0), xytext=(7, -13), textcoords="offset points", fontsize=8.5)
    ax.text(1.0, 1.45, "node 3 left out", ha="center", fontsize=8.5)
    ax.text(-1.45, 1.0, "node 1\nleft out", ha="center", fontsize=8.5)
    ax.text(-0.75, -1.85, "node 2 left out", ha="center", fontsize=8.5)
    # directions of single-node changes
    o = (1.35, -0.95)
    for (dx, dy, lab, off) in ((0.55, 0, r"$w_1\!\uparrow$", (4, -3)), (0, 0.55, r"$w_2\!\uparrow$", (4, -2)), (-0.39, -0.39, r"$w_3\!\uparrow$", (-22, -9))):
        ax.annotate("", xy=(o[0] + dx, o[1] + dy), xytext=o, arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=0.8, shrinkA=0, shrinkB=0))
        ax.annotate(lab, (o[0] + dx, o[1] + dy), xytext=off, textcoords="offset points", fontsize=8, color=MUTED)
    ax.set_title("(a) a rule is a random apex", loc="left")
    # (b) the three cyclic configurations: where must the apex be for the middle node to be left out
    ax = axes[1]
    P1, P2, P3 = (L, 2 * L), (-2 * L, -L), (L, -L)
    ax.add_patch(Polygon([P3, (L, -far), (-far, -far), (-far, -L)], closed=True, fc=tint(AQUA), ec="none"))                 # A3: alpha<L, beta<-L
    ax.add_patch(Polygon([P1, (far, far + L), (far, -far), (L, -far)], closed=True, fc=tint(BLUE), ec="none"))               # A1: alpha>L, beta<alpha+L
    ax.add_patch(Polygon([P2, (-far, -L), (-far, far), (far - L, far)], closed=True, fc=tint(ORANGE), ec="none"))            # A2: beta>-L, beta>alpha+L
    ax.add_patch(Polygon([P1, P2, P3], closed=True, fc="white", ec="none"))
    ax.plot([L, L], [-far, 2 * L], color=INK, lw=1.0)
    ax.plot([-far, L], [-L, -L], color=INK, lw=1.0)
    ax.plot([-2 * L, far], [-L, far + L], color=INK, lw=1.0)
    for (pt, lab, off) in ((P1, r"$x^{(1)}$", (5, -3)), (P2, r"$x^{(2)}$", (-6, 6)), (P3, r"$x^{(3)}$", (5, 5))):
        ax.plot(*pt, "o", color=INK, ms=4.5, zorder=5)
        ax.annotate(lab, pt, xytext=off, textcoords="offset points", fontsize=9)
    ax.text(1.42, -0.2, r"$A_1$", ha="center", fontsize=10)
    ax.text(-1.1, 1.25, r"$A_2$", ha="center", fontsize=10)
    ax.text(-0.75, -1.65, r"$A_3$", ha="center", fontsize=10)
    ax.text(0.03, 0.02, "no $A_i$", ha="center", va="center", fontsize=8, color=MUTED)
    ax.set_title(r"(b) the events $A_1,A_2,A_3$ are disjoint", loc="left")
    for ax in axes:
        ax.set_xlim(-R, R)
        ax.set_ylim(-R, R)
        ax.set_aspect("equal")
        ax.set_xticks([-2, -1, 0, 1, 2])
        ax.set_yticks([-2, -1, 0, 1, 2])
        ax.set_xlabel(r"$\log (w_1/w_3)$")
        ax.tick_params(length=2.5)
    axes[0].set_ylabel(r"$\log (w_2/w_3)$")
    fig.tight_layout(w_pad=1.6)
    fig.savefig(f"{FIG}/fig_tripod.pdf")
    plt.close(fig)


# ------------------------------------------------------------------------------------------ corpus movement
def capped_flags(M):
    used = {c["id"]: np.array(c["weights"], float) for c in json.load(open(f"{OUT}/corpus_used.json"))}
    cache = {}

    def pmax(cfg, k, ev, i):
        key = (cfg, k, ev, i)
        if key not in cache:
            w = used[cfg]
            w2 = w.copy()
            w2[i] = 0.0 if ev == "remove" else w2[i] * 1.25
            a = target_inclusion(w, k).max()
            pos = w2 > 0
            b = 1.0 if pos.sum() <= k else target_inclusion(w2[pos], k).max()
            cache[key] = max(a, b)
        return cache[key]
    return np.array([pmax(c, int(k), e, int(i)) for c, k, e, i in zip(M["config"], M["k"], M["event"], M["node"])]) >= 0.999


def fig_movement():
    M = pd.read_csv(f"{OUT}/corpus_movement.csv")
    M = M[M.opt_fair > 1e-3].copy()
    M = M[~((M.event == "remove") & (M.n - 1 <= M.k))].copy()   # removals leaving k domains: see make_tables
    M["capped"] = capped_flags(M)
    rows = [("ceph", "CRUSH (Ceph mapper)", False), ("topk", "single-order top-$k$", True), None,
            ("ceph+cal", "CRUSH + exact weight set", False), ("cos", "COS", True),
            ("pivotal", "ordered pivotal", False), ("systematic", "systematic", False)]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.95), sharey=True)
    rng = np.random.default_rng(5)
    for ax, ev, title in zip(axes, ("remove", "reweight"), ("(a) node removed", r"(b) node reweighted by $1.25$")):
        y = 0
        yt, yl = [], []
        for r in rows:
            if r is None:
                y -= 0.55
                continue
            sch, lab, ours = r
            d = M[(M.scheme == sch) & (M.event == ev)]
            if sch == "ceph+cal":
                d = d[~d.capped]
            v = np.clip(d["ratio"].values, 0.985, None)
            col = BLUE if ours else MUTED
            ax.scatter(v, y + rng.uniform(-0.2, 0.2, len(v)), s=5, color=col, alpha=0.35, linewidths=0, zorder=2)
            q1, med, q3 = np.percentile(v, [25, 50, 75])
            ax.plot([q1, q3], [y - 0.36, y - 0.36], color=col, lw=2.2, solid_capstyle="butt", zorder=3)
            ax.plot([med, med], [y - 0.46, y - 0.26], color=INK, lw=1.2, zorder=4)
            ax.text(1.02, y, f"{med:.3f}", transform=ax.get_yaxis_transform(), va="center", ha="left", fontsize=7.5, color=INK)
            yt.append(y)
            yl.append(lab)
            y -= 1
        ax.set_xscale("log")
        ax.set_xlim(0.985, 12.5)
        ax.set_xticks([1, 1.5, 2, 3, 5, 10])
        ax.set_xticklabels(["1", "1.5", "2", "3", "5", "10"])
        ax.axhline(-1.78, color=MUTED, lw=0.5, ls=(0, (3, 2)), zorder=1)
        ax.minorticks_off()
        ax.axvline(1.0, color=MUTED, lw=0.6, zorder=1)
        ax.grid(axis="x", zorder=0)
        ax.set_yticks(yt)
        ax.set_yticklabels(yl)
        ax.tick_params(axis="y", length=0, labelcolor=INK)
        ax.tick_params(axis="x", length=2.5)
        ax.set_title(title, loc="left")
        ax.set_xlabel("movement / optimum")
        ax.text(1.02, 0.55, "median", transform=ax.get_yaxis_transform(), va="center", ha="left", fontsize=7.5, color=MUTED)
        ax.spines["left"].set_visible(False)
    fig.tight_layout(w_pad=2.4)
    fig.savefig(f"{FIG}/fig_movement.pdf")
    plt.close(fig)


# ------------------------------------------------------------------------------------------ frontier
def fig_frontier():
    F = pd.read_csv(f"{OUT}/frontier.csv")
    names = json.load(open(f"{OUT}/frontier_names.json")) if os.path.exists(f"{OUT}/frontier_names.json") else {}
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.7))
    cols = [BLUE, ORANGE, AQUA, YELLOW]
    marks = ["o", "s", "^", "D"]
    for ax, col, title in zip(axes, ("excess_remove_mean", "excess_reweight_mean"), ("(a) node removed", r"(b) node reweighted by $1.25$")):
        for (cfg, d), c, m in zip(F.groupby("config", sort=False), cols, marks):
            d = d.sort_values("theta")
            x = 100 * np.clip(d[col].values, 0, None)
            yv = d["max_overfill_pct"].values
            ax.plot(x, yv, "-", color=c, lw=1.4, marker=m, ms=4.2, mec="white", mew=0.6, label=names.get(cfg, cfg), zorder=3)
            ax.annotate(r"$\theta=0$" if c == cols[0] else "", (x[0], yv[0]), xytext=(5, 2), textcoords="offset points", fontsize=7.5, color=MUTED)
            ax.annotate(r"$\theta=1$" if c == cols[0] else "", (x[-1], yv[-1]), xytext=(3, 9), textcoords="offset points", fontsize=7.5, color=MUTED, ha="left")
        ax.set_xlabel("extra movement (% of the fair optimum)")
        ax.set_title(title, loc="left")
        ax.grid(True, zorder=0)
        ax.set_ylim(bottom=0)
        ax.set_xlim(left=-0.05)
        ax.tick_params(length=2.5)
    axes[0].set_ylabel("over-fill of the fullest domain (%)")
    axes[1].legend(frameon=False, loc="upper right", handlelength=2.2)
    fig.tight_layout(w_pad=1.5)
    fig.savefig(f"{FIG}/fig_frontier.pdf")
    plt.close(fig)


# ------------------------------------------------------------------------------------------ sweep
def fig_sweep():
    SF = pd.read_csv(f"{OUT}/sweep_fairness.csv")
    SM = pd.read_csv(f"{OUT}/sweep_movement.csv")
    SM = SM[SM.opt_fair > 1e-3]
    fams = list(SF["family"].unique())
    cols = [BLUE, ORANGE, AQUA, YELLOW, MAGENTA]
    marks = ["o", "s", "^", "D", "v"]
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.75))
    ax = axes[0]
    for fam, c, m in zip(fams, cols, marks):
        d = SF[(SF.family == fam) & (SF.k == 3)].groupby("n")["straw2_over_pct"].max()
        ax.plot(d.index, d.values, "-", color=c, lw=1.4, marker=m, ms=4.2, mec="white", mew=0.6, label=fam, zorder=3)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xticks([6, 8, 12, 16, 24, 32])
    ax.set_xticklabels(["6", "8", "12", "16", "24", "32"])
    ax.set_xlim(5.4, 36)
    ax.minorticks_off()
    ax.set_yticks([0.3, 1, 3, 10, 30])
    ax.set_yticklabels(["0.3", "1", "3", "10", "30"])
    ax.set_xlabel("number of failure domains $n$")
    ax.set_ylabel("over-fill of the fullest domain (%)")
    ax.set_title("(a) successive sampling, $k=3$", loc="left")
    ax.grid(True, zorder=0)
    ax.legend(frameon=False, loc="lower left", handlelength=2.2)
    ax = axes[1]
    for fam, c, m in zip(fams, cols, marks):
        d = SM[(SM.family == fam) & (SM.scheme == "cos") & (SM.k == 3)].groupby("n")["ratio"].max()
        ax.plot(d.index, d.values, "-", color=c, lw=1.4, marker=m, ms=4.2, mec="white", mew=0.6, label=fam, zorder=3)
    ax.set_xscale("log")
    ax.set_xticks([6, 8, 12, 16, 24, 32])
    ax.set_xticklabels(["6", "8", "12", "16", "24", "32"])
    ax.set_xlim(5.4, 36)
    ax.minorticks_off()
    ax.axhline(1.0, color=MUTED, lw=0.6)
    ax.set_xlabel("number of failure domains $n$")
    ax.set_ylabel("movement / optimum (largest of three events)")
    ax.set_title("(b) COS, $k=3$", loc="left")
    ax.grid(True, zorder=0)
    for a in axes:
        a.tick_params(length=2.5)
    fig.tight_layout(w_pad=1.5)
    fig.savefig(f"{FIG}/fig_sweep.pdf")
    plt.close(fig)


if __name__ == "__main__":
    which = sys.argv[1:] or ["tripod", "movement", "frontier", "sweep"]
    for w in which:
        fn = globals()[f"fig_{w}"]
        try:
            fn()
            print("wrote", w)
        except FileNotFoundError as e:
            print("skipped", w, "-", e)
