"""Build the corpus of real multi-pick configurations from public CRUSH maps.

Every (map, rule) is decomposed into the selection problems where several
distinct failure domains are drawn from one weighted population.  Identical
weight vectors (after sorting and rounding) are merged; provenance of every
duplicate is kept.  Output: data/corpus.json
"""
import glob
import hashlib
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import crushmap as C   # noqa: E402
from fsp import paths as _P    # noqa: E402

RAW = sys.argv[1] if len(sys.argv) > 1 else _P.RAW
OUT = sys.argv[2] if len(sys.argv) > 2 else _P.ROOT + "/data/corpus.json"

GROUPS = [
    ("ceph-fixture", f"{RAW}/ceph/src/test/cli/crushtool/crush-classes/*"),
    ("ceph-fixture", f"{RAW}/ceph/src/test/cli/crushtool/*.crushmap"),
    ("ceph-fixture", f"{RAW}/ceph/src/test/cli/crushtool/*.txt"),
    ("ceph-fixture", f"{RAW}/ceph/src/test/cli/crushtool/*.crush"),
    ("ceph-fixture", f"{RAW}/ceph/src/test/cli/crushtool/multitype.*"),
    ("ceph-osdmap", f"{RAW}/ceph/src/test/compressor/osdmaps/osdmap.2982809"),
    ("pycrush-report", f"{RAW}/python-crush/tests/ceph/*.json"),
    ("pycrush-report", f"{RAW}/python-crush/tests/ceph/*.txt"),
    ("pycrush-report", f"{RAW}/python-crush/tests/*.json"),
]

entries = {}
scanned = []
for group, pat in GROUPS:
    for p in sorted(glob.glob(pat)):
        if os.path.isdir(p):
            continue
        try:
            cm = C.load(p)
        except Exception:
            continue
        if not cm.buckets or not cm.rules:
            continue
        rel = os.path.relpath(p, RAW)
        scanned.append(rel)
        pool_sizes = sorted({s for (_, s, _, _) in cm.pools if s})
        for rule in cm.rules:
            for inst in C.multipick_instances(cm, rule):
                if inst["mode"] != "firstn":
                    continue                       # replicated rules only
                w = np.array(inst["weights"], dtype=float)
                n = len(w)
                if n < 3:
                    continue
                key = hashlib.sha1(np.round(np.sort(w), 9).tobytes()).hexdigest()[:16]
                e = entries.setdefault(key, dict(
                    id=key, n=n, weights=[float(x) for x in np.sort(w)[::-1]],
                    cv=float(np.std(w) / np.mean(w)), sources=[]))
                e["sources"].append(dict(map=rel, group=group, rule=rule.name, level=inst["level"],
                                         root=inst["root"], num=inst["num"],
                                         ctx_prob=inst["ctx_prob"], pool_sizes=pool_sizes))

corpus = sorted(entries.values(), key=lambda e: (e["n"], e["id"]))
het = [e for e in corpus if e["cv"] > 1e-9]
json.dump(dict(scanned_maps=scanned, n_maps=len(scanned), configurations=corpus), open(OUT, "w"), indent=1)
print(f"maps parsed: {len(scanned)}; distinct configurations (n>=3): {len(corpus)}; heterogeneous: {len(het)}")
import collections
print("n distribution (heterogeneous):", sorted(collections.Counter(e["n"] for e in het).items()))
print("maps contributing heterogeneous configs:", len({s["map"] for e in het for s in e["sources"]}))
