"""E1b: the unmodified Ceph mapper on the FULL hierarchical real maps.

Checks the modelling step used throughout the paper: for a rule
`take ROOT; choose[leaf] firstn 0 type T; emit`, the distribution of the set of
type-T failure domains chosen by CRUSH equals successive sampling with the
single-descent probabilities of the domains.  We run crush_do_rule on the
original map (all buckets as straw2, optimal tunables) for N placement groups
and compare domain-level inclusion frequencies with the exact prediction.
Output: out/realmap_validation.csv
"""
import csv
import glob
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import cephcrush as CC, crushmap as C          # noqa: E402
from fsp.core import inclusion, target_inclusion         # noqa: E402

from fsp.paths import RAW, OUT as _OUTDIR   # noqa: E402
N = int(os.environ.get("N_PGS", 1_000_000))
paths = sorted(glob.glob(f"{RAW}/ceph/src/test/cli/crushtool/crush-classes/*")) + \
    sorted(glob.glob(f"{RAW}/ceph/src/test/cli/crushtool/*.crushmap")) + \
    [f"{RAW}/ceph/src/test/compressor/osdmaps/osdmap.2982809"] + \
    sorted(glob.glob(f"{RAW}/python-crush/tests/ceph/ceph-report*.json")) + \
    sorted(glob.glob(f"{RAW}/python-crush/tests/test_optimize_*cluster.json"))

rows, seen = [], set()
for p in paths:
    try:
        cm = C.load(p)
    except Exception:
        continue
    for rule in cm.rules:
        st = [s for s in rule.steps]
        if len(st) != 3 or st[0][0] != "take" or st[1][0] not in ("choose", "chooseleaf") or st[1][1] != "firstn" or st[1][2] != 0:
            continue
        take = cm.by_name(st[0][1]) if isinstance(st[0][1], str) else cm.buckets.get(st[0][1])
        if take is None:
            continue
        typ = st[1][3]
        dom = cm.domains_under(take.id, typ)
        if len(dom) < 4 or typ in ("osd", "device"):
            continue
        ids = [d[0] for d in dom]
        probs = np.array([d[2] for d in dom])
        probs = probs / probs.sum()
        if np.std(probs) / np.mean(probs) < 0.005:
            continue
        sig = (os.path.basename(p), tuple(np.round(np.sort(probs), 6)))
        if sig in seen:
            continue
        seen.add(sig)
        k = 3
        try:
            res = CC.run(CC.spec_for(cm, rule, k, N, force_straw2=True), N, k)
        except Exception as ex:
            print("skip", os.path.basename(p), rule.name, str(ex)[:80])
            continue
        par = None
        if st[1][0] == "chooseleaf":
            # device -> failure domain, following ONLY the tree under the take root
            # (maps with device classes contain shadow trees that share the devices)
            par = {}
            idset = set(ids)

            def rec(bid, anc):
                if bid >= 0:
                    if anc is not None:
                        par[bid] = anc
                    return
                a = bid if bid in idset else anc
                for cid, cw in cm.buckets[bid].items:
                    if cw > 0:
                        rec(cid, a)
            rec(take.id, None)
        pos = {b: i for i, b in enumerate(ids)}
        cnt = np.zeros(len(ids))
        short = 0
        for j in range(k):
            col = res[:, j]
            ok = col != CC.NONE
            short += int((~ok).sum())
            vals, c = np.unique(col[ok], return_counts=True)
            for v, cc in zip(vals, c):
                b = par.get(int(v)) if par is not None else int(v)
                if b in pos:
                    cnt[pos[b]] += cc
        freq = cnt / N
        pred = inclusion(probs, k, "exp")
        fair = target_inclusion(probs, k)
        se = np.sqrt(np.clip(pred * (1 - pred), 1e-12, None) / N)
        z = (freq - pred) / se
        rows.append(dict(map=os.path.basename(p), rule=rule.name, level=typ, n=len(ids), k=k, pgs=N,
                         shortfall=short, max_abs_diff_pred=float(np.abs(freq - pred).max()),
                         max_abs_z=float(np.abs(z).max()),
                         max_abs_diff_fair=float(np.abs(freq - fair).max()),
                         ceph_over_pct=float(100 * (freq / fair - 1).max()),
                         pred_over_pct=float(100 * (pred / fair - 1).max())))
        print(rows[-1], flush=True)
with open(_OUTDIR + "/realmap_validation.csv", "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    wr.writeheader()
    wr.writerows(rows)
print("validated rules:", len(rows))
