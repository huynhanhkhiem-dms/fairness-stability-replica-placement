"""Worst-case differential adaptivity of COS: three numerical studies.

(A) hierarchical corners.  For k heavy nodes and two light ones with rates
    lam_i = g^(i-1), g -> 0, raising the lightest node, a cascade argument predicts
        T_k = 1 + (k-1)/(2k) + ((k+1)/k) (H_{k+1} - 3/2)
    (7/4, 19/9, 113/48, 127/50, ...).  We evaluate rho exactly (multiple-precision
    linear solve) for k = 2..7 and g = 1e-2 .. 1e-5.
(B) constrained search: largest rho found when every node stays at least a
    margin m below its cap (p_i <= 1 - m) and p_i >= 1e-5.
(C) unconstrained search (p within 1e-9 of the cap allowed, p_i >= 1e-12),
    to see whether anything exceeds T_k.

Outputs: out/rho_hier.csv, out/rho_margin_<tag>.csv, out/rho_free_<tag>.csv
(each file is rewritten after every row).
"""
import csv
import os
import sys
import time
from fractions import Fraction

import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.laplacian import flow_ratios, race_p_phi    # noqa: E402

from fsp.paths import ROOT   # noqa: E402


def T(k):
    H = sum(Fraction(1, m) for m in range(1, k + 2))
    return 1 + Fraction(k - 1, 2 * k) + Fraction(k + 1, k) * (H - Fraction(3, 2))


def rho_all(lam, k, width=0.25, order=12):
    lam = np.asarray(lam, float)
    lam = lam / lam.max()
    p, phi = race_p_phi(lam, k, width=width, order=order)
    return flow_ratios(p, phi, k), p


def dump(path, rows):
    with open(path, "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)


def study_hier():
    rows = []
    for k in range(2, 8):
        n = k + 2
        for g in (1e-2, 1e-3, 1e-4, 1e-5):
            lam = np.array([g ** i for i in range(n)])
            r, p = rho_all(lam, k)
            rf, _ = rho_all(lam, k, width=0.1, order=20)
            rows.append(dict(k=k, n=n, g=g, rho_lightest=round(float(r[-1]), 6), rho_lightest_fine=round(float(rf[-1]), 6),
                             T_k=str(T(k)), T_k_float=round(float(T(k)), 6), rho_all=" ".join(f"{x:.4f}" for x in r)))
            print(rows[-1], flush=True)
            dump(f"{ROOT}/out/rho_hier.csv", rows)


def f_mu(mu):
    """Limit of rho for n = 4, k = 2, lambda = (1, mu, eta, zeta), eta -> 0, zeta/eta -> 0, raising node 4
    (Proposition "two corners", part 2)."""
    a = 2 * mu / (1 + mu) ** 3
    b = 1 - (1 + mu) ** -2
    c = 1 / mu - mu / (1 + mu) ** 2
    m = b * c / (b + c)
    return 1 + abs(c - b) / (2 * (b + c)) * (a + 2 * m) / (a + m)


def study_fmu():
    from scipy.optimize import minimize_scalar
    rows = []
    for mu in (1.0, 0.5, 0.2, 0.1, 0.05, 0.03, 0.02, 0.01, 0.001):
        r, p = rho_all([1, mu, mu * 1e-7, mu * 1e-14], 2)
        rows.append(dict(mu=mu, f_mu=round(f_mu(mu), 6), rho_exact=round(float(r[3]), 6)))
        print(rows[-1], flush=True)
    res = minimize_scalar(lambda x: -f_mu(x), bounds=(1e-4, 0.5), method="bounded", options=dict(xatol=1e-10))
    r, p = rho_all([1, res.x, res.x * 1e-7, res.x * 1e-14], 2)
    rows.append(dict(mu=round(float(res.x), 5), f_mu=round(float(-res.fun), 6), rho_exact=round(float(r[3]), 6)))
    print("max", rows[-1], flush=True)
    dump(f"{ROOT}/out/rho_fmu.csv", rows)


def sample(n, k, rng, it, spread):
    mode = it % 6
    if mode == 0:
        return rng.normal(0, 1.0, n)
    if mode == 1:
        return rng.normal(0, 2.5 * spread, n)
    if mode == 2:                       # some heavy nodes, the rest light
        x = rng.normal(0, 0.3, n)
        x[: rng.integers(1, k + 2)] += rng.uniform(1, 7 * spread)
        return x
    if mode == 3:                       # three tiers
        x = rng.normal(0, 0.3, n)
        a, b = sorted(rng.integers(0, n + 1, 2))
        x[:a] += rng.uniform(2, 8 * spread)
        x[a:b] += rng.uniform(0, 3 * spread)
        return x
    if mode == 4:                       # k heavy nodes, others spread out
        x = rng.normal(0, 0.2, n)
        x[:k] += rng.uniform(2, 8 * spread)
        x[k:] += rng.normal(0, 2.0 * spread, n - k)
        return x
    step = rng.uniform(0.5, 6 * spread)   # geometric hierarchy with random step
    return -step * np.arange(n) + rng.normal(0, 0.3, n)


def search(n, k, margin, pmin, budget, rng, spread):
    def obj(x):
        x = np.clip(x - x.max(), -90, 0)
        r, p = rho_all(np.exp(x), k)
        if not np.all(np.isfinite(r)) or p.max() > 1 - margin or p.min() < pmin:
            return 0.0, -1, p
        j = int(np.argmax(r))
        return float(r[j]), j, p
    t0 = time.time()
    cands, tested, it = [], 0, 0
    # Fixed candidate count is opt-in for machine-independent diagnostic searches.
    fixed_candidates = int(os.environ.get("SEARCH_CANDIDATES", "0"))
    if fixed_candidates < 0:
        raise ValueError("SEARCH_CANDIDATES must be nonnegative")
    while (it < fixed_candidates if fixed_candidates else time.time() - t0 < 0.4 * budget):
        x = sample(n, k, rng, it, spread)
        it += 1
        r, j, p = obj(x)
        if j >= 0:
            tested += 1
            cands.append((r, j, x))
    cands.sort(key=lambda c: -c[0])
    best = cands[0] if cands else (0.0, -1, np.zeros(n))
    for r0, j0, x0 in cands[:5]:
        if not fixed_candidates and time.time() - t0 > budget:
            break
        res = minimize(lambda x: -obj(x)[0], x0, method="Nelder-Mead",
                       options=dict(maxiter=120 * n, xatol=1e-5, fatol=1e-8, adaptive=True))
        tested += res.nfev
        r1, j1, _ = obj(res.x)
        if r1 > best[0]:
            best = (r1, j1, res.x)
    r, j, x = best
    lam = np.exp(np.clip(x - x.max(), -90, 0))
    rf, pf = rho_all(lam, k, width=0.1, order=20)
    return dict(n=n, k=k, margin=margin, pmin=pmin, tested=tested, sup_rho=round(r, 5),
                sup_rho_fine=round(float(rf[j]), 5) if j >= 0 else "", j=j,
                p_j=float(pf[j]) if j >= 0 else "", p_max=float(pf.max()), p_min=float(pf.min()),
                T_k=round(float(T(k)), 5), p=" ".join(f"{v:.6g}" for v in pf), lam=" ".join(f"{v:.3e}" for v in lam))


def study_margin(grid, margins, budget, tag):
    path = f"{ROOT}/out/rho_margin_{tag}.csv"
    rows = []
    for (n, k) in grid:
        for m in margins:
            rng = np.random.default_rng([20261116, n, k, int(round(-np.log10(m) * 10))])
            rows.append(search(n, k, m, 1e-5, budget, rng, spread=1.0))
            print({a: rows[-1][a] for a in ("n", "k", "margin", "tested", "sup_rho", "sup_rho_fine", "j", "p")}, flush=True)
            dump(path, rows)


def study_free(grid, budget, tag):
    path = f"{ROOT}/out/rho_free_{tag}.csv"
    rows = []
    for (n, k) in grid:
        rng = np.random.default_rng([20261117, n, k])
        rows.append(search(n, k, 1e-9, 1e-12, budget, rng, spread=2.5))
        print({a: rows[-1][a] for a in ("n", "k", "tested", "sup_rho", "sup_rho_fine", "T_k", "j", "p")}, flush=True)
        dump(path, rows)


if __name__ == "__main__":
    what = os.environ.get("STUDY", "hier")
    grid = [tuple(int(v) for v in g.split("x")) for g in os.environ.get("GRID", "3x2,4x2").split(",")]
    budget = float(os.environ.get("BUDGET", 30))
    tag = os.environ.get("TAG", "a")
    if what == "hier":
        study_hier()
    elif what == "fmu":
        study_fmu()
    elif what == "margin":
        study_margin(grid, [float(v) for v in os.environ.get("MARGINS", "0.1,0.01,0.001").split(",")], budget, tag)
    elif what == "free":
        study_free(grid, budget, tag)
