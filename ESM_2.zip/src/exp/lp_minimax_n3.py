"""Minimax unfairness of stable, scale-invariant 2-of-3 placement (LP + certificate).

By the structure theorem (n = 3, k = 2) every pathwise-stable, scale-invariant
rule is, key by key, "exclude argmin_i w_i T_i": in coordinates a = log(w1/w3),
b = log(w2/w3) the key owns an apex (alpha, beta) and
     node 3 excluded  <=>  alpha < a  and  beta < b
     node 1 excluded  <=>  alpha > a  and  beta - alpha < b - a
     node 2 excluded  <=>  beta  > b  and  beta - alpha > b - a
(degenerate rules = apex at infinity).  A rule is a probability law nu of the apex.

Primal LP on a finite test set X of uncapped configurations:
     minimise  delta   s.t.  | P_nu(excluded = j at x) - tau_j(x) | <= delta,
     tau_j = 1 - 2 p_j  (exact fairness).
Its value is a LOWER bound on sup-norm unfairness of every such rule, provided
every sign pattern an apex can realise against X is available.  Test coordinates
lie on a uniform log grid of step h, so all thresholds (a_i, b_j, b_j - a_i) are
multiples of h; atoms at alpha = (i + 1/2) h/2, beta = (j + 3/4) h/2 hit every
cell of that arrangement with both signs of the diagonal comparison, and the
atom box extends 2L + 2h beyond the test box so that apexes at infinity (in
every direction and with every diagonal offset) are represented.

The dual solution is a signed weight c on (configuration, node) pairs with
|c|_1 <= 1; the certificate is checked independently:
     delta* >= <tau, c> - max_atoms <pattern, c>.
"""
import json
import os
import sys
import time

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, hstack, vstack

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.paths import OUT   # noqa: E402


def test_set(G, R):
    L = np.log(R)
    t = np.linspace(-L, L, G)
    A, B = np.meshgrid(t, t, indexing="ij")
    ea, eb = np.exp(A), np.exp(B)
    W = ea + eb + 1.0
    p = np.stack([ea / W, eb / W, 1.0 / W], axis=-1)
    inM = p.max(axis=-1) <= 0.5 + 1e-12
    pts = np.argwhere(inM)
    return t, pts, 1.0 - 2.0 * p[inM]             # tau[q, j]


def atoms(t):
    G = len(t)
    h = t[1] - t[0]
    L = t[-1]
    hp = h / 2.0
    marg = int(np.ceil(2 * L / h)) + 2
    lo = -L - marg * h
    na = 2 * (G - 1 + 2 * marg)
    al = lo + (np.arange(na) + 0.5) * hp
    be = lo + (np.arange(na) + 0.75) * hp
    AL, BE = np.meshgrid(al, be, indexing="ij")
    return AL.ravel(), BE.ravel()


def indicators(t, pts, AL, BE):
    m, nv = len(pts), AL.size
    I = np.empty((3, m, nv), dtype=np.float32)
    D = BE - AL
    for q in range(m):
        a, b = t[pts[q, 0]], t[pts[q, 1]]
        I[2, q] = (AL < a) & (BE < b)
        I[0, q] = (AL > a) & (D < (b - a))
        I[1, q] = (BE > b) & (D > (b - a))
    assert np.allclose(I.sum(axis=0), 1.0)
    return I


def solve(G, R, want_solution=False):
    t, pts, tau = test_set(G, R)
    AL, BE = atoms(t)
    I = indicators(t, pts, AL, BE)
    m, nv = len(pts), AL.size
    M3 = csr_matrix(I.reshape(3 * m, nv))
    tau_flat = tau.T.reshape(3 * m)
    ones = np.ones((3 * m, 1))
    A_ub = vstack([hstack([M3, -ones]), hstack([-M3, -ones])]).tocsr()
    b_ub = np.concatenate([tau_flat, -tau_flat])
    A_eq = csr_matrix(np.concatenate([np.ones(nv), [0.0]])[None, :])
    c = np.zeros(nv + 1)
    c[-1] = 1.0
    t0 = time.time()
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=[1.0],
                  bounds=[(0, None)] * (nv + 1), method="highs")
    # ---- independent check of the dual certificate ----
    y = -res.ineqlin.marginals                    # >= 0
    u, v = y[:3 * m], y[3 * m:]
    cert = v - u                                  # signed weights, |cert|_1 <= 1
    norm1 = float(np.abs(cert).sum())
    cert_n = cert / max(norm1, 1.0)
    pattern_max = float((I.reshape(3 * m, nv).T.astype(np.float64) @ cert_n).max())
    bound = float(tau_flat @ cert_n) - pattern_max
    out = dict(G=G, R=R, n_test=int(m), n_atoms=int(nv), delta_primal=float(res.fun),
               delta_certified=bound, cert_l1=norm1,
               cert_support=int((np.abs(cert_n) > 1e-9).sum()), seconds=round(time.time() - t0, 1))
    print(json.dumps(out), flush=True)
    if want_solution:
        return out, (t, pts, tau, AL, BE, res.x[:-1], cert_n.reshape(3, m))
    return out, None


def exclusion_probs(al, be, mass, a, b):
    """Exclusion probabilities of the discrete apex law at configuration (a, b)."""
    e3 = mass[(al < a) & (be < b)].sum()
    e1 = mass[(al > a) & ((be - al) < (b - a))].sum()
    e2 = mass[(be > b) & ((be - al) > (b - a))].sum()
    return np.array([e1, e2, e3])


def reference_errors(R, G=41, nsim=1_000_000, seed=7):
    """Worst-case error of concrete iid rules on a dense test grid (Monte Carlo)."""
    rng = np.random.default_rng(seed)
    t, pts, tau = test_set(G, R)
    res = {}
    laws = {
        "straw2 (exp race)": -np.log(rng.exponential(size=(nsim, 3))),
        "priority (w/U)": -np.log(rng.random((nsim, 3))),
    }
    for a_exp in (1.25, 1.5, 2.0):
        laws[f"power exponent {a_exp}"] = -np.log(rng.exponential(size=(nsim, 3))) / a_exp
    for name, c in laws.items():
        al, be = c[:, 0] - c[:, 2], c[:, 1] - c[:, 2]
        worst = 0.0
        for q in range(len(pts)):
            a, b = t[pts[q, 0]], t[pts[q, 1]]
            e3 = np.mean((al < a) & (be < b))
            e1 = np.mean((al > a) & ((be - al) < (b - a)))
            e2 = np.mean((be > b) & ((be - al) > (b - a)))
            worst = max(worst, np.abs(np.array([e1, e2, e3]) - tau[q]).max())
        res[name] = float(worst)
    return res


if __name__ == "__main__":
    PHI = (1 + 5 ** 0.5) / 2
    rows = []
    # (R, G): uniform log grids; the last two are aligned with the golden ratio so that
    # the cyclic certificate with weights 1 : phi : phi^2 lies on the grid.
    for R, G in ((4.0, 13), (4.0, 25), (16.0, 13), (16.0, 25), (PHI ** 3, 13), (PHI ** 3, 25)):
        o, _ = solve(G, R)
        rows.append(o)
        json.dump(dict(lp=rows), open(f"{OUT}/lp_minimax_n3.json", "w"), indent=1)
    cyc = (7 - 3 * 5 ** 0.5) / 6
    print("closed-form cyclic bound (7-3*sqrt5)/6 =", cyc)
    refs = {f"R={R}": reference_errors(R) for R in (4.0, 16.0)}
    print(json.dumps(refs, indent=1))
    json.dump(dict(lp=rows, cyclic_bound=cyc, reference_rules=refs),
              open(f"{OUT}/lp_minimax_n3.json", "w"), indent=1)
