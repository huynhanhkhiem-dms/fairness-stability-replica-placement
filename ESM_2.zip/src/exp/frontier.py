"""E7: the fairness / movement frontier between the stable rule and the fair rule.

Working weights are interpolated geometrically, lambda_theta = w^(1-theta) * lambda*^theta,
theta in [0,1]: theta=0 is the stable (biased) exponential race, theta=1 is COS.
For each theta we report the exact unfairness and, for single-node events, the
movement in excess of the rule's own transport bound (zero for a stable rule),
relative to the fair optimum.  Output: out/frontier.csv
"""
import csv
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.calib import calibrate                        # noqa: E402
from fsp.core import inclusion, target_inclusion        # noqa: E402
from fsp.movement import draws, moved, topk_sets        # noqa: E402

from fsp.paths import ROOT   # noqa: E402
M = int(os.environ.get("M_KEYS", 1_000_000))
THETAS = [0.0, 0.25, 0.5, 0.75, 0.9, 1.0]


def mult(w, k, theta):
    out = np.zeros(len(w))
    p = w > 0
    lam, alw = calibrate(w[p], k, "exp")
    lw = np.log(w[p])
    with np.errstate(divide="ignore"):
        ll = np.where(np.isinf(lam), np.inf, np.log(np.where(np.isinf(lam), 1.0, lam)))
    # align scales on the free set before interpolating
    free = ~np.isinf(ll)
    ll[free] += lw[free].mean() - ll[free].mean()
    out[p] = np.exp((1 - theta) * lw + theta * np.where(free, ll, lw))
    if theta >= 1.0:
        out[p] = np.where(free, out[p], np.inf)
    return out


def incl(mu, k):
    out = np.zeros(len(mu))
    p = mu > 0
    inf = np.isinf(mu)
    kk = k - int(inf.sum())
    out[inf] = 1.0
    fin = p & ~inf
    out[fin] = inclusion(mu[fin], kk, "exp") if fin.sum() > kk else 1.0
    return out


# four uncapped configurations of the corpus, identified by (map, level, rule) of their first source;
# events that would bring a domain within 0.1% of its cap are skipped (the interpolation is only
# defined for uncapped domains, whose working weight is finite)
used = json.load(open(f"{ROOT}/out/corpus_used.json"))


def find(mapname, level, rule):
    for c in used:
        s0 = c["sources"][0]
        if s0["map"].split("/")[-1] == mapname and s0["level"] == level and s0.get("rule") == rule:
            return c
    raise KeyError((mapname, level, rule))


want = [("e (8 hosts)", find("e", "host", "replicated_rule"), 3),
        ("big-1 (6 racks)", find("test-map-big-1.crushmap", "rack", "data"), 3),
        ("gabe (5 racks)", find("f", "rack", "replicated_ruleset"), 3),
        ("report-10h (10 hosts)", find("ceph-crushmap-rules-order.txt", "host", "data"), 3)]
json.dump({name: name for name, _, _ in want}, open(f"{ROOT}/out/frontier_names.json", "w"))
rows = []
for label, cfg, k in want:
    w = np.array(cfg["weights"], float)
    n = len(w)
    fair = target_inclusion(w, k)
    assert fair.max() < 0.999, label
    U = draws(M, n, seed=21)
    events = []
    for i in range(n):
        w2 = w.copy(); w2[i] = 0.0
        if target_inclusion(w2[w2 > 0], k).max() < 0.999:
            events.append(("remove", w2))
        w3 = w.copy(); w3[i] *= 1.25
        if target_inclusion(w3, k).max() < 0.999:
            events.append(("reweight", w3))
    for th in THETAS:
        mu = mult(w, k, th)
        pi = incl(mu, k)
        base = topk_sets(mu, U, k)
        exc = {"remove": [], "reweight": []}
        for ev, w2 in events:
            mu2 = mult(w2, k, th)
            pi2 = incl(mu2, k)
            f2 = np.zeros(n); f2[w2 > 0] = target_inclusion(w2[w2 > 0], k)
            opt_fair = float(np.clip(f2 - fair, 0, None).sum())
            own = float(np.clip(pi2 - pi, 0, None).sum())
            mv = moved(base, topk_sets(mu2, U, k))
            exc[ev].append((mv - own) / opt_fair)
        rows.append(dict(config=label, n=n, k=k, theta=th, n_remove=len(exc["remove"]), n_reweight=len(exc["reweight"]),
                         max_overfill_pct=float(100 * (pi / fair - 1).max()),
                         misplaced_pct=float(100 * np.abs(pi - fair).sum() / (2 * k)),
                         excess_remove_mean=float(np.mean(exc["remove"])), excess_remove_max=float(np.max(exc["remove"])),
                         excess_reweight_mean=float(np.mean(exc["reweight"])), excess_reweight_max=float(np.max(exc["reweight"]))))
        print(rows[-1], flush=True)
with open(f"{ROOT}/out/frontier.csv", "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    wr.writeheader()
    wr.writerows(rows)
