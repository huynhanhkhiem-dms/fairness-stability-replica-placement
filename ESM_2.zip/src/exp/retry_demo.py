"""E2a: extra movement of the unmodified Ceph mapper on small flat straw2
buckets, against the single-order rule with the same distribution.
Output: out/retry_demo.csv
"""
import csv
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import cephcrush as CC                        # noqa: E402
from fsp.core import inclusion                         # noqa: E402
from fsp.designs import retry_sets                     # noqa: E402
from fsp.movement import draws, moved, topk_sets       # noqa: E402

N = int(os.environ.get("M_KEYS", 2_000_000))
SCEN = [
    ("add 4th equal node", [1, 1, 1, 0], [1, 1, 1, 1], 2),
    ("add 6th equal node", [1, 1, 1, 1, 1, 0], [1, 1, 1, 1, 1, 1], 3),
    ("add 11th equal node", [1] * 10 + [0], [1] * 11, 3),
    ("add 11th equal node, two replicas", [1] * 10 + [0], [1] * 11, 2),
    ("remove 1 of 10 equal nodes", [1] * 10, [1] * 9 + [0], 3),
    ("double 1 of 5 equal nodes", [1, 1, 1, 1, 1], [2, 1, 1, 1, 1], 3),
    ("double 1 of 10 equal nodes", [1] * 10, [2] + [1] * 9, 3),
    ("add node 2 to (4,3,2,1)", [4, 3, 2, 1, 0], [4, 3, 2, 1, 2], 2),
    ("remove largest of (4,3,2,1,2,3)", [4, 3, 2, 1, 2, 3], [0, 3, 2, 1, 2, 3], 3),
    ("+50% on one of (4,3,2,1,2,3)", [4, 3, 2, 1, 2, 3], [4, 3, 3, 1, 2, 3], 3),
]


def ceph(w, k):
    w = np.asarray(w, float)
    res, _ = CC.run_binary(CC.HARNESS, CC.flat_spec(w, k, N, always="big"), N, k)
    return CC.membership(res, len(w))


rows = []
for name, wa, wb, k in SCEN:
    wa, wb = np.array(wa, float), np.array(wb, float)
    n = len(wa)
    pa, pb = np.zeros(n), np.zeros(n)
    pa[wa > 0] = inclusion(wa[wa > 0], k) if (wa > 0).sum() > k else 1.0
    pb[wb > 0] = inclusion(wb[wb > 0], k) if (wb > 0).sum() > k else 1.0
    opt = float(np.clip(pb - pa, 0, None).sum())
    mc = moved(ceph(wa, k), ceph(wb, k))
    mr = moved(retry_sets(wa, N, k, seed=1), retry_sets(wb, N, k, seed=1))
    U = draws(N, n, seed=3)
    ms = moved(topk_sets(wa, U, k), topk_sets(wb, U, k))
    se = np.sqrt(mc / N) / opt
    rows.append(dict(scenario=name, n=n, k=k, optimum=opt, ceph=mc, ceph_ratio=mc / opt, ratio_se=se,
                     retry_model_ratio=mr / opt, single_order_ratio=ms / opt))
    print(rows[-1], flush=True)
from fsp.paths import OUT as _OUTDIR   # noqa: E402
with open(_OUTDIR + "/retry_demo.csv", "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    wr.writeheader()
    wr.writerows(rows)
