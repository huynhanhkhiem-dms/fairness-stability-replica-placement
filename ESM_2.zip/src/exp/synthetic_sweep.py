"""E4: controlled sweep over (n, k, weight family): fairness of stable rules,
exactness and cost of calibration, and movement ratios of all schemes.
Outputs out/sweep_fairness.csv and out/sweep_movement.csv.
"""
import csv
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp.calib import calibrate                         # noqa: E402
from fsp.core import inclusion, target_inclusion         # noqa: E402
from fsp.designs import pivotal_sets, retry_sets, systematic_sets   # noqa: E402
from fsp.movement import draws, moved, topk_sets         # noqa: E402

from fsp.paths import ROOT   # noqa: E402
M = int(os.environ.get("M_KEYS", 200_000))


FAMS = ["two-size 1:2", "two-size 1:4", "one large (3x)", "drive mix 4/8/12/16", "lognormal 0.5"]
GRID = [(n, k) for n in (4, 6, 8, 12, 16, 24, 32) for k in (2, 3, 4, 6) if k <= n - 2]


def family(name, n, rng):
    if name == "two-size 1:2":
        w = np.where(np.arange(n) < n // 2, 2.0, 1.0)
    elif name == "two-size 1:4":
        w = np.where(np.arange(n) < n // 2, 4.0, 1.0)
    elif name == "one large (3x)":
        w = np.ones(n)
        w[0] = 3.0
    elif name == "drive mix 4/8/12/16":
        w = np.array([4.0, 8.0, 12.0, 16.0])[np.arange(n) % 4]
    elif name == "lognormal 0.5":
        w = np.exp(rng.normal(0, 0.5, n))
    else:
        raise ValueError(name)
    return np.sort(w)[::-1].astype(float)


def cal(w, k):
    out = np.zeros(len(w))
    p = w > 0
    if p.sum() <= k:
        out[p] = np.inf
        return out
    lam, _ = calibrate(w[p], k, "exp")
    out[p] = lam
    return out


def vec(fn, w, k):
    out = np.zeros(len(w))
    p = w > 0
    out[p] = fn(w[p], k) if p.sum() > k else 1.0
    return out


def main():
    import json
    fams = FAMS
    grid = GRID
    if os.environ.get("FAMS"):
        fams_run = [fams[int(i)] for i in os.environ["FAMS"].split(",")]
    else:
        fams_run = fams
    cdir = f"{ROOT}/out/sweep_chunks"
    os.makedirs(cdir, exist_ok=True)
    t0 = time.time()
    for fam in fams_run:
        fi = fams.index(fam)
        reps = 3 if fam.startswith("lognormal") else 1
        for (n, k) in (grid[::-1] if os.environ.get("REVERSE") else grid):
            cfile = f"{cdir}/{fi}_{n}_{k}.json"
            if os.path.exists(cfile):
                continue
            frows, mrows = [], []
            for rep in range(reps):
                rng = np.random.default_rng([fi, n, k, rep])
                w = family(fam, n, rng)
                pf = target_inclusion(w, k)
                tc = time.time()
                lam, alw, info = calibrate(w, k, "exp", return_info=True)
                tcal = time.time() - tc
                row = dict(family=fam, n=n, k=k, rep=rep, cv=float(np.std(w) / np.mean(w)), pmax=float(pf.max()),
                           n_capped=int(alw.sum()), cal_seconds=tcal, cal_iters=info["iters"], cal_err=info["err"])
                for nm, shape in (("straw2", "exp"), ("priority", "uniform"), ("pow1.25", ("frechet", 1.25))):
                    px = inclusion(w, k, shape)
                    row[f"{nm}_over_pct"] = float(100 * (px / pf - 1).max())
                    row[f"{nm}_under_pct"] = float(100 * (px / pf - 1).min())
                    row[f"{nm}_misplaced_pct"] = float(100 * np.abs(px - pf).sum() / (2 * k))
                frows.append(row)
                # movement: three canonical events
                U = draws(M, n, seed=1 + rep)
                mc = cal(w, k)
                base = dict(retry=retry_sets(w, M, k, seed=3), topk=topk_sets(w, U, k),
                            cos=topk_sets(mc, U, k), **{"retry+cal": retry_sets(mc, M, k, seed=3)},
                            systematic=systematic_sets(w, M, k, seed=4), pivotal=pivotal_sets(w, M, k, seed=4))
                pf0 = vec(target_inclusion, w, k)
                po0 = vec(lambda a, b: inclusion(a, b, "exp"), w, k)
                events = {"remove largest": (0, 0.0), "remove smallest": (n - 1, 0.0), "reweight median x1.25": (n // 2, 1.25)}
                for ev, (i, f) in events.items():
                    w2 = w.copy()
                    w2[i] *= f
                    if (w2 > 0).sum() < k:
                        continue
                    mc2 = cal(w2, k)
                    after = dict(retry=retry_sets(w2, M, k, seed=3), topk=topk_sets(w2, U, k),
                                 cos=topk_sets(mc2, U, k), **{"retry+cal": retry_sets(mc2, M, k, seed=3)},
                                 systematic=systematic_sets(w2, M, k, seed=4), pivotal=pivotal_sets(w2, M, k, seed=4))
                    pf2 = vec(target_inclusion, w2, k)
                    of = float(np.clip(pf2 - pf0, 0, None).sum())
                    oo = float(np.clip(vec(lambda a, b: inclusion(a, b, "exp"), w2, k) - po0, 0, None).sum())
                    for s in base:
                        mv = moved(base[s], after[s])
                        ref = oo if s in ("retry", "topk") else of
                        mrows.append(dict(family=fam, n=n, k=k, rep=rep, event=ev, scheme=s, moved=mv,
                                          opt_fair=of, opt_own=oo, pmax=float(max(pf0.max(), pf2.max())),
                                          ratio=mv / ref if ref > 1e-9 else float("nan")))
            with open(cfile + ".tmp", "w") as f:
                json.dump(dict(fair=frows, move=mrows), f)
            os.replace(cfile + ".tmp", cfile)
            print(f"[{time.time()-t0:5.0f}s] {fam} n={n} k={k}", flush=True)
    # merge when complete
    want = [f"{cdir}/{fi}_{n}_{k}.json" for fi in range(len(fams)) for (n, k) in grid]
    if all(os.path.exists(c) for c in want):
        frows, mrows = [], []
        for c in want:
            d = json.load(open(c))
            frows += d["fair"]
            mrows += d["move"]
        for name, rows in (("sweep_fairness.csv", frows), ("sweep_movement.csv", mrows)):
            with open(f"{ROOT}/out/{name}", "w", newline="") as f:
                wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                wr.writeheader()
                wr.writerows(rows)
        print("merged rows", len(frows), len(mrows))
    else:
        print("chunks present", sum(os.path.exists(c) for c in want), "of", len(want))


if __name__ == "__main__":
    main()
