"""E6: the single-order rule implemented in C on top of Ceph's hash and
fixed-point logarithm (csrc/topk_harness.c).

 (a) distribution: raw weights -> exact successive-sampling probabilities;
     calibrated weights -> fair target (z-scores over all corpus configurations);
 (b) movement for one removal per configuration, calibrated weights;
 (c) time per mapping, unmodified crush_do_rule vs single-order selection;
 (d) calibration time as a function of n.
Outputs out/impl_distribution.csv, out/impl_timing.csv, out/calibration_timing.csv
"""
import csv
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from fsp import cephcrush as CC                        # noqa: E402
from fsp.calib import calibrate                        # noqa: E402
from fsp.core import inclusion, target_inclusion        # noqa: E402
from fsp.movement import moved                         # noqa: E402

from fsp.paths import ROOT   # noqa: E402
N = int(os.environ.get("M_KEYS", 2_000_000))


def topk_c(w, k, n_keys=N, x0=0):
    res, ns = CC.run_binary(CC.TOPK, CC.flat_spec(w, k, n_keys, x0=x0, always="flag"), n_keys, k)
    return CC.membership(res, len(w)), ns


def cal(w, k):
    out = np.zeros(len(w))
    p = w > 0
    if p.sum() <= k:
        out[p] = np.inf
        return out
    lam, _ = calibrate(w[p], k, "exp")
    out[p] = lam
    return out


PARTS = os.environ.get("PARTS", "dist,time,cal").split(",")

if "dist" in PARTS:
    configs = json.load(open(f"{ROOT}/out/corpus_used.json"))
    rows = []
    for e in configs:
        w = np.array(e["weights"], float)
        n = len(w)
        label = e["sources"][0]["map"].split("/")[-1] + ":" + e["sources"][0]["level"]
        for k in (2, 3):
            if k >= n:
                continue
            pred, fair = inclusion(w, k, "exp"), target_inclusion(w, k)
            mem_raw, _ = topk_c(w, k)
            lam = cal(w, k)
            mem_cal, _ = topk_c(lam, k)
            fr, fc = mem_raw.mean(0), mem_cal.mean(0)
            z_raw = (fr - pred) / np.sqrt(np.clip(pred * (1 - pred), 1e-12, None) / N)
            z_cal = (fc - fair) / np.sqrt(np.clip(fair * (1 - fair), 1e-12, None) / N)
            # movement: remove the largest node
            w2 = w.copy()
            w2[0] = 0.0
            mem2, _ = topk_c(cal(w2, k), k)
            f2 = np.zeros(n)
            f2[w2 > 0] = target_inclusion(w2[w2 > 0], k) if (w2 > 0).sum() > k else 1.0
            opt = float(np.clip(f2 - fair, 0, None).sum())
            rows.append(dict(label=label, n=n, k=k, keys=N,
                             raw_max_abs_z=float(np.abs(z_raw).max()), raw_max_abs_diff=float(np.abs(fr - pred).max()),
                             cal_max_abs_z=float(np.abs(z_cal[fair < 1 - 1e-9]).max()) if (fair < 1 - 1e-9).any() else 0.0,
                             cal_max_abs_diff=float(np.abs(fc - fair).max()),
                             cal_max_rel_err_pct=float(100 * np.abs(fc / fair - 1).max()),
                             remove_largest_ratio=moved(mem_cal, mem2) / opt if opt > 1e-9 else float("nan")))
            print(rows[-1], flush=True)
    with open(f"{ROOT}/out/impl_distribution.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)

# ---- timing: ns per mapping -------------------------------------------------
if "time" in PARTS:
    trows = []
    rng = np.random.default_rng(5)
    NT = 1_000_000
    for n in (5, 10, 20, 50, 100, 200):
        for k in (3,):
            w = np.exp(rng.normal(0, 0.4, n))
            best_c, best_t = 1e18, 1e18
            for rep in range(5):
                _, ns_c = CC.run_binary(CC.HARNESS, CC.flat_spec(w, k, NT, always="big"), NT, k)
                _, ns_t = CC.run_binary(CC.TOPK, CC.flat_spec(w, k, NT, always="flag"), NT, k)
                best_c, best_t = min(best_c, ns_c), min(best_t, ns_t)
            trows.append(dict(n=n, k=k, crush_do_rule_ns=best_c, single_order_ns=best_t, speedup=best_c / best_t))
            print(trows[-1], flush=True)
    with open(f"{ROOT}/out/impl_timing.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(trows[0].keys()))
        wr.writeheader()
        wr.writerows(trows)

# ---- calibration cost -------------------------------------------------------
if "cal" in PARTS:
    crow = []
    for n in (5, 10, 20, 50, 100, 200):
        for k in (3,):
            ts, its, errs = [], [], []
            for rep in range(3):
                w = np.exp(np.random.default_rng([n, rep]).normal(0, 0.4, n))
                t0 = time.time()
                lam, alw, info = calibrate(w, k, "exp", return_info=True)
                ts.append(time.time() - t0)
                its.append(info["iters"])
                errs.append(info["err"])
            crow.append(dict(n=n, k=k, seconds_median=float(np.median(ts)), iters_median=float(np.median(its)),
                             max_abs_err=float(np.max(errs))))
            print(crow[-1], flush=True)
    with open(f"{ROOT}/out/calibration_timing.csv", "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(crow[0].keys()))
        wr.writeheader()
        wr.writerows(crow)
