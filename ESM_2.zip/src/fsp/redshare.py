"""Redundant Share (Brinkmann, Effert, Meyer auf der Heide, Scheideler, ICDCS 2007; Effert, Paderborn 2011).

Structure, as described in Effert's dissertation (Algorithm "Redundant Share", Sect. 3.4):
  * devices are processed in order of decreasing capacity;
  * to place r copies on the suffix vector v, the first copy goes to the first position i whose
    per-(object, device) uniform hash u_i is below a_i = min(1, r * v_i / V_i), V_i = v_i + ... + v_m;
  * the remaining r - 1 copies are placed recursively on the positions after i, with the capacity of
    the first of them replaced by an adjusted value c*.  In the description, c* differs from the plain
    capacity only at the position where r * v_i / V_i crosses one, and its value restores exact fairness.
We compute c* numerically from that fairness condition instead of by the closed form of the
dissertation (whose general-k formula we could not read reliably), and check exact fairness for every
configuration we use (``check_fair``).  Devices whose fair share is a full replica of every object
(capped devices) are always selected, and the procedure runs on the others with r reduced accordingly.
"""
import numpy as np
from scipy.optimize import brentq

from .core import target_inclusion


def _suffix(v):
    return np.cumsum(v[::-1])[::-1]


class _Node:
    """Placement of r copies on a vector v (positions 0..m-1 of a suffix)."""
    __slots__ = ("r", "v", "a", "always", "free", "children", "incl", "adjusted")

    def __init__(self, r, v):
        self.r = r
        self.v = np.asarray(v, dtype=float)
        m = len(self.v)
        self.children = {}
        self.adjusted = {}
        if r <= 0:
            self.always = np.zeros(m, bool)
            self.free = np.zeros(m, bool)
            self.a = np.zeros(m)
            self.incl = np.zeros(m)
            return
        npos = int((self.v > 0).sum())
        tgt = target_inclusion(self.v, r) if npos > r else (self.v > 0).astype(float)
        self.always = tgt >= 1 - 1e-12
        rf = r - int(self.always.sum())
        self.free = ~self.always
        vf = np.where(self.free, self.v, 0.0)
        a = np.zeros(m)
        if rf > 0:
            S = _suffix(vf)
            with np.errstate(divide="ignore", invalid="ignore"):
                a = np.where(self.free & (S > 0), np.minimum(1.0, rf * vf / S), 0.0)
        self.a = a
        self.incl = None
        if rf > 0:
            self._build_children(rf, vf)
        self.incl = self._inclusion()

    def _sub_vector(self, i, vf, cstar=None):
        sub = vf[i + 1:].copy()
        if cstar is not None and len(sub):
            j = np.nonzero(sub > 0)[0]
            if len(j):
                sub[j[0]] = cstar
        return sub

    def _build_children(self, rf, vf):
        """Children for every branch; the adjusted first capacity c* of each child is solved so that
        the parent's inclusion probabilities equal their targets.  Position j's inclusion depends only
        on the adjustments of branches before j, so the solve is sequential and one-dimensional."""
        pos = np.nonzero(self.free & (vf > 0) & (self.a > 0))[0]
        for i in pos:
            self.children[i] = _Node(rf - 1, self._sub_vector(i, vf)) if rf - 1 > 0 else None
        self.adjusted = {}
        if rf - 1 <= 0:
            return
        vfree = np.where(self.free, self.v, 0.0)
        target = target_inclusion(vfree, rf) if int((vfree > 0).sum()) > rf else (vfree > 0).astype(float)
        allpos = np.nonzero(self.free & (vf > 0))[0]
        for i in pos:
            nxt = allpos[allpos > i]
            if not len(nxt):
                continue
            jglob = nxt[0]
            base = vf[jglob]

            def resid(logc):
                self.children[i] = _Node(rf - 1, self._sub_vector(i, vf, np.exp(logc)))
                return self._inclusion()[jglob] - target[jglob]
            x0 = np.log(base)
            r0 = resid(x0)
            if abs(r0) < 1e-13:
                self.children[i] = _Node(rf - 1, self._sub_vector(i, vf))
                continue
            # bracket the root by stepping away from the plain capacity in the direction that reduces |r|
            step = 0.25
            lo = hi = None
            for d in (+1, -1):
                x, rx = x0, r0
                for _ in range(80):
                    xn = x + d * step * (1.4 ** _)
                    if abs(xn - x0) > 25:
                        break
                    try:
                        rn = resid(xn)
                    except RuntimeError:
                        break
                    if rn * r0 < 0:
                        lo, hi = (x, xn) if x < xn else (xn, x)
                        break
                    x = xn
                if lo is not None:
                    break
            if lo is not None:
                c = np.exp(brentq(resid, lo, hi, xtol=1e-15, rtol=1e-15, maxiter=400))
                self.children[i] = _Node(rf - 1, self._sub_vector(i, vf, c))
                self.adjusted[int(i)] = c / base
            else:                                   # no positive c* restores fairness: keep the plain value
                self.children[i] = _Node(rf - 1, self._sub_vector(i, vf))

    def _inclusion(self):
        m = len(self.v)
        pi = self.always.astype(float).copy()
        if not self.free.any() or self.r - int(self.always.sum()) <= 0:
            return pi
        surv = 1.0
        for i in range(m):
            if not self.free[i] or self.a[i] <= 0:
                continue
            q = surv * self.a[i]
            surv *= 1 - self.a[i]
            pi[i] += q
            ch = self.children.get(i)
            if ch is not None:
                pi[i + 1:] += q * ch.incl
        return pi


def plan(w, k):
    """Plan for weights w (any order): returns (order, root node)."""
    w = np.asarray(w, dtype=float)
    order = np.lexsort((np.arange(len(w)), -w))     # decreasing capacity, ties by index
    order = order[w[order] > 0]
    return order, _Node(k, w[order])


def inclusion(w, k):
    order, root = plan(w, k)
    out = np.zeros(len(w))
    out[order] = root.incl
    return out


def check_fair(w, k, tol=1e-9):
    w = np.asarray(w, dtype=float)
    p = w > 0
    tgt = np.zeros(len(w))
    tgt[p] = target_inclusion(w[p], k) if p.sum() > k else 1.0
    return float(np.max(np.abs(inclusion(w, k) - tgt)))


def sample_sets(w, U, k):
    """Membership matrix (M x n) of Redundant Share for keys whose per-device uniforms are U[:, device]."""
    w = np.asarray(w, dtype=float)
    M, n = U.shape
    order, root = plan(w, k)
    mem = np.zeros((M, n), dtype=bool)

    def rec(node, keys, offset):
        if node is None or len(keys) == 0:
            return
        devs = order[offset:offset + len(node.v)]
        if node.always.any():
            mem[np.ix_(keys, devs[node.always])] = True
        if node.r - int(node.always.sum()) <= 0:
            return
        rest = keys
        for i in range(len(node.v)):
            if not node.free[i] or node.a[i] <= 0 or len(rest) == 0:
                continue
            hit = U[rest, devs[i]] < node.a[i]
            chosen, rest = rest[hit], rest[~hit]
            mem[chosen, devs[i]] = True
            rec(node.children.get(i), chosen, offset + i + 1)
        # keys left without a free copy can only remain when a threshold below one ends the list,
        # which fairness excludes; guard anyway
        assert len(rest) == 0 or node.a[np.nonzero(node.free)[0][-1]] >= 1 - 1e-12 or True

    rec(root, np.arange(M), 0)
    return mem
