"""Run the unmodified Ceph CRUSH mapper (compiled from the Ceph repository
sources) on a parsed map, via csrc/crush_harness."""
from __future__ import annotations

import os
import subprocess
import tempfile

import numpy as np

from .crushmap import CrushMap, Rule

HERE = os.path.dirname(os.path.abspath(__file__))
HARNESS = os.path.normpath(os.path.join(HERE, "..", "..", "csrc", "build", "crush_harness"))

ALG = {"uniform": 1, "list": 2, "tree": 3, "straw": 4, "straw2": 5}
OP = {("choose", "firstn"): 2, ("choose", "indep"): 3,
      ("chooseleaf", "firstn"): 6, ("chooseleaf", "indep"): 7}
NONE = 0x7FFFFFFF


def _type_ids(cm: CrushMap):
    names = []
    for b in cm.buckets.values():
        if b.type not in names:
            names.append(b.type)
    # device type is 0; bucket types get 1..m in a stable order
    return {t: i + 1 for i, t in enumerate(sorted(names))}


def spec_for(cm: CrushMap, rule: Rule, k: int, n_keys: int, x0: int = 0,
             force_straw2: bool = True, weight_override: dict | None = None,
             tunables: tuple | None = None) -> str:
    """Text spec for the harness.  weight_override: {(bucket_id, child_id): w}."""
    tid = _type_ids(cm)
    lines = []
    if tunables is not None:
        lines.append("T " + " ".join(str(int(t)) for t in tunables))
    for b in cm.buckets.values():
        alg = 5 if force_straw2 else ALG.get(b.alg, 5)
        items = []
        for cid, w in b.items:
            if weight_override and (b.id, cid) in weight_override:
                w = weight_override[(b.id, cid)]
            if w <= 0:
                continue                      # removed / zero-weight child
            items.append((cid, int(round(w * 65536))))
        lines.append(f"B {b.id} {alg} {tid[b.type]} {len(items)} "
                     + " ".join(f"{c} {w}" for c, w in items))
    steps = []
    for s in rule.steps:
        if s[0] == "take":
            b = cm.by_name(s[1]) if isinstance(s[1], str) else cm.buckets[s[1]]
            steps.append((1, b.id, 0))
        elif s[0] in ("choose", "chooseleaf"):
            typ = 0 if s[3] in ("osd", "device") else tid[s[3]]
            steps.append((OP[(s[0], s[1])], s[2], typ))
        elif s[0] == "emit":
            steps.append((4, 0, 0))
    lines.append(f"R {len(steps)} " + " ".join(f"{a} {b} {c}" for a, b, c in steps))
    lines.append(f"X {n_keys} {k} {x0}")
    return "\n".join(lines) + "\n"


def run(spec: str, n_keys: int, k: int) -> np.ndarray:
    with tempfile.TemporaryDirectory() as td:
        sp = os.path.join(td, "spec.txt")
        ob = os.path.join(td, "out.bin")
        with open(sp, "w") as f:
            f.write(spec)
        r = subprocess.run([HARNESS, sp, ob], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"crush_harness failed: {r.stderr}")
        return np.fromfile(ob, dtype=np.int32).reshape(n_keys, k)


def device_parent_of_type(cm: CrushMap, type_name: str) -> dict:
    """device id -> id of its ancestor bucket of the given type."""
    out = {}

    def rec(bid, anc):
        if bid >= 0:
            if anc is not None:
                out[bid] = anc
            return
        b = cm.buckets[bid]
        a = bid if b.type == type_name else anc
        for cid, _ in b.items:
            rec(cid, a)

    child_ids = {c for b in cm.buckets.values() for c, _ in b.items}
    for bid in cm.buckets:
        if bid not in child_ids:
            rec(bid, None)
    return out


TOPK = os.path.normpath(os.path.join(HERE, "..", "..", "csrc", "build", "topk_harness"))


def flat_spec(weights, k: int, n_keys: int, x0: int = 0, always: str = "flag") -> str:
    """Spec for a single flat straw2 bucket whose items are 0..n-1.

    weights: positive floats, 0 = absent, inf = capped ("always selected").
    always = "flag": write -1 (understood by topk_harness);
    always = "big" : write the largest 16.16 weight while the finite weights are
                     scaled down to a 1:16383 ratio (for the unmodified mapper).
    """
    import numpy as np
    w = np.asarray(weights, dtype=float)
    fin = w[np.isfinite(w) & (w > 0)]
    has_inf = bool(np.isinf(w).any())
    # 16.16 fixed point; the unmodified builder takes signed 32-bit ints (< 32768.0)
    top = 2.0 if (has_inf and always == "big") else 16000.0
    scale = top / fin.max() if len(fin) else 1.0
    items = []
    for i, x in enumerate(w):
        if x == 0:
            continue
        if np.isinf(x):
            items.append((i, -1 if always == "flag" else int(32767.0 * 65536)))
        else:
            items.append((i, max(1, int(round(x * scale * 65536)))))
    lines = [f"B -1 5 1 {len(items)} " + " ".join(f"{c} {v}" for c, v in items),
             "R 3 1 -1 0 2 0 0 4 0 0", f"X {n_keys} {k} {x0}"]
    return "\n".join(lines) + "\n"


def run_binary(binary: str, spec: str, n_keys: int, k: int):
    """Returns (mapping array [n_keys, k], ns_per_mapping or None)."""
    with tempfile.TemporaryDirectory() as td:
        sp = os.path.join(td, "spec.txt")
        ob = os.path.join(td, "out.bin")
        with open(sp, "w") as f:
            f.write(spec)
        r = subprocess.run([binary, sp, ob], capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"{binary} failed: {r.stderr}")
        ns = None
        for tok in r.stderr.split():
            if tok.startswith("ns_per_mapping="):
                ns = float(tok.split("=")[1])
        return np.fromfile(ob, dtype=np.int32).reshape(n_keys, k), ns


def membership(res: np.ndarray, n: int) -> np.ndarray:
    mem = np.zeros((res.shape[0], n), dtype=bool)
    for j in range(res.shape[1]):
        ok = res[:, j] != NONE
        mem[np.nonzero(ok)[0], res[ok, j]] = True
    return mem
