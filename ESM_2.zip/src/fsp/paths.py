"""Locations used by the experiment scripts.

FSP_ROOT : root of the replication package (default: two levels above this file)
FSP_RAW  : directory holding the downloaded repositories / cluster maps
           (default: <root>/data/raw; see data/PROVENANCE.md)
"""
import os

ROOT = os.environ.get("FSP_ROOT", os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")))
RAW = os.environ.get("FSP_RAW", os.path.join(ROOT, "data", "raw"))
OUT = os.path.join(ROOT, "out")
os.makedirs(OUT, exist_ok=True)
