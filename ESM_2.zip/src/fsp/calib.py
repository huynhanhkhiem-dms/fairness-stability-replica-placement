"""Calibrated order sampling (COS): working weights lambda(w) such that top-k
order sampling with scores lambda_i * X_i has EXACTLY the fair (capped
proportional) inclusion probabilities.

Existence and uniqueness of the calibrated parameters for fixed-shape order
sampling is due to Aires, Jonasson & Nerman (2002); here we only need a robust
solver.  Capped nodes (target 1) are always selected and removed from the race.
"""
from __future__ import annotations

import numpy as np

from .core import inclusion, target_inclusion


def _newton_exp(tgt, kf, x0, tol, max_iter=200):
    """Damped Newton iteration for the exponential race: find x = log(lambda) with
    pi_ss(exp(x)) = tgt.  The Jacobian of pi_ss with respect to x is the graph
    Laplacian of the conductances (Proposition "convex"), so the Newton direction d
    solves L d = -(p - tgt); since L is positive definite on the complement of the
    constants, the Euclidean norm of the residual decreases along d, and
    backtracking on that norm cannot stall.  The quadrature (log time) and the
    linear solve (multiple precision) stay accurate when some targets are close to
    one and the working weights span many orders of magnitude."""
    from .laplacian import laplacian_solve, race_p_phi
    x = np.asarray(x0, dtype=float).copy()
    x -= x.max()
    p, phi = race_p_phi(np.exp(x), kf)
    r = p - tgt
    it = 0
    for it in range(1, max_iter + 1):
        err = float(np.max(np.abs(r)))
        if err < tol:
            break
        d = laplacian_solve(phi, -(r - r.mean()))
        d -= d.mean()
        d *= min(1.0, 4.0 / np.max(np.abs(d)))          # at most a factor e^4 per step
        t, nr = 1.0, float(np.linalg.norm(r))
        while True:
            xn = x + t * d
            xn -= xn.max()
            pn = race_p_phi(np.exp(xn), kf, need_phi=False)[0]
            if np.all(np.isfinite(pn)) and np.linalg.norm(pn - tgt) < nr * (1 - 1e-4 * t):
                break
            t *= 0.5
            if t < 1e-8:
                break
        x = xn
        p, phi = race_p_phi(np.exp(x), kf)
        r = p - tgt
    return x, float(np.max(np.abs(r))), it


def calibrate(w, k, shape="exp", tol=1e-10, max_iter=500, lam0=None, return_info=False, strict=None):
    """Return (lam, always) where `always` is a boolean mask of nodes selected
    with probability one (lam = +inf there) and lam[~always] are positive
    working weights normalised to geometric mean of w on the free set.

    A fast fixed-point iteration is tried first; if it has not converged after 60
    steps (targets close to one, many replicas) the exact Newton method takes over.
    With strict=True (the default unless return_info is requested) a RuntimeError is
    raised when the final error exceeds 1e-8, so that no experiment can silently use
    uncalibrated weights."""
    w = np.asarray(w, dtype=float)
    n = len(w)
    pi_t = target_inclusion(w, k)
    always = pi_t >= 1.0 - 1e-13
    free = ~always
    kf = k - int(always.sum())
    lam = np.full(n, np.inf)
    info = dict(iters=0, err=0.0, k_free=kf)
    if kf == 0 or free.sum() == 0:
        return (lam, always, info) if return_info else (lam, always)
    wf = w[free]
    tgt = pi_t[free]
    x = np.log(wf if lam0 is None else np.asarray(lam0, dtype=float)[free])
    x = x - x.mean()
    logit = lambda p: np.log(p) - np.log1p(-p)
    lt = logit(tgt)
    err = np.inf
    fp_status = "max_iter"
    for it in range(1, max_iter + 1):
        with np.errstate(all="ignore"):
            cur = inclusion(np.exp(x), kf, shape)
        if not np.all(np.isfinite(cur)):
            err = np.inf
            fp_status = "non-finite"
            break
        cur = np.clip(cur, 1e-300, 1 - 1e-16)
        r = lt - logit(cur)
        err = float(np.max(np.abs(cur - tgt)))
        if err < tol:
            fp_status = "converged"
            break
        if it >= 60 and shape == "exp":            # the fast iteration is not converging: use the robust solver
            err = np.inf
            fp_status = "slow"
            break
        # Newton step with a finite-difference Jacobian every few iterations is
        # overkill for the sizes we need; a damped fixed-point on the logit
        # scale converges linearly and monotonically in practice.  We switch to
        # Newton when progress stalls.
        if it <= 6 or it % 4:
            x = x + r
        else:
            m = len(x)
            J = np.empty((m, m))
            h = 1e-6
            base = logit(cur)
            for j in range(m):
                xp = x.copy()
                xp[j] += h
                J[:, j] = (logit(np.clip(inclusion(np.exp(xp), kf, shape), 1e-300, 1 - 1e-16)) - base) / h
            # the map is invariant to a common shift: solve in the subspace sum(dx)=0
            A = np.vstack([J, np.ones((1, m))])
            b = np.concatenate([r, [0.0]])
            dx, *_ = np.linalg.lstsq(A, b, rcond=None)
            x = x + dx
        x = x - x.mean()
    info.update(iters=it, err=err, method="fixed-point", fp_iters=it, fp_status=fp_status)
    if not err < tol and shape == "exp":
        # robust fallback (cap-adjacent targets, large k): exact Newton from the raw weights
        x, err, it2 = _newton_exp(tgt, kf, np.log(wf), tol)
        x = x - x.mean()
        info.update(iters=it + it2, err=err, method="newton")
    lam[free] = np.exp(x + np.log(wf).mean())
    if (not return_info if strict is None else strict) and not info["err"] < 1e-8:
        raise RuntimeError(f"calibration did not converge: {info}")
    return (lam, always, info) if return_info else (lam, always)


def cos_inclusion(w, k, shape="exp", **kw):
    """Inclusion probabilities actually realised by COS (for verification)."""
    lam, always = calibrate(w, k, shape, **kw)
    out = np.ones(len(lam))
    free = ~always
    if free.any():
        out[free] = inclusion(lam[free], k - int(always.sum()), shape)
    return out
