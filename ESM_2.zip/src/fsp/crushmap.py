"""Minimal CRUSH map reader (decompiled text, `ceph report` JSON, python-crush JSON).

Only what the analysis needs: the bucket tree with item weights and, for each
rule, the `take` root and the failure-domain type of its firstn/indep choose
step.  No placement logic lives here.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field


@dataclass
class Bucket:
    id: int
    name: str
    type: str
    alg: str = "straw2"
    items: list = field(default_factory=list)      # list of (child_id, weight)


@dataclass
class Rule:
    name: str
    steps: list                                     # list of tuples


@dataclass
class CrushMap:
    source: str
    devices: dict = field(default_factory=dict)     # id -> name
    buckets: dict = field(default_factory=dict)     # id -> Bucket
    rules: list = field(default_factory=list)
    pools: list = field(default_factory=list)       # (name, size, rule id/name)
    meta: dict = field(default_factory=dict)

    def by_name(self, name):
        for b in self.buckets.values():
            if b.name == name:
                return b
        return None

    # ---- tree helpers -------------------------------------------------
    def domains_under(self, root_id: int, type_name: str):
        """Probability that a single weighted descent from `root_id` reaches
        each bucket of type `type_name` (or each device if type is the leaf
        type).  Returns list of (id, name, prob, raw_weight)."""
        out = []

        def rec(bid, prob, wraw):
            if bid >= 0:                               # device
                if type_name in ("osd", "device") or type_name is None:
                    out.append((bid, self.devices.get(bid, f"osd.{bid}"), prob, wraw))
                return
            b = self.buckets[bid]
            if b.type == type_name:
                out.append((bid, b.name, prob, wraw))
                return
            tot = sum(w for _, w in b.items if w > 0)
            if tot <= 0:
                return
            for cid, w in b.items:
                if w > 0:
                    rec(cid, prob * w / tot, w)

        rec(root_id, 1.0, None)
        return out


# ---------------------------------------------------------------------------
_num = r"[-+]?\d+(?:\.\d+)?"


def parse_text(path: str) -> CrushMap:
    cm = CrushMap(source=path)
    types = {}
    name2id = {}
    pending = []                 # (bucket, [(child_name, weight)])
    lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    i = 0
    typenames = set()
    while i < len(lines):
        ln = lines[i].split("#")[0].strip()
        i += 1
        if not ln:
            continue
        m = re.match(r"device\s+(\d+)\s+(\S+)", ln)
        if m:
            cm.devices[int(m.group(1))] = m.group(2)
            name2id[m.group(2)] = int(m.group(1))
            continue
        m = re.match(r"type\s+(\d+)\s+(\S+)", ln)
        if m:
            types[int(m.group(1))] = m.group(2)
            typenames.add(m.group(2))
            continue
        m = re.match(r"tunable\s+(\S+)\s+(\S+)", ln)
        if m:
            cm.meta.setdefault("tunables", {})[m.group(1)] = m.group(2)
            continue
        m = re.match(r"rule\s+(\S+)?\s*\{", ln)
        if m:
            name = m.group(1) or f"rule{len(cm.rules)}"
            steps = []
            while i < len(lines):
                s = lines[i].split("#")[0].strip()
                i += 1
                if s.startswith("}"):
                    break
                ms = re.match(r"step\s+take\s+(\S+)(?:\s+class\s+(\S+))?", s)
                if ms:
                    steps.append(("take", ms.group(1), ms.group(2)))
                    continue
                ms = re.match(r"step\s+(chooseleaf|choose)\s+(firstn|indep)\s+(-?\d+)\s+type\s+(\S+)", s)
                if ms:
                    steps.append((ms.group(1), ms.group(2), int(ms.group(3)), ms.group(4)))
                    continue
                if re.match(r"step\s+emit", s):
                    steps.append(("emit",))
            cm.rules.append(Rule(name, steps))
            continue
        m = re.match(r"choose_args\s+\S+\s*\{", ln)
        if m:                                   # skip nested block
            depth = 1
            while i < len(lines) and depth > 0:
                depth += lines[i].count("{") - lines[i].count("}")
                i += 1
            continue
        m = re.match(r"(\S+)\s+(\S+)\s*\{", ln)
        if m and m.group(1) in typenames:
            b = Bucket(id=0, name=m.group(2), type=m.group(1))
            kids = []
            got_id = False
            while i < len(lines):
                s = lines[i].split("#")[0].strip()
                i += 1
                if s.startswith("}"):
                    break
                mi = re.match(r"id\s+(-?\d+)(\s+class\s+\S+)?", s)
                if mi:
                    if not mi.group(2) and not got_id:
                        b.id = int(mi.group(1))
                        got_id = True
                    continue
                mi = re.match(r"alg\s+(\S+)", s)
                if mi:
                    b.alg = mi.group(1)
                    continue
                mi = re.match(rf"item\s+(\S+)(?:\s+weight\s+({_num}))?", s)
                if mi:
                    kids.append((mi.group(1), float(mi.group(2)) if mi.group(2) else 1.0))
            if not got_id:
                b.id = -(len(cm.buckets) + 1000)
            cm.buckets[b.id] = b
            name2id[b.name] = b.id
            pending.append((b, kids))
    for b, kids in pending:
        for cname, w in kids:
            if cname in name2id:
                b.items.append((name2id[cname], w))
    return cm


def parse_ceph_json(obj: dict, source: str) -> CrushMap:
    """`ceph report` (has 'crushmap' and 'osdmap') or a bare `ceph osd crush dump`."""
    cmj = obj.get("crushmap", obj)
    cm = CrushMap(source=source)
    for d in cmj.get("devices", []):
        cm.devices[d["id"]] = d["name"]
    for b in cmj.get("buckets", []):
        bk = Bucket(id=b["id"], name=b["name"], type=b.get("type_name", str(b.get("type_id"))),
                    alg=b.get("alg", "straw2"))
        for it in b.get("items", []):
            bk.items.append((it["id"], it["weight"] / 65536.0))
        cm.buckets[bk.id] = bk
    for r in cmj.get("rules", []):
        steps = []
        for s in r.get("steps", []):
            op = s["op"]
            if op == "take":
                steps.append(("take", s.get("item_name", s.get("item")), None))
            elif op.startswith("choose"):
                kind, mode = op.split("_")
                steps.append((kind, mode, s["num"], s["type"]))
            elif op == "emit":
                steps.append(("emit",))
        cm.rules.append(Rule(r.get("rule_name", str(r.get("rule_id"))), steps))
    om = obj.get("osdmap") or {}
    for p in om.get("pools", []):
        cm.pools.append((p.get("pool_name"), p.get("size"),
                         p.get("crush_rule", p.get("crush_ruleset")), p.get("pg_num")))
    for key in ("version", "timestamp", "cluster_fingerprint"):
        if key in obj:
            cm.meta[key] = obj[key]
    return cm


def parse_pycrush_json(obj: dict, source: str) -> CrushMap:
    """python-crush native format: {'trees': [...nested children...], 'rules': {...}}."""
    cm = CrushMap(source=source)
    auto = [-10_000]

    def rec(node):
        if "children" not in node:                      # device
            did = node["id"]
            cm.devices[did] = node.get("name", f"osd.{did}")
            return did, float(node.get("weight", 1.0)) / (65536.0 if isinstance(node.get("weight"), int) and node.get("weight", 0) > 4096 else 1.0)
        bid = node.get("id")
        if bid is None:
            auto[0] -= 1
            bid = auto[0]
        bk = Bucket(id=bid, name=node.get("name", str(bid)), type=node.get("type", "bucket"),
                    alg=node.get("algorithm", "straw2"))
        tot = 0.0
        for ch in node["children"]:
            cid, w = rec(ch)
            bk.items.append((cid, w))
            tot += w
        cm.buckets[bid] = bk
        w = node.get("weight")
        if w is None:
            w = tot
        elif isinstance(w, int) and w > 4096:
            w = w / 65536.0
        return bid, float(w)

    for t in obj.get("trees", []):
        rec(t)
    for name, steps in (obj.get("rules") or {}).items():
        st = []
        for s in steps:
            if s[0] == "take":
                st.append(("take", s[1], None))
            elif s[0] in ("choose", "chooseleaf"):
                st.append((s[0], s[1], int(s[2]), s[4]))
            elif s[0] == "emit":
                st.append(("emit",))
        cm.rules.append(Rule(name, st))
    return cm


CRUSH_MAGIC = 0x00010000
_ALG_NAME = {1: "uniform", 2: "list", 3: "tree", 4: "straw", 5: "straw2"}
_OPS = {2: ("choose", "firstn"), 3: ("choose", "indep"),
        6: ("chooseleaf", "firstn"), 7: ("chooseleaf", "indep")}


def parse_binary(buf: bytes, source: str, offset: int = 0) -> CrushMap:
    """Decoder for the compiled CRUSH map encoding, following
    CrushWrapper::decode / decode_crush_bucket in the Ceph sources
    (little endian; only the fields the analysis needs are kept)."""
    import struct

    pos = [offset]

    def rd(fmt):
        size = struct.calcsize("<" + fmt)
        if pos[0] + size > len(buf):
            raise ValueError("truncated")
        v = struct.unpack_from("<" + fmt, buf, pos[0])
        pos[0] += size
        return v[0] if len(v) == 1 else v

    if rd("I") != CRUSH_MAGIC:
        raise ValueError("bad magic")
    max_buckets, max_rules, max_devices = rd("i"), rd("I"), rd("i")
    if not (0 <= max_buckets < 1_000_000 and max_rules < 100_000 and 0 <= max_devices < 10_000_000):
        raise ValueError("implausible header")
    cm = CrushMap(source=source)
    raw = []
    for _ in range(max_buckets):
        alg = rd("I")
        if alg == 0:
            continue
        if alg not in _ALG_NAME:
            raise ValueError("bad alg")
        bid, btype, balg, bhash, bweight, size = rd("i"), rd("H"), rd("B"), rd("B"), rd("I"), rd("I")
        if size > 1_000_000:
            raise ValueError("implausible bucket size")
        items = [rd("i") for _ in range(size)]
        if balg == 1:
            iw = rd("I")
            weights = [iw] * size
        elif balg == 2:
            weights = []
            for _ in range(size):
                weights.append(rd("I"))
                rd("I")
        elif balg == 3:
            nn = rd("B") if False else rd("I")
            node_w = [rd("I") for _ in range(nn)]
            # leaf i sits at node ((i + 1) << 1) - 1
            weights = [node_w[((i + 1) << 1) - 1] if ((i + 1) << 1) - 1 < nn else 0 for i in range(size)]
        elif balg == 4:
            weights = []
            for _ in range(size):
                weights.append(rd("I"))
                rd("I")
        else:
            weights = [rd("I") for _ in range(size)]
        raw.append((bid, btype, balg, items, weights))
    rules_raw = []
    for i in range(max_rules):
        if rd("I") == 0:
            continue
        ln = rd("I")
        if ln > 10_000:
            raise ValueError("implausible rule")
        rd("B"); rtype = rd("B"); rd("B"); rd("B")
        steps = [(rd("I"), rd("i"), rd("i")) for _ in range(ln)]
        rules_raw.append((i, rtype, steps))

    def strmap():
        out = {}
        n = rd("I")
        if n > 5_000_000:
            raise ValueError("implausible map")
        for _ in range(n):
            key = rd("i")
            sl = rd("I")
            if sl == 0:
                sl = rd("I")
            if sl > 4096:
                raise ValueError("implausible string")
            out[key] = buf[pos[0]:pos[0] + sl].decode("utf-8", "replace")
            pos[0] += sl
        return out

    type_map, name_map, rule_names = strmap(), strmap(), strmap()
    tun = {}
    try:
        tun["choose_local_tries"], tun["choose_local_fallback_tries"], tun["choose_total_tries"] = rd("I"), rd("I"), rd("I")
        tun["chooseleaf_descend_once"] = rd("I")
        tun["chooseleaf_vary_r"] = rd("B")
        tun["straw_calc_version"] = rd("B")
        tun["allowed_bucket_algs"] = rd("I")
        tun["chooseleaf_stable"] = rd("B")
    except Exception:
        pass
    cm.meta["tunables"] = tun
    for bid, btype, balg, items, weights in raw:
        b = Bucket(id=bid, name=name_map.get(bid, str(bid)), type=type_map.get(btype, str(btype)),
                   alg=_ALG_NAME[balg])
        b.items = [(c, w / 65536.0) for c, w in zip(items, weights)]
        cm.buckets[bid] = b
        for c in items:
            if c >= 0:
                cm.devices[c] = name_map.get(c, f"osd.{c}")
    for i, rtype, steps in rules_raw:
        st = []
        for op, a1, a2 in steps:
            if op == 1:
                st.append(("take", a1, None))
            elif op in _OPS:
                st.append((*_OPS[op], a1, type_map.get(a2, "osd" if a2 == 0 else str(a2))))
            elif op == 4:
                st.append(("emit",))
        r = Rule(rule_names.get(i, f"rule{i}"), st)
        cm.rules.append(r)
        cm.meta.setdefault("rule_types", {})[r.name] = rtype
    return cm


def find_binary(buf: bytes, source: str):
    """Locate and decode a compiled CRUSH map embedded in a larger blob (osdmap)."""
    magic = (CRUSH_MAGIC).to_bytes(4, "little")
    start = 0
    best = None
    while True:
        j = buf.find(magic, start)
        if j < 0:
            break
        try:
            cm = parse_binary(buf, source, j)
            if cm.buckets and cm.rules and (best is None or len(cm.buckets) > len(best.buckets)):
                best = cm
        except Exception:
            pass
        start = j + 1
    return best


def load(path: str) -> CrushMap:
    with open(path, "rb") as f:
        head = f.read(4)
    if head == (CRUSH_MAGIC).to_bytes(4, "little"):
        return parse_binary(open(path, "rb").read(), path)
    if path.endswith(".json"):
        obj = json.load(open(path, encoding="utf-8"))
        if "trees" in obj:
            return parse_pycrush_json(obj, path)
        return parse_ceph_json(obj, path)
    if "osdmap" in path.rsplit("/", 1)[-1] and not path.endswith((".h", ".t", ".txt")):
        cm = find_binary(open(path, "rb").read(), path)
        if cm is not None:
            return cm
    return parse_text(path)


def rule_domains(cm: CrushMap, rule: Rule):
    """For a rule: (take bucket, list of choose steps).  The first firstn/indep
    choose step whose count is 0 (or >1) is where distinct replicas are drawn."""
    take = None
    chooses = []
    for s in rule.steps:
        if s[0] == "take":
            take = cm.by_name(s[1]) if isinstance(s[1], str) else cm.buckets.get(s[1])
        elif s[0] in ("choose", "chooseleaf"):
            chooses.append(s)
    return take, chooses


def multipick_instances(cm: CrushMap, rule: Rule, max_contexts: int = 64):
    """Decompose a rule into the bucket-selection problems in which several
    DISTINCT domains are drawn from one weighted population.

    Returns a list of dicts: root (id), level (type name), num (rule argument:
    >1 fixed count, <=0 'pool size'), mode ('firstn'/'indep'), ids, weights
    (single-descent probabilities from root, normalised), ctx_prob (probability
    that the rule reaches this root at all).
    """
    take = None
    contexts = []
    out = []
    for s in rule.steps:
        if s[0] == "take":
            take = cm.by_name(s[1]) if isinstance(s[1], str) else cm.buckets.get(s[1])
            contexts = [(take.id, 1.0)] if take is not None else []
        elif s[0] in ("choose", "chooseleaf") and contexts:
            kind, mode, num, typ = s
            nxt = []
            for root, cp in contexts[:max_contexts]:
                dom = cm.domains_under(root, typ)
                if not dom:
                    continue
                p = [d[2] for d in dom]
                tot = sum(p)
                if tot <= 0:
                    continue
                if num != 1 and len(dom) >= 2:
                    out.append(dict(root=root, level=typ, num=num, mode=mode, kind=kind,
                                    ids=[d[0] for d in dom], names=[d[1] for d in dom],
                                    weights=[x / tot for x in p], ctx_prob=cp))
                if kind == "choose":
                    nxt += [(d[0], cp * d[2] / tot) for d in dom if d[0] < 0]
            contexts = nxt
        elif s[0] == "emit":
            contexts = []
    return out
