"""Reference placement rules used as baselines (all stateless: a rule is a
function of the current weights and of permanent per-key random numbers).

  retry_sets       : CRUSH firstn semantics -- i.i.d. weighted draws d_0, d_1, ...
                     (each draw is an exponential race with its own random
                     numbers), keep the first k distinct values.  Same law as
                     single-order top-k, different coupling.
  systematic_sets  : Madow's systematic pps sampling in node-id order (exactly fair).
  pivotal_sets     : Deville-Tille ordered pivotal sampling in node-id order
                     (exactly fair), one permanent random number per node.
"""
from __future__ import annotations

import numpy as np

from .core import target_inclusion


def retry_sets(mult: np.ndarray, m: int, k: int, seed: int = 0, max_draws: int = 64) -> np.ndarray:
    """mult: per-node weights (0 = absent, inf = always).  Returns bool [m, n]."""
    mult = np.asarray(mult, dtype=float)
    n = len(mult)
    mem = np.zeros((m, n), dtype=bool)
    cnt = np.zeros(m, dtype=np.int64)
    inf = np.isinf(mult)
    eff = np.where(inf, 0.0, mult)
    with np.errstate(divide="ignore"):
        logw = np.where(eff > 0, np.log(np.where(eff > 0, eff, 1.0)), -np.inf)
    for r in range(max_draws):
        # the r-th draw uses its own permanent stream (seed, r): independent of weights
        rng = np.random.default_rng([seed, r])
        g = -np.log(-np.log(rng.random((m, n))))          # Gumbel
        s = logw[None, :] + g
        s[:, inf] = np.inf                                 # always-selected nodes win ties first
        if inf.any():
            # break ties among several infinite-weight nodes by their Gumbel
            s[:, inf] = 1e300 + g[:, inf]
        d = np.argmax(s, axis=1)
        need = cnt < k
        new = need & ~mem[np.arange(m), d]
        mem[new, d[new]] = True
        cnt += new
        if (cnt >= k).all():
            break
    return mem


def systematic_sets(w: np.ndarray, m: int, k: int, seed: int = 0) -> np.ndarray:
    w = np.asarray(w, dtype=float)
    n = len(w)
    present = w > 0
    pi = np.zeros(n)
    pi[present] = target_inclusion(w[present], k)
    c = np.concatenate(([0.0], np.cumsum(pi)))
    c[-1] = k
    u = np.random.default_rng([seed, 991]).random(m)       # one permanent number per key
    mem = np.zeros((m, n), dtype=bool)
    for j in range(k):
        idx = np.searchsorted(c, u + j, side="right") - 1
        idx = np.clip(idx, 0, n - 1)
        mem[np.arange(m), idx] = True
    return mem


def pivotal_sets(w: np.ndarray, m: int, k: int, seed: int = 0) -> np.ndarray:
    w = np.asarray(w, dtype=float)
    n = len(w)
    present = np.where(w > 0)[0]
    pi = target_inclusion(w[present], k)
    U = np.random.default_rng([seed, 992]).random((m, n))  # permanent number of node j = U[:, j]
    mem = np.zeros((m, n), dtype=bool)
    cur = np.full(m, present[0])                           # index of the undecided unit
    pc = np.full(m, pi[0])                                 # its current probability
    rows = np.arange(m)
    for t in range(1, len(present)):
        b = present[t]
        pb = pi[t]
        u = U[:, b]
        s = pc + pb
        lo = s < 1.0
        # case s < 1: one unit keeps s, the other is discarded
        keep_cur = u < np.where(s > 0, pc / np.where(s > 0, s, 1.0), 1.0)
        # case s >= 1: one unit is selected, the other keeps s - 1
        denom = 2.0 - s
        sel_cur = u < np.where(denom > 1e-15, (1.0 - pb) / np.where(denom > 1e-15, denom, 1.0), 1.0)
        hi = ~lo
        # selections
        sc = hi & sel_cur
        sb = hi & ~sel_cur
        mem[rows[sc], cur[sc]] = True
        mem[rows[sb], b] = True
        # who stays undecided
        new_cur = cur.copy()
        new_cur[(lo & ~keep_cur) | sc] = b
        new_pc = np.where(lo, s, s - 1.0)
        cur, pc = new_cur, new_pc
    last = pc > 0.5
    mem[rows[last], cur[last]] = True
    return mem
