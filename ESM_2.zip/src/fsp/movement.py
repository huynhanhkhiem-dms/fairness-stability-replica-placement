"""Movement accounting with common random numbers.

A "rule" maps a weight vector to per-node score multipliers:
    scores(key, i) = mult_i * X(key, i)      (+inf multiplier = always selected)
Two configurations are compared on the SAME keys (same X), exactly as a
deterministic hash would behave.  Nodes absent from a configuration have
multiplier 0.
"""
from __future__ import annotations

import numpy as np

from .core import _shape_fns, target_inclusion
from .calib import calibrate


def draws(m: int, n: int, seed: int = 0) -> np.ndarray:
    """Uniform(0,1) variates U[key, node]; column j is the permanent random
    number stream of node j (independent of the configuration)."""
    rng = np.random.default_rng(seed)
    return rng.random((m, n))


def topk_sets(mult: np.ndarray, U: np.ndarray, k: int, shape="exp") -> np.ndarray:
    """Boolean membership matrix [key, node] of the top-k scores mult_i * X_i."""
    ppf, _ = _shape_fns(shape)
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        s = np.where(mult[None, :] > 0, mult[None, :] * ppf(U), -1.0)
    s[:, np.isinf(mult)] = np.inf
    idx = np.argpartition(-s, k - 1, axis=1)[:, :k]
    mem = np.zeros(U.shape, dtype=bool)
    np.put_along_axis(mem, idx, True, axis=1)
    return mem


def multipliers(rule: str, w: np.ndarray, k: int, shape="exp") -> np.ndarray:
    """rule = 'raw' (scores w_i X_i: stable, biased) or 'cos' (calibrated: fair)."""
    w = np.asarray(w, dtype=float)
    present = w > 0
    out = np.zeros(len(w))
    if rule == "raw":
        out[present] = w[present]
    elif rule == "cos":
        lam, always = calibrate(w[present], k, shape)
        out[present] = lam
    else:
        raise ValueError(rule)
    return out


def moved(mem_a: np.ndarray, mem_b: np.ndarray) -> float:
    """Expected number of replicas per key that must be copied: |R_b minus R_a|."""
    return float((mem_b & ~mem_a).sum() / mem_a.shape[0])


def moved_stats(mem_a: np.ndarray, mem_b: np.ndarray) -> tuple[float, float]:
    """Sample mean and unbiased standard error of the *per-key* number of moved replicas.

    Individual keys, not individual replica moves, are the Monte Carlo units.  This
    remains valid when several replicas move for one key; Poisson sqrt(mean/N)
    would be inappropriate for such outcomes.
    """
    counts = np.count_nonzero(mem_b & ~mem_a, axis=1).astype(float)
    return float(np.mean(counts)), float(np.std(counts, ddof=1) / np.sqrt(len(counts)))


def optimal_moved(pi_a: np.ndarray, pi_b: np.ndarray) -> float:
    """Transport lower bound for ANY rule realising these inclusion vectors."""
    return float(np.clip(pi_b - pi_a, 0, None).sum())


def fair(w: np.ndarray, k: int) -> np.ndarray:
    w = np.asarray(w, dtype=float)
    out = np.zeros(len(w))
    present = w > 0
    out[present] = target_inclusion(w[present], k)
    return out
