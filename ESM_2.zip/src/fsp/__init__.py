"""fsp: fair-and-stable placement toolkit (exact inclusion probabilities,
calibration, movement accounting and CRUSH map parsing)."""
