"""Exact inclusion probabilities for stateless top-k ("order sampling") placement.

A placement rule in this module is: every node i draws a score
    s_i = w_i * X_i,   X_i i.i.d. with a fixed "shape" law,
and a key is stored on the k nodes with the largest scores.

  shape = "exp"      X = 1/E, E ~ Exp(1)   -> weighted rendezvous hashing / straw2,
                                             a.k.a. successive sampling (PPSWOR)
  shape = "uniform"  X = 1/U, U ~ U(0,1)   -> priority sampling (Duffield-Lund-Thorup)
  shape = "pareto"   X = (1-U)/U           -> Pareto order sampling with sizes w
  shape = ("power", b)  X = U^(-1/b)       -> one-parameter family; b=1 is "uniform"

All routines are deterministic numerical integrations (no Monte Carlo); the
Monte Carlo and brute-force checks live in tests/.
"""
from __future__ import annotations

import itertools
import math
from typing import Callable, Sequence

import numpy as np

# --------------------------------------------------------------------------
# Fair target: capped proportional ("water-filling") inclusion probabilities
# --------------------------------------------------------------------------

def target_inclusion(w: Sequence[float], k: int) -> np.ndarray:
    """Capped-proportional target: pi_i = min(1, w_i / tau), sum(pi) = k.

    Without caps this is k * w_i / W.  Nodes with w_i > W/k cannot receive a
    proportional share with distinct replicas; they are capped at 1 and the
    remaining replicas are shared proportionally among the rest.
    """
    w = np.asarray(w, dtype=float)
    n = len(w)
    if k > n:
        raise ValueError("k > n")
    if k == n:
        return np.ones(n)
    order = np.argsort(-w)
    ws = w[order]
    pi = np.empty(n)
    capped = 0
    rest = ws.sum()
    while True:
        tau = rest / (k - capped)
        if ws[capped] > tau * (1 + 1e-15):
            rest -= ws[capped]
            capped += 1
            if capped == k:  # cannot happen when k < n and all w > 0
                raise RuntimeError("degenerate water-filling")
        else:
            break
    pi_sorted = np.minimum(1.0, ws / tau)
    pi_sorted[:capped] = 1.0
    pi[order] = pi_sorted
    return pi


# --------------------------------------------------------------------------
# Shapes: survival function of the score  S_j(s) = P(w_j X_j > s)
# and quantile of X.
# --------------------------------------------------------------------------

def _shape_fns(shape):
    """Return (ppf, sf) for X: ppf(u) = F^{-1}(u), sf(x) = P(X > x)."""
    if shape == "exp":           # X = 1/E ; P(X > x) = P(E < 1/x) = 1 - exp(-1/x)
        ppf = lambda u: -1.0 / np.log(u)             # F(x)=exp(-1/x)
        sf = lambda x: -np.expm1(-1.0 / x)
        return ppf, sf
    if shape == "uniform":       # X = 1/U ; P(X > x) = min(1, 1/x)
        ppf = lambda u: 1.0 / (1.0 - u)
        sf = lambda x: np.minimum(1.0, 1.0 / x)
        return ppf, sf
    if shape == "pareto":        # X = (1-U)/U ; P(X > x) = 1/(1+x)
        ppf = lambda u: u / (1.0 - u)
        sf = lambda x: 1.0 / (1.0 + x)
        return ppf, sf
    if isinstance(shape, tuple) and shape[0] == "power":
        b = float(shape[1])      # X = U^(-1/b) ; P(X > x) = min(1, x^-b)
        ppf = lambda u: (1.0 - u) ** (-1.0 / b)
        sf = lambda x: np.minimum(1.0, x ** (-b))
        return ppf, sf
    if isinstance(shape, tuple) and shape[0] == "frechet":
        a = float(shape[1])      # X = E^(-1/a) ; P(X > x) = 1 - exp(-x^-a); a=1 is "exp"
        ppf = lambda u: (-np.log(u)) ** (-1.0 / a)
        sf = lambda x: -np.expm1(-(x ** (-a)))
        return ppf, sf
    raise ValueError(f"unknown shape {shape!r}")


def _at_most(q: np.ndarray, m: int) -> np.ndarray:
    """P(at most m successes) for independent Bernoulli(q[j, :]) rows.

    q has shape (n_other, n_grid).  Returns array of shape (n_grid,).
    DP over the number of successes, truncated at m (O(n*m) per grid point).
    """
    g = q.shape[1]
    dp = np.zeros((m + 1, g))
    dp[0] = 1.0
    for j in range(q.shape[0]):
        qj = q[j]
        # iterate counts downwards so that dp[c-1] is still the old value
        for c in range(m, 0, -1):
            dp[c] = dp[c] * (1.0 - qj) + dp[c - 1] * qj
        dp[0] = dp[0] * (1.0 - qj)
    return dp.sum(axis=0)


# Gauss-Legendre nodes on (0,1), reused.
_GL_CACHE: dict[int, tuple[np.ndarray, np.ndarray]] = {}


def _gl(m: int):
    if m not in _GL_CACHE:
        x, wt = np.polynomial.legendre.leggauss(m)
        _GL_CACHE[m] = (0.5 * (x + 1.0), 0.5 * wt)
    return _GL_CACHE[m]


def inclusion(w: Sequence[float], k: int, shape="exp", panels: int = 64,
              order: int = 48) -> np.ndarray:
    """Exact (to quadrature accuracy) inclusion probabilities of top-k order
    sampling with scores w_i X_i.

    P(i in top-k) = int_0^1 P( #{j != i : w_j X_j > w_i F^{-1}(u)} <= k-1 ) du.

    The integrand is piecewise smooth in u; we use composite Gauss-Legendre on
    a grid refined geometrically towards both end points (panels per side).
    """
    w = np.asarray(w, dtype=float)
    n = len(w)
    if k >= n:
        return np.ones(n)
    ppf, sf = _shape_fns(shape)
    # composite grid on (0,1), geometric refinement near 0 and 1
    half = panels // 2
    left = 0.5 * 2.0 ** (-np.arange(half, -1, -1.0))       # 2^-half-1 ... 0.5
    edges = np.concatenate(([0.0], left, 1.0 - left[::-1][1:], [1.0]))
    xg, wg = _gl(order)
    a = edges[:-1][:, None]
    b = edges[1:][:, None]
    u = (a + (b - a) * xg[None, :]).ravel()
    du = ((b - a) * wg[None, :]).ravel()
    out = np.empty(n)
    with np.errstate(divide="ignore", over="ignore", invalid="ignore"):
        x = ppf(u)                                   # X-quantiles
        for i in range(n):
            s = w[i] * x                             # i's score at quantile u
            others = np.delete(w, i)
            q = sf(s[None, :] / others[:, None])     # P(other beats i)
            q = np.nan_to_num(q, nan=0.0, posinf=1.0, neginf=0.0)
            out[i] = float(np.dot(_at_most(q, k - 1), du))
    return out


# --------------------------------------------------------------------------
# Brute force / closed forms used for validation
# --------------------------------------------------------------------------

def ppswor_inclusion_bruteforce(w: Sequence[float], k: int) -> np.ndarray:
    """Successive sampling inclusion probabilities by enumerating ordered
    k-tuples (Plackett-Luce).  O(n^k); validation only."""
    w = np.asarray(w, dtype=float)
    n = len(w)
    W = w.sum()
    pi = np.zeros(n)
    for tup in itertools.permutations(range(n), k):
        p = 1.0
        rem = W
        for t in tup:
            p *= w[t] / rem
            rem -= w[t]
        for t in tup:
            pi[t] += p
    return pi


def exclusion_exp_n3(w: Sequence[float]) -> np.ndarray:
    """Closed form for n=3,k=2 under the exponential race: P(i excluded) =
    P(i is last) = 1 - w_i/(w_i+w_j) - w_i/(w_i+w_k) + w_i/W."""
    w = np.asarray(w, dtype=float)
    W = w.sum()
    out = np.empty(3)
    for i in range(3):
        j, l = [t for t in range(3) if t != i]
        out[i] = 1 - w[i] / (w[i] + w[j]) - w[i] / (w[i] + w[l]) + w[i] / W
    return out


def simulate_inclusion(w: Sequence[float], k: int, shape="exp", m: int = 200000,
                       seed: int = 0) -> np.ndarray:
    """Monte Carlo inclusion frequencies (validation only)."""
    rng = np.random.default_rng(seed)
    w = np.asarray(w, dtype=float)
    ppf, _ = _shape_fns(shape)
    u = rng.random((m, len(w)))
    s = w[None, :] * ppf(u)
    idx = np.argpartition(-s, k - 1, axis=1)[:, :k]
    cnt = np.bincount(idx.ravel(), minlength=len(w))
    return cnt / m
