"""Differential ("electrical network") analysis of calibrated order sampling.

For exponential order sampling with log working weights l = log(lambda), the
Jacobian d pi / d l is a weighted graph Laplacian:
    d pi_i / d l_m = -phi_im  (i != m),   d pi_i / d l_i = sum_m phi_im,
with symmetric conductances
    phi_im = int_0^inf f_i(t) f_m(t) t P(exactly k-1 of the other nodes arrive before t) dt,
f_i(t) = lambda_i exp(-lambda_i t).  phi_im dl is the probability that nodes i and
m swap across the k-th/(k+1)-th rank boundary when l_m - l_i increases by dl.
"""
from __future__ import annotations

import numpy as np

from .core import _gl, target_inclusion
from .calib import calibrate


def _exactly(q: np.ndarray, m: int) -> np.ndarray:
    """P(exactly m successes) for independent Bernoulli rows q[j, :]."""
    g = q.shape[1]
    if m < 0:
        return np.zeros(g)
    dp = np.zeros((m + 1, g))
    dp[0] = 1.0
    for j in range(q.shape[0]):
        qj = q[j]
        for c in range(m, 0, -1):
            dp[c] = dp[c] * (1.0 - qj) + dp[c - 1] * qj
        dp[0] = dp[0] * (1.0 - qj)
    return dp[m]


def _counts(q: np.ndarray, m: int, surv: np.ndarray | None = None) -> np.ndarray:
    """dp[c] = P(exactly c successes), c = 0..m, for independent Bernoulli rows q[j, :].
    surv = 1 - q may be passed separately to avoid cancellation when q is close to 1."""
    if surv is None:
        surv = 1.0 - q
    dp = np.zeros((m + 1, q.shape[1]))
    dp[0] = 1.0
    for j in range(q.shape[0]):
        qj, sj = q[j], surv[j]
        for c in range(m, 0, -1):
            dp[c] = dp[c] * sj + dp[c - 1] * qj
        dp[0] = dp[0] * sj
    return dp


def race_p_phi(lam: np.ndarray, k: int, width: float = 0.25, order: int = 12, need_phi: bool = True):
    """Inclusion probabilities p and conductances phi of the exponential race with
    rates lam (selection = k earliest arrivals), by composite Gauss-Legendre
    quadrature in y = log t.  Every feature of the integrands has width O(1) in y
    whatever the spread of the rates, and every integrand is a sum of positive
    terms, so each entry is computed to high *relative* accuracy even when the
    rates span many orders of magnitude (relative error < 1e-8 against the closed
    forms for k = 2; see src/exp/theory_checks.py)."""
    lam = np.asarray(lam, dtype=float)
    n = len(lam)
    y0, y1 = np.log(1e-13 / lam.max()), np.log(45.0 / lam.min())
    m = int(np.ceil((y1 - y0) / width))
    edges = np.linspace(y0, y1, m + 1)
    xg, wg = np.polynomial.legendre.leggauss(order)
    a, b = edges[:-1][:, None], edges[1:][:, None]
    y = (0.5 * (a + b) + 0.5 * (b - a) * xg[None, :]).ravel()
    dy = (0.5 * (b - a) * wg[None, :]).ravel()
    t = np.exp(y)
    lt = np.outer(lam, t)
    surv = np.exp(-lt)                      # P(T_i > t)
    dens = lt * surv                        # f_i(t) * t : density with respect to dy
    q = -np.expm1(-lt)                      # P(T_i < t)
    p = np.empty(n)
    phi = np.zeros((n, n))
    idx = np.arange(n)
    for i in range(n):
        oth = idx != i
        p[i] = float(np.dot(dens[i] * _counts(q[oth], k - 1, surv[oth]).sum(axis=0), dy))
        if not need_phi:
            continue
        for l in range(i + 1, n):
            o2 = oth & (idx != l)
            pe = _counts(q[o2], k - 1, surv[o2])[k - 1] if o2.any() else (np.ones_like(t) if k == 1 else np.zeros_like(t))
            phi[i, l] = phi[l, i] = float(np.dot(dens[i] * dens[l] * pe, dy))
    return p, phi


def phi_k2_closed(lam: np.ndarray) -> np.ndarray:
    """Closed form of the conductances for k = 2 and any n:
    phi_il = lam_i lam_l sum_{o != i,l} [ (Lam - lam_o)^-2 - Lam^-2 ]."""
    lam = np.asarray(lam, dtype=float)
    n = len(lam)
    Lam = lam.sum()
    phi = np.zeros((n, n))
    for i in range(n):
        for l in range(i + 1, n):
            acc = 0.0
            for o in range(n):
                if o != i and o != l:
                    # (Lam-lam_o)^-2 - Lam^-2 = lam_o (2 Lam - lam_o) / (Lam^2 (Lam-lam_o)^2): no cancellation
                    acc += lam[o] * (2 * Lam - lam[o]) / (Lam ** 2 * (Lam - lam[o]) ** 2)
            phi[i, l] = phi[l, i] = lam[i] * lam[l] * acc
    return phi


def laplacian_solve(phi: np.ndarray, b: np.ndarray, dps: int = 40) -> np.ndarray:
    """Solve L(phi) v = b (sum b = 0) with v[-1] = 0 in multiple-precision arithmetic.
    Used where the conductances span many orders of magnitude."""
    import mpmath as mp
    n = len(b)
    pos = phi[phi > 0]
    span = float(np.log10(pos.max() / pos.min())) if len(pos) else 0.0
    with mp.workdps(int(max(dps, 30 + 3 * span))):
        A = mp.matrix(n - 1, n - 1)
        for i in range(n - 1):
            for l in range(n - 1):
                A[i, l] = -mp.mpf(float(phi[i, l])) if i != l else mp.fsum(mp.mpf(float(phi[i, o])) for o in range(n) if o != i)
        v = mp.lu_solve(A, mp.matrix([mp.mpf(float(x)) for x in b[:-1]]))
        return np.array([float(x) for x in v] + [0.0])


def flow_ratios(p: np.ndarray, phi: np.ndarray, k: int, dps: int = 60) -> np.ndarray:
    """rho_j for every j: total current of the electrical flow with injections
    e_j - p/k, divided by 1 - p_j/k.  The linear system is solved in
    multiple-precision arithmetic (mpmath) because conductances of cap-adjacent
    configurations span tens of orders of magnitude, which defeats a
    double-precision solve."""
    import mpmath as mp
    n = len(p)
    out = np.empty(n)
    pos = phi[phi > 0]
    span = float(np.log10(pos.max() / pos.min())) if len(pos) else 0.0
    dps = int(max(dps, 40 + 3 * span))      # precision grows with the dynamic range of the conductances
    with mp.workdps(dps):
        P = [mp.mpf(float(x)) for x in p]
        PH = [[mp.mpf(float(phi[i, l])) for l in range(n)] for i in range(n)]
        # grounded Laplacian (node n-1 grounded); one LU, n right-hand sides
        A = mp.matrix(n - 1, n - 1)
        for i in range(n - 1):
            for l in range(n - 1):
                A[i, l] = -PH[i][l] if i != l else mp.fsum(PH[i][o] for o in range(n) if o != i)
        for j in range(n):
            b = mp.matrix(n - 1, 1)
            for i in range(n - 1):
                b[i] = (1 if i == j else 0) - P[i] / k
            v = list(mp.lu_solve(A, b)) + [mp.mpf(0)]
            tot = mp.fsum(PH[i][l] * abs(v[i] - v[l]) for i in range(n) for l in range(i + 1, n))
            out[j] = float(tot / (1 - P[j] / k))
    return out


def conductances(lam: np.ndarray, k: int, panels: int = 40, order: int = 40) -> np.ndarray:
    """phi matrix (n x n, zero diagonal) for the exponential race with rates lam,
    selection = k earliest arrivals.  (panels/order are kept for backward
    compatibility; the quadrature is the log-time rule of race_p_phi.)"""
    return race_p_phi(lam, k)[1]


def laplacian(phi: np.ndarray) -> np.ndarray:
    return np.diag(phi.sum(axis=1)) - phi


def d_target(w: np.ndarray, k: int, j: int, h: float = 1e-6) -> np.ndarray:
    """d pi*/d log w_j (central difference; exact enough and valid across caps)."""
    wp = np.array(w, dtype=float)
    wm = np.array(w, dtype=float)
    wp[j] *= np.exp(h)
    wm[j] *= np.exp(-h)
    return (target_inclusion(wp, k) - target_inclusion(wm, k)) / (2 * h)


def cos_differential_ratio(w, k, j, lam=None, always=None):
    """Movement rate of COS divided by the optimal rate, for an infinitesimal
    increase of w_j.  Returns (ratio, excess_rate, opt_rate)."""
    w = np.asarray(w, dtype=float)
    if lam is None:
        lam, always = calibrate(w, k, "exp")
    free = np.where(~always)[0]
    kf = k - int(always.sum())
    dpi = d_target(w, k, j)
    opt = float(np.clip(dpi, 0, None).sum())
    if opt <= 1e-14 or len(free) < 2 or kf < 1:
        return 1.0, 0.0, opt
    phi = conductances(lam[free], kf)
    Lm = laplacian(phi)
    rhs = dpi[free]
    rhs = rhs - rhs.mean()                 # consistent with rows summing to zero
    dl, *_ = np.linalg.lstsq(Lm, rhs, rcond=None)
    diff = np.abs(dl[:, None] - dl[None, :])
    move = float((phi * diff).sum() / 2.0)
    return move / opt, move - opt, opt
