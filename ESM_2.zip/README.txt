STATELESS REPLICA PLACEMENT - code, data and outputs
=====================================================

Reproducibility materials for the manuscript "Fairness and Stability in Stateless Replica Placement: Lower Bounds and Calibrated Order Sampling" prepared for submission to The Journal of Supercomputing.

The sole manuscript author and corresponding author is Huynh Anh Khiem (Faculty of Information Technology, Ton Duc Thang University, Ho Chi Minh City, Vietnam; huynhanhkhiem@tdtu.edu.vn).

Every table, figure and number in the manuscript and in its supplementary material is generated
from the files in out/ by src/exp/make_tables.py and src/exp/make_figs.py; numbers enter the LaTeX
sources as macros (paper/numbers.tex). The placement experiments use Ceph CRUSH mapper source code with rebuilt maps.
The hierarchical validation reconstructs parsed public maps using straw2 buckets; it does not
assert that the original bucket algorithms and tunables were left untouched.
The theoretical identification of the CRUSH retry process with successive sampling is conditional
on an independent-hash idealization. Actual Ceph hashes and retries are deterministic; the C-harness
validation assesses agreement with the statistical prediction on the included reconstructions.


COMPANION REPOSITORY

  https://github.com/huynhanhkhiem-dms/fairness-stability-replica-placement
  The standalone exact certificate and recorded result are publicly available there.
  This archive contains the complete reproducibility package.

CONTENTS

  paper/      LaTeX sources of the manuscript (main.tex) and of the supplementary material
              (supplement.tex), bibliography, generated tables/figures/numbers, build.sh
  src/fsp/    Python library
                core.py       exact inclusion probabilities of order sampling; fair target
                calib.py      calibration of COS working weights (fixed point + exact Newton)
                laplacian.py  conductances, Laplacian, electrical-flow movement (multiple precision)
                movement.py   movement measurement with common random numbers
                designs.py    model of CRUSH's retry loop; systematic and pivotal sampling
                redshare.py   Redundant Share (two copies; see supplement, Section S3.1)
                crushmap.py   parsers for CRUSH maps (text, JSON, Ceph binary, OSD map)
                cephcrush.py  driver for the C harnesses
                paths.py      locations of data and outputs (FSP_ROOT, FSP_RAW)
  src/exp/    one script per experiment, plus make_tables.py and make_figs.py
  csrc/       crush_harness.c: builds a map and runs crush_do_rule of the unmodified Ceph mapper
              topk_harness.c: single-order selection on Ceph's hash and fixed-point logarithm
              build/crush/: byte-identical copies of src/crush of the Ceph repository
              build.sh: compiles both harnesses
  data/       corpus.json (parsed configurations) and raw/ (public cluster maps with licenses)
  out/        raw outputs of every experiment (CSV/JSON)
  run_all.sh  reproduction script
  requirements.txt
  LICENSE.txt licence of the code written for this paper (MIT)


REQUIREMENTS

  Linux, gcc, Python >= 3.10 with numpy, scipy, pandas, matplotlib, mpmath
  (pip install -r requirements.txt; dependencies pinned to the reproducibility environment), and pdflatex (standard article class) for the PDFs.
  The curated .bbl reference files are supplied and directly included by the LaTeX sources to preserve full DOI links. refs.bib contains the editable reference metadata; regenerate .bbl explicitly when changing references.
  The original reported runs used Python 3.13, gcc 13.3 and a two-core virtual machine with 7 GB of memory.
  A verification run on 18 November 2026 used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0,
  pandas 2.2.3, Matplotlib 3.10.8 and mpmath 1.3.0.


REPRODUCING

  sh run_all.sh paper   tables, figures and both PDFs from the shipped outputs        (~1 min)
  sh run_all.sh quick   also rebuild the harnesses and the corpus, rerun fast parts    (~5 min)
  sh run_all.sh full    rerun every experiment at the sizes used in the paper         (~2 h)

  The four-corner 12/11 certificate is checked exactly (no floating point or solver) by
  src/exp/certificate_rectangle.py.
  Monte Carlo experiments use fixed seeds and are deterministic. Two kinds of output depend on the
  machine: timings (impl_check.py; PARTS=dist, PARTS=time or PARTS=cal runs one part), and the
  random searches of rho_study.py with STUDY=margin and STUDY=free, which are seeded but stop after
  a wall-clock budget per cell (BUDGET seconds), so other machines evaluate more or fewer candidates.
  The values these searches report are lower bounds.

  In out/corpus_movement.csv the column se is the empirical standard deviation of
  per-key movement counts divided by sqrt(n_keys); the standard error of a ratio is se
  divided by the reference
  (opt_own for the rules ceph, retry and topk, opt_fair for the others). Removals that leave exactly
  k domains are kept in the CSV files and excluded by make_tables.py and make_figs.py.

  Script (src/exp/)        Output (out/)                                   Paper
  build_corpus.py          ../data/corpus.json                             Sec. 7.1
  certificate_rectangle.py certificate_rectangle.json                exact four-corner rational witness
  theory_checks.py         theory_checks.json                              Sec. 7.2, Table S2
  lp_minimax_n3.py         lp_minimax_n3.json, .csv                        Sec. 4, Table S1
  rho_study.py             rho_hier.csv, rho_fmu.csv, rho_margin_a.csv,    Sec. 6, Tables S3, S4
                           rho_free_a.csv
  realmap_validation.py    realmap_validation.csv                          Table 3
  corpus_eval.py           corpus_fairness.csv, corpus_movement.csv,       Tables 4, 5, Fig. 2
                           corpus_used.json
  redshare_eval.py         redshare_movement.csv                           supplementary diagnostic only
  retry_demo.py            retry_demo.csv                                  Table 2
  synthetic_sweep.py       sweep_fairness.csv, sweep_movement.csv          Table S5, Fig. S1
  sweep_calibration.py     sweep_calibration.csv                           Sec. 6
  frontier.py              frontier.csv, frontier_names.json               Fig. S2
  impl_check.py            impl_distribution.csv, impl_timing.csv,         Sec. 7.4, Table S6
                           calibration_timing.csv
  make_tables.py           ../paper/tables/*.tex, ../paper/numbers.tex,    all
                           movement_tests.json
  make_figs.py             ../paper/figs/*.pdf                             all


STATUS OF THE RESULTS

  Proved in the paper: Theorems 1-4, Propositions 1-4 (Proposition 4: the two corners for k = 2),
  Lemma S1 and Proposition S1 of the supplementary material.
  On finite grids only: attainment of delta_2 (linear program with certified dual).
  Heuristic, confirmed numerically for k <= 7: the cascade value T_k.
  Lower bounds found by search: the largest adaptivity ratios of COS reported in Table S4.
  Diagnostic only, NOT used as validated comparison in the manuscript: Redundant Share for
  two copies (src/fsp/redshare.py) exceeds a published bound in five removals; its
  implementation has not been reconciled with the original algorithm.


DATA PROVENANCE AND LICENSES

  All inputs are public and free of charge; they were obtained with git clone on 14-15 November
  2026. No data about people are used.

  data/raw/ceph/src/test/cli/crushtool/ and data/raw/ceph/src/test/compressor/osdmaps/osdmap.2982809
      from https://github.com/ceph/ceph, commit 794314477bd15de431a1d823d0960a7f88951eea
      (test fixtures: compiled and decompiled CRUSH maps; a complete OSD map).
      License: LGPL-2.1 or LGPL-3.0 (data/raw/ceph/COPYING*).
  data/raw/python-crush/tests/
      from https://github.com/ceph/python-crush, commit b3f717dd6a78ee66ec76b4e2a5b6772fbf0f0c95
      (cluster reports and maps of its test suite). License: GPL-3.0 (data/raw/python-crush/LICENSE).
  csrc/build/crush/ (builder.c, crush.c, hash.c, mapper.c and headers)
      byte-identical copies of src/crush of the Ceph commit above. License: LGPL-2.1 or LGPL-3.0.
  csrc/build/include/int_types.h
      from https://github.com/ceph/libcrush (commit de2e859a). License: LGPL-2.1
      (data/raw/libcrush/LICENSE-LGPL-2.1).
  csrc/build/acconfig.h is a three-line shim written for this package; csrc/topk_harness.c contains a
  verbatim copy of the static function crush_ln of Ceph's mapper.c.

  The maps are data and are never executed; the parsers only read bytes and text.
  Code written for this paper is released under the MIT License (LICENSE.txt); third-party files
  keep their own licenses.

LICENSE NOTICE
  The MIT license file retains the supplied copyright notice (Quang Vinh Tran, 2026).
  Copyright ownership and scientific authorship are distinct; any permission to distribute
  the code must be assessed against the license and contributors' rights.

DETERMINISTIC SEARCH RECHECK
  The recorded rho-margin/free searches used a wall-clock budget. To obtain a fully
  fixed candidate count in new independent diagnostic runs, set SEARCH_CANDIDATES
  to a positive integer when invoking src/exp/rho_study.py. This alternative mode
  is not claimed to reproduce the wall-clock-limited search maxima in out/.
