/*
 * topk_harness: single-order ("top-k straws of ONE draw") selection for a flat
 * straw2 bucket, written against the Ceph CRUSH code base: it reuses Ceph's
 * hash (crush_hash32_3, rjenkins1) and Ceph's fixed-point logarithm so that
 * each straw is bit-identical to the one bucket_straw2_choose() computes for
 * r = 0.  The only change with respect to CRUSH is the selection logic:
 * instead of k successive draws with collision retries (r' = r + ftotal), the
 * k longest straws of one draw are taken.
 *
 * crush_ln() below is copied verbatim from ceph/src/crush/mapper.c (LGPL-2.1),
 * where it is a static function.
 *
 * Spec: same format as crush_harness (only the first B line and the X line are
 * used).  A weight of -1 marks an "always selected" (capped) item.
 * Usage: topk_harness spec out.bin [time]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>

#include "crush/crush.h"
#include "crush/hash.h"
#include "crush/crush_ln_table.h"

static __u64 crush_ln(unsigned int xin)
{
	unsigned int x = xin;
	int iexpon, index1, index2;
	__u64 RH, LH, LL, xl64, result;

	x++;

	/* normalize input */
	iexpon = 15;

	if (!(x & 0x18000)) {
	  int bits = __builtin_clz(x & 0x1FFFF) - 16;
	  x <<= bits;
	  iexpon = 15 - bits;
	}

	index1 = (x >> 8) << 1;
	RH = __RH_LH_tbl[index1 - 256];
	LH = __RH_LH_tbl[index1 + 1 - 256];

	xl64 = (__s64)x * RH;
	xl64 >>= 48;

	result = iexpon;
	result <<= (12 + 32);

	index2 = xl64 & 0xff;
	LL = __LL_tbl[index2];

	LH = LH + LL;

	LH >>= (48 - 12 - 32);
	result += LH;

	return result;
}

static inline long long straw(int x, int id, long long weight)
{
	unsigned int u = crush_hash32_3(CRUSH_HASH_RJENKINS1, x, id, 0);
	u &= 0xffff;
	long long ln = (long long)crush_ln(u) - 0x1000000000000ll;
	return ln / weight;
}

int main(int argc, char **argv)
{
	if (argc < 3) { fprintf(stderr, "usage: %s spec out.bin [time]\n", argv[0]); return 2; }
	FILE *f = fopen(argv[1], "r");
	if (!f) { perror("spec"); return 2; }
	char tok[16];
	int size = 0, *items = NULL; long long *weights = NULL;
	long N = 0; int k = 0; long x0 = 0; int have_bucket = 0;
	while (fscanf(f, "%15s", tok) == 1) {
		if (!strcmp(tok, "T")) { int a; for (int i = 0; i < 6; i++) if (fscanf(f, "%d", &a) != 1) return 3; }
		else if (!strcmp(tok, "B")) {
			int id, alg, type, sz;
			if (fscanf(f, "%d %d %d %d", &id, &alg, &type, &sz) != 4) return 3;
			int *it = malloc(sizeof(int) * (sz ? sz : 1));
			long long *wt = malloc(sizeof(long long) * (sz ? sz : 1));
			for (int i = 0; i < sz; i++) if (fscanf(f, "%d %lld", &it[i], &wt[i]) != 2) return 3;
			if (!have_bucket) { items = it; weights = wt; size = sz; have_bucket = 1; }
		} else if (!strcmp(tok, "R")) {
			int n, a; if (fscanf(f, "%d", &n) != 1) return 3;
			for (int i = 0; i < 3 * n; i++) if (fscanf(f, "%d", &a) != 1) return 3;
		} else if (!strcmp(tok, "X")) { if (fscanf(f, "%ld %d %ld", &N, &k, &x0) != 3) return 3; }
		else return 3;
	}
	fclose(f);
	if (!have_bucket || N <= 0 || k <= 0 || k > size) { fprintf(stderr, "bad spec\n"); return 3; }
	int *out = malloc(sizeof(int) * (size_t)N * k);
	long long *best = malloc(sizeof(long long) * k);
	int *bi = malloc(sizeof(int) * k);
	struct timespec t0, t1;
	clock_gettime(CLOCK_MONOTONIC, &t0);
	for (long q = 0; q < N; q++) {
		int x = (int)(x0 + q), cnt = 0;
		for (int i = 0; i < size; i++) {
			long long d;
			if (weights[i] == 0) continue;
			if (weights[i] < 0) d = LLONG_MAX - i;          /* capped item: always in */
			else d = straw(x, items[i], weights[i]);
			/* insertion into the running top-k; ties keep the lower index first,
			 * as bucket_straw2_choose does (strict '>' comparison) */
			int p = cnt < k ? cnt : k;
			while (p > 0 && d > best[p - 1]) p--;
			if (p < k) {
				int last = cnt < k ? cnt : k - 1;
				for (int m = last; m > p; m--) { best[m] = best[m - 1]; bi[m] = bi[m - 1]; }
				best[p] = d; bi[p] = items[i];
				if (cnt < k) cnt++;
			}
		}
		for (int j = 0; j < k; j++) out[q * k + j] = j < cnt ? bi[j] : 0x7fffffff;
	}
	clock_gettime(CLOCK_MONOTONIC, &t1);
	double ns = ((t1.tv_sec - t0.tv_sec) * 1e9 + (t1.tv_nsec - t0.tv_nsec)) / (double)N;
	FILE *o = fopen(argv[2], "wb");
	if (!o) { perror("out"); return 2; }
	fwrite(out, sizeof(int), (size_t)N * k, o);
	fclose(o);
	fprintf(stderr, "topk N=%ld k=%d size=%d ns_per_mapping=%.1f\n", N, k, size, ns);
	return 0;
}
