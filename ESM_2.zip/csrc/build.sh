#!/bin/sh
# Build the two harnesses.  csrc/build/crush/*.{c,h} are byte-identical copies of src/crush/ of the Ceph
# repository at the commit given in data/PROVENANCE.md; include/int_types.h comes from ceph/libcrush;
# acconfig.h is a three-line shim that replaces the autoconf header.  Nothing in the mapper is modified.
set -e
cd "$(dirname "$0")/build"
CC=${CC:-gcc}
FLAGS="-O2 -I. -Icrush -Iinclude"
for f in builder crush hash mapper; do $CC $FLAGS -c crush/$f.c -o $f.o; done
$CC $FLAGS -o crush_harness ../crush_harness.c builder.o crush.o hash.o mapper.o -lm
$CC $FLAGS -o topk_harness ../topk_harness.c hash.o -lm
echo "built: $(pwd)/crush_harness $(pwd)/topk_harness"
