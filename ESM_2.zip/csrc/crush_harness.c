/*
 * crush_harness: drive the UNMODIFIED Ceph CRUSH mapper (src/crush/mapper.c,
 * builder.c, hash.c, crush.c from the Ceph repository) on a map described in a
 * tiny text spec, and dump the mapping of x = 0..N-1 as raw int32.
 *
 * Spec (whitespace separated tokens):
 *   T lt lft tt descend_once vary_r stable   (optional; default = set_optimal_crush_map)
 *   B id alg type size  item weight  item weight ...   (weight is 16.16 fixed point)
 *   R nsteps  op arg1 arg2  op arg1 arg2 ...
 *   X N k x0
 * Output file: N*k int32 (CRUSH_ITEM_NONE = 0x7fffffff where unmapped).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "crush/crush.h"
#include "crush/builder.h"
#include "crush/mapper.h"
#include "crush/hash.h"

int main(int argc, char **argv)
{
	if (argc < 3) {
		fprintf(stderr, "usage: %s spec out.bin\n", argv[0]);
		return 2;
	}
	FILE *f = fopen(argv[1], "r");
	if (!f) { perror("spec"); return 2; }
	struct crush_map *map = crush_create();
	set_optimal_crush_map(map);
	char tok[16];
	int ruleno = -1;
	long N = 0; int k = 0; long x0 = 0;
	while (fscanf(f, "%15s", tok) == 1) {
		if (!strcmp(tok, "T")) {
			int a, b, c, d, e, g;
			if (fscanf(f, "%d %d %d %d %d %d", &a, &b, &c, &d, &e, &g) != 6) return 3;
			map->choose_local_tries = a;
			map->choose_local_fallback_tries = b;
			map->choose_total_tries = c;
			map->chooseleaf_descend_once = d;
			map->chooseleaf_vary_r = e;
			map->chooseleaf_stable = g;
		} else if (!strcmp(tok, "B")) {
			int id, alg, type, size;
			if (fscanf(f, "%d %d %d %d", &id, &alg, &type, &size) != 4) return 3;
			int *items = malloc(sizeof(int) * (size ? size : 1));
			int *weights = malloc(sizeof(int) * (size ? size : 1));
			for (int i = 0; i < size; i++)
				if (fscanf(f, "%d %d", &items[i], &weights[i]) != 2) return 3;
			struct crush_bucket *b = crush_make_bucket(map, alg, CRUSH_HASH_RJENKINS1,
								   type, size, items, weights);
			if (!b) { fprintf(stderr, "make_bucket failed for %d\n", id); return 4; }
			int idout;
			if (crush_add_bucket(map, id, b, &idout) < 0 || idout != id) {
				fprintf(stderr, "add_bucket failed for %d\n", id);
				return 4;
			}
			free(items); free(weights);
		} else if (!strcmp(tok, "R")) {
			int n;
			if (fscanf(f, "%d", &n) != 1) return 3;
			struct crush_rule *r = crush_make_rule(n, 1);
			for (int i = 0; i < n; i++) {
				int op, a1, a2;
				if (fscanf(f, "%d %d %d", &op, &a1, &a2) != 3) return 3;
				crush_rule_set_step(r, i, op, a1, a2);
			}
			ruleno = crush_add_rule(map, r, -1);
		} else if (!strcmp(tok, "X")) {
			if (fscanf(f, "%ld %d %ld", &N, &k, &x0) != 3) return 3;
		} else {
			fprintf(stderr, "bad token %s\n", tok);
			return 3;
		}
	}
	fclose(f);
	crush_finalize(map);
	if (ruleno < 0 || N <= 0 || k <= 0) { fprintf(stderr, "incomplete spec\n"); return 3; }
	int nd = map->max_devices;
	__u32 *w = malloc(sizeof(__u32) * (nd ? nd : 1));
	for (int i = 0; i < nd; i++) w[i] = 0x10000;
	void *cwin = malloc(crush_work_size(map, k));
	int *res = malloc(sizeof(int) * k);
	int *out = malloc(sizeof(int) * (size_t)N * k);
	long shortfall = 0;
	struct timespec t0, t1;
	clock_gettime(CLOCK_MONOTONIC, &t0);
	for (long i = 0; i < N; i++) {
		crush_init_workspace(map, cwin);
		int got = crush_do_rule(map, ruleno, (int)(x0 + i), res, k, w, nd, cwin, NULL);
		for (int j = 0; j < k; j++)
			out[i * k + j] = j < got ? res[j] : 0x7fffffff;
		if (got < k) shortfall++;
	}
	clock_gettime(CLOCK_MONOTONIC, &t1);
	double ns = ((t1.tv_sec - t0.tv_sec) * 1e9 + (t1.tv_nsec - t0.tv_nsec)) / (double)N;
	FILE *o = fopen(argv[2], "wb");
	if (!o) { perror("out"); return 2; }
	fwrite(out, sizeof(int), (size_t)N * k, o);
	fclose(o);
	fprintf(stderr, "mapped N=%ld k=%d max_devices=%d shortfall=%ld ns_per_mapping=%.1f\n", N, k, nd, shortfall, ns);
	return 0;
}
