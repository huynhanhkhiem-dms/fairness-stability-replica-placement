#!/bin/sh
# Manuscript and supplementary cross-references require several LaTeX passes.
set -eu
cd "$(dirname "$0")"
# Supports both the flat submission-source archive and the packaged code/data tree.
export TEXINPUTS=".:./tables:./figs:${TEXINPUTS:-}"
for i in 1 2; do
  pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null
  pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null
done
# The curated, numbered bibliography is in main.bbl and supplement.bbl.
# refs.bib is also supplied; no BibTeX call may silently strip linked DOIs.
[ -s main.bbl ] && [ -s supplement.bbl ] || { echo "missing bibliography source" >&2; exit 1; }
for i in 1 2 3; do
  pdflatex -interaction=nonstopmode -halt-on-error supplement.tex >/dev/null
  pdflatex -interaction=nonstopmode -halt-on-error main.tex >/dev/null
done
echo "built main.pdf supplement.pdf"
