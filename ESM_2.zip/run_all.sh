#!/bin/sh
# Reproduce the paper.  Usage: sh run_all.sh [paper|quick|full]
#   paper  regenerate tables, figures and both PDFs from the shipped outputs in out/      (~1 min)
#   quick  also rebuild the C harnesses and the corpus and rerun the fast experiments      (~5 min)
#   full   rerun every experiment at the sizes used in the paper                           (~2 h, 2 cores)
# Long experiments checkpoint in out/chunks and out/sweep_chunks and resume when re-run.
set -e
MODE=${1:-paper}
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PY=${PYTHON:-python3}
E=src/exp
run() { echo ">>> $*"; "$@"; }

if [ "$MODE" != "paper" ]; then
  run sh csrc/build.sh
  run $PY $E/build_corpus.py
  STUDY=hier run $PY $E/rho_study.py
  STUDY=fmu  run $PY $E/rho_study.py
  run $PY $E/retry_demo.py
  run $PY $E/redshare_eval.py
  run $PY $E/certificate_rectangle.py
fi

if [ "$MODE" = "full" ]; then
  run $PY $E/theory_checks.py
  run $PY $E/lp_minimax_n3.py
  STUDY=margin GRID="3x2,4x2,4x3,5x2,5x3,5x4,6x2,6x3,6x4,8x3" MARGINS="0.1,0.01,0.001" BUDGET=25 TAG=a run $PY $E/rho_study.py
  STUDY=free GRID="4x2,5x2,6x2,5x3,6x3,6x4,7x5" BUDGET=60 TAG=a run $PY $E/rho_study.py
  run $PY $E/realmap_validation.py
  M_KEYS=500000 run $PY $E/corpus_eval.py
  M_KEYS=200000 run $PY $E/synthetic_sweep.py
  run $PY $E/sweep_calibration.py
  M_KEYS=1000000 run $PY $E/frontier.py
  run $PY $E/impl_check.py
fi

run $PY $E/make_tables.py
run $PY $E/make_figs.py
run sh paper/build.sh
echo "done: paper/main.pdf and paper/supplement.pdf"
